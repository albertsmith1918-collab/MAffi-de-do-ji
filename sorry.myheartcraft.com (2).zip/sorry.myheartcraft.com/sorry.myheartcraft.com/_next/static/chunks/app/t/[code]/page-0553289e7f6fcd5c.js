!(function () {
  try {
    var e =
        "u" > typeof window
          ? window
          : "u" > typeof global
          ? global
          : "u" > typeof globalThis
          ? globalThis
          : "u" > typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "b49f43d4-2c94-485e-a93a-6983a9f0106b"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-b49f43d4-2c94-485e-a93a-6983a9f0106b"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [449],
    {
      446: () => {},
      1122: () => {},
      3321: (e, t, a) => {
        "use strict";
        var s = a(4645);
        a.o(s, "useParams") &&
          a.d(t, {
            useParams: function () {
              return s.useParams;
            },
          }),
          a.o(s, "useSearchParams") &&
            a.d(t, {
              useSearchParams: function () {
                return s.useSearchParams;
              },
            });
      },
      3791: () => {},
      4066: (e, t, a) => {
        Promise.resolve().then(a.bind(a, 4102));
      },
      4102: (e, t, a) => {
        "use strict";
        a.r(t), a.d(t, { default: () => M });
        var s = a(5155),
          l = a(2115);
        a(7413);
        let r = ["♥", "♡", "❤", "\uD83D\uDC95", "\uD83D\uDC97"],
          n = function () {
            let [e, t] = (0, l.useState)([]),
              [a, n] = (0, l.useState)(!1);
            return ((0, l.useEffect)(() => {
              t(
                [...Array(20)].map((e, t) => ({
                  left: 100 * Math.random(),
                  delay: 12 * Math.random(),
                  duration: 8 + 10 * Math.random(),
                  size: 18 + 28 * Math.random(),
                  char: r[t % r.length],
                  drift: -30 + 60 * Math.random(),
                  opacity: 0.15 + 0.3 * Math.random(),
                }))
              ),
                n(!0);
            }, []),
            a)
              ? (0, s.jsx)("div", {
                  className: "floating-hearts-field",
                  "aria-hidden": "true",
                  children: e.map((e, t) =>
                    (0, s.jsx)(
                      "span",
                      {
                        className: "floating-heart",
                        style: {
                          left: `${e.left}%`,
                          animationDelay: `${e.delay}s`,
                          animationDuration: `${e.duration}s`,
                          fontSize: `${e.size}px`,
                          "--drift": `${e.drift}px`,
                          "--peak-opacity": e.opacity,
                        },
                        children: e.char,
                      },
                      t
                    )
                  ),
                })
              : (0, s.jsx)("div", {
                  className: "floating-hearts-field",
                  "aria-hidden": "true",
                });
          };
        a(7139);
        let i = function ({ onNext: e, recipientName: t }) {
          return (0, s.jsx)("div", {
            className: "tpl-landing",
            children: (0, s.jsxs)("div", {
              className: "tpl-landing-content",
              children: [
                (0, s.jsxs)("div", {
                  className: "tpl-landing-image-wrap",
                  children: [
                    (0, s.jsx)("img", {
                      src: "/template/home_page_cat.webp",
                      alt: "",
                      className: "tpl-landing-image tpl-landing-dance",
                    }),
                    (0, s.jsx)("div", {
                      className: "tpl-landing-heart-badge",
                      children: (0, s.jsxs)("svg", {
                        viewBox: "0 0 48 48",
                        className: "tpl-landing-heart-svg",
                        children: [
                          (0, s.jsx)("circle", {
                            cx: "24",
                            cy: "24",
                            r: "24",
                            fill: "#e85a7a",
                          }),
                          (0, s.jsx)("path", {
                            d: "M24 36s-12-7.5-12-15c0-4 3-7 6.5-7 2.2 0 4.2 1.2 5.5 3 1.3-1.8 3.3-3 5.5-3 3.5 0 6.5 3 6.5 7 0 7.5-12 15-12 15z",
                            fill: "white",
                          }),
                        ],
                      }),
                    }),
                  ],
                }),
                (0, s.jsxs)("h1", {
                  className: "tpl-landing-title",
                  children: ["I Messed Up, ", t || "Bestie", " \uD83D\uDE22"],
                }),
                (0, s.jsx)("p", {
                  className: "tpl-landing-subtitle",
                  children:
                    "But I'm ready to make it right. Will you hear me out?",
                }),
                (0, s.jsx)("button", {
                  className: "template-btn-primary tpl-landing-btn",
                  onClick: e,
                  children: "Listen to my heart \uD83D\uDC9D",
                }),
              ],
            }),
          });
        };
        a(8617);
        let c = function ({ config: e, message: t, onNext: a, onBack: l }) {
          let r = t || e.defaultMessage;
          return (0, s.jsx)("div", {
            className: "tpl-slide",
            children: (0, s.jsxs)("div", {
              className: "tpl-slide-content",
              children: [
                (0, s.jsx)("div", {
                  className: "tpl-slide-image-wrap",
                  children: (0, s.jsx)("img", {
                    src: e.image,
                    alt: "",
                    className: "tpl-slide-image",
                  }),
                }),
                (0, s.jsx)("h2", {
                  className: "tpl-slide-title",
                  children: e.title,
                }),
                (0, s.jsx)("div", {
                  className: "tpl-slide-message-card",
                  children: (0, s.jsx)("p", {
                    className: "tpl-slide-message",
                    children: r,
                  }),
                }),
                (0, s.jsxs)("div", {
                  className: "template-nav-row",
                  children: [
                    (0, s.jsx)("button", {
                      className: "template-btn-secondary",
                      onClick: l,
                      children: "← Back",
                    }),
                    (0, s.jsx)("button", {
                      className: "template-btn-primary",
                      onClick: a,
                      children: "Next →",
                    }),
                  ],
                }),
              ],
            }),
          });
        };
        a(4266);
        let o = function ({ onOpen: e, onBack: t }) {
          return (0, s.jsxs)("div", {
            className: "tpl-envelope",
            children: [
              (0, s.jsx)("button", {
                className: "template-back-top",
                onClick: t,
                children: "← Back",
              }),
              (0, s.jsx)("div", {
                className: "tpl-envelope-content",
                children: (0, s.jsxs)("div", {
                  className: "tpl-envelope-wrapper",
                  onClick: e,
                  role: "button",
                  tabIndex: 0,
                  onKeyDown: (t) => {
                    ("Enter" === t.key || " " === t.key) &&
                      (t.preventDefault(), e());
                  },
                  children: [
                    (0, s.jsx)("img", {
                      src: "/card-animation/envelope_closed.webp",
                      alt: "Envelope",
                      className: "tpl-envelope-img",
                    }),
                    (0, s.jsx)("p", {
                      className: "tpl-envelope-hint",
                      children: "Click to open ❤️",
                    }),
                  ],
                }),
              }),
            ],
          });
        };
        var d = a(8165);
        a(446);
        let m = function ({ sorryData: e, onNext: t, onBack: a }) {
          let r = (0, l.useRef)(null),
            n = e?.recipientName || e?.userName || "you",
            i =
              e?.personalNote ||
              "I am so so sorry for being such a silly bear lately. I've realized how much I hurt you, and it breaks my heart to see you upset. You mean the world to me, and I promise to be better, more patient, and way more cuddly! Will you please peek inside this letter and give me one more chance? \uD83D\uDE4F",
            { displayText: c, isComplete: o } = (0, d.d)(i, 30, 300, !0);
          return (
            (0, l.useEffect)(() => {
              r.current && (r.current.scrollTop = r.current.scrollHeight);
            }, [c]),
            (0, s.jsxs)("div", {
              className: "tpl-letter",
              children: [
                (0, s.jsx)("button", {
                  className: "template-back-top",
                  onClick: a,
                  children: "← Back",
                }),
                (0, s.jsxs)("div", {
                  className: "tpl-letter-content",
                  children: [
                    (0, s.jsx)("h2", {
                      className: "tpl-letter-heading",
                      children: "A Virtual Peace Offering ❤️",
                    }),
                    (0, s.jsxs)("div", {
                      className: "tpl-letter-card",
                      children: [
                        (0, s.jsxs)("p", {
                          className: "tpl-letter-greeting",
                          children: ["My Dearest ", n, ","],
                        }),
                        (0, s.jsx)("div", {
                          className: "tpl-letter-text",
                          ref: r,
                          children: c
                            .split("\n")
                            .filter((e) => "" !== e.trim())
                            .map((e, t, a) =>
                              (0, s.jsxs)(
                                "p",
                                {
                                  children: [
                                    e,
                                    t === a.length - 1 &&
                                      !o &&
                                      (0, s.jsx)("span", {
                                        className: "tpl-letter-cursor",
                                        children: "|",
                                      }),
                                  ],
                                },
                                t
                              )
                            ),
                        }),
                        (0, s.jsx)("div", {
                          className: "tpl-letter-cat-wrap",
                          children: (0, s.jsx)("img", {
                            src: "/template/letter-cat.webp",
                            alt: "",
                            className: "tpl-letter-cat",
                          }),
                        }),
                      ],
                    }),
                    o &&
                      (0, s.jsx)("button", {
                        className: "template-btn-primary tpl-letter-next",
                        onClick: t,
                        children: "Continue →",
                      }),
                  ],
                }),
              ],
            })
          );
        };
        function p() {
          let e = (0, l.useRef)(
            [...Array(100)].map((e, t) => ({
              left: 100 * Math.random(),
              delay: +Math.random(),
              duration: 1.5 + 2 * Math.random(),
              size: 4 + 8 * Math.random(),
              color: [
                "#e85a7a",
                "#f8a4b8",
                "#fdd",
                "#ff6b8a",
                "#d44060",
                "#ffc0cb",
                "#ff85a2",
                "#ffb6c1",
                "#f06292",
                "#ec407a",
              ][t % 10],
              drift: -60 + 120 * Math.random(),
              shape: ["circle", "rect", "star"][t % 3],
              rotation: 360 * Math.random(),
            }))
          );
          return (0, s.jsx)("div", {
            className: "tpl-confetti",
            "aria-hidden": "true",
            children: e.current.map((e, t) =>
              (0, s.jsx)(
                "div",
                {
                  className: `tpl-confetti-piece tpl-confetti-${e.shape}`,
                  style: {
                    left: `${e.left}%`,
                    animationDelay: `${e.delay}s`,
                    animationDuration: `${e.duration}s`,
                    width: `${e.size}px`,
                    height:
                      "rect" === e.shape ? `${0.4 * e.size}px` : `${e.size}px`,
                    backgroundColor: e.color,
                    "--drift": `${e.drift}px`,
                    "--rotation": `${e.rotation}deg`,
                  },
                },
                t
              )
            ),
          });
        }
        a(1122);
        let u = function ({ onComplete: e, onBack: t }) {
          let [a, r] = (0, l.useState)(0),
            [n, i] = (0, l.useState)(!1),
            [c, o] = (0, l.useState)(!1),
            [d, m] = (0, l.useState)(!1),
            u = (0, l.useRef)(null),
            h = Math.min(Math.round((a / 10) * 100), 100);
          return (
            (0, l.useEffect)(() => {
              if (n) {
                u.current = setTimeout(() => {
                  m(!0);
                }, 2200);
                let t = setTimeout(() => {
                  e();
                }, 3e3);
                return () => {
                  clearTimeout(u.current), clearTimeout(t);
                };
              }
            }, [n, e]),
            (0, s.jsxs)("div", {
              className: `tpl-meter ${d ? "tpl-meter-fade-out" : ""}`,
              children: [
                !n &&
                  (0, s.jsx)("button", {
                    className: "template-back-top tpl-meter-back",
                    onClick: t,
                    children: "← Back",
                  }),
                (0, s.jsxs)("div", {
                  className: `tpl-meter-card ${
                    n ? "tpl-meter-card-complete" : ""
                  }`,
                  children: [
                    (0, s.jsx)("h2", {
                      className: "tpl-meter-title",
                      children: "Forgiveness Meter ❤️",
                    }),
                    (0, s.jsxs)("div", {
                      className: "tpl-meter-gif-wrap",
                      children: [
                        (0, s.jsx)("img", {
                          src: n
                            ? "/template/meter-happy.webp"
                            : "/template/meter-sorry.webp",
                          alt: "",
                          className: `tpl-meter-gif ${
                            n ? "tpl-meter-gif-happy" : ""
                          }`,
                        }),
                        n &&
                          (0, s.jsx)("div", {
                            className: "tpl-meter-hearts-burst",
                            children: [
                              "\uD83D\uDC95",
                              "\uD83D\uDC96",
                              "\uD83D\uDC97",
                              "❤️",
                              "\uD83D\uDC9D",
                            ].map((e, t) =>
                              (0, s.jsx)(
                                "span",
                                {
                                  className: "tpl-meter-burst-heart",
                                  style: { animationDelay: `${0.12 * t}s` },
                                  children: e,
                                },
                                t
                              )
                            ),
                          }),
                      ],
                    }),
                    c && (0, s.jsx)(p, {}),
                    (0, s.jsxs)("div", {
                      className: "tpl-meter-bar-wrap",
                      children: [
                        (0, s.jsx)("div", {
                          className: "tpl-meter-bar",
                          children: (0, s.jsx)("div", {
                            className: `tpl-meter-bar-fill ${
                              n ? "tpl-meter-bar-complete" : ""
                            }`,
                            style: { width: `${h}%` },
                          }),
                        }),
                        (0, s.jsxs)("p", {
                          className: "tpl-meter-percent",
                          children: [h, "% Forgiven"],
                        }),
                      ],
                    }),
                    (0, s.jsx)("p", {
                      className: "tpl-meter-cta",
                      children: n
                        ? "You're forgiven! \uD83D\uDC95"
                        : "Tap the heart to heal my heart!",
                    }),
                    !n &&
                      (0, s.jsx)("button", {
                        className: "tpl-meter-heart-btn",
                        onClick: () => {
                          if (n) return;
                          let e = a + 1;
                          r(e), e >= 10 && (i(!0), o(!0));
                        },
                        "aria-label": "Tap to forgive",
                        children: (0, s.jsx)("span", {
                          className: "tpl-meter-heart-icon",
                          children: "\uD83E\uDD0D",
                        }),
                      }),
                  ],
                }),
              ],
            })
          );
        };
        a(3791);
        let h = [
            {
              image: "/template/coupon-flowers.webp",
              title: "Fresh Blooms \uD83C\uDF38",
              description:
                "Valid for 1 bouquet delivery + unlimited forehead kisses \uD83D\uDC95",
              redeemText: "Redeemable anytime",
            },
            {
              image: "/template/coupon-teddy.webp",
              title: "Cuddle Pass \uD83E\uDDF8",
              description:
                "Valid for unlimited hugs, cuddles & no drama day \uD83E\uDD70",
              redeemText: "Redeemable anytime",
            },
            {
              image: "/template/coupon-chocolate.webp",
              title: "Sweet Treat \uD83C\uDF6B",
              description:
                "Valid for your favorite chocolate + my full attention \uD83D\uDE0A",
              redeemText: "Redeemable anytime",
            },
          ],
          f = function ({ onNext: e, onBack: t }) {
            return (0, s.jsxs)("div", {
              className: "tpl-coupons",
              children: [
                (0, s.jsx)("button", {
                  className: "template-back-top",
                  onClick: t,
                  children: "← Back",
                }),
                (0, s.jsxs)("div", {
                  className: "tpl-coupons-content",
                  children: [
                    (0, s.jsx)("div", {
                      className: "tpl-coupons-grid",
                      children: h.map((e, t) =>
                        (0, s.jsxs)(
                          "div",
                          {
                            className: "tpl-coupon-card",
                            children: [
                              (0, s.jsx)("div", {
                                className: "tpl-coupon-image-wrap",
                                children: (0, s.jsx)("img", {
                                  src: e.image,
                                  alt: "",
                                  className: "tpl-coupon-image",
                                }),
                              }),
                              (0, s.jsx)("h3", {
                                className: "tpl-coupon-title",
                                children: e.title,
                              }),
                              (0, s.jsx)("p", {
                                className: "tpl-coupon-desc",
                                children: e.description,
                              }),
                              (0, s.jsxs)("div", {
                                className: "tpl-coupon-redeem",
                                children: [
                                  (0, s.jsx)("span", {
                                    className: "tpl-coupon-tick",
                                    children: "✓",
                                  }),
                                  (0, s.jsx)("span", {
                                    className: "tpl-coupon-redeem-text",
                                    children: e.redeemText,
                                  }),
                                ],
                              }),
                            ],
                          },
                          t
                        )
                      ),
                    }),
                    (0, s.jsx)("button", {
                      className: "tpl-coupons-btn",
                      onClick: e,
                      children: "ENOUGH BRIBES!",
                    }),
                  ],
                }),
              ],
            });
          };
        a(9071);
        let x = [
            { src: "/template/finale-doodle1.webp", alt: "Doodle 1" },
            { src: "/template/finale-doodle2.webp", alt: "Doodle 2" },
            { src: "/template/finale-doodle3.webp", alt: "Doodle 3" },
          ],
          g = function ({ onReplay: e, onBack: t }) {
            return (0, s.jsxs)("div", {
              className: "tpl-finale",
              children: [
                (0, s.jsx)("button", {
                  className: "template-back-top tpl-finale-back",
                  onClick: t,
                  children: "← Back",
                }),
                (0, s.jsxs)("div", {
                  className: "tpl-finale-content",
                  children: [
                    (0, s.jsxs)("div", {
                      className: "tpl-finale-doodles",
                      children: [
                        (0, s.jsx)("div", {
                          className: "tpl-finale-doodle-row-top",
                          children: x
                            .slice(0, 2)
                            .map((e, t) =>
                              (0, s.jsx)(
                                "div",
                                {
                                  className: "tpl-finale-doodle-card",
                                  style: { animationDelay: `${0.15 * t}s` },
                                  children: (0, s.jsx)("img", {
                                    src: e.src,
                                    alt: e.alt,
                                    className: "tpl-finale-doodle-img",
                                  }),
                                },
                                t
                              )
                            ),
                        }),
                        (0, s.jsx)("div", {
                          className: "tpl-finale-doodle-row-bottom",
                          children: (0, s.jsx)("div", {
                            className: "tpl-finale-doodle-card",
                            style: { animationDelay: "0.3s" },
                            children: (0, s.jsx)("img", {
                              src: x[2].src,
                              alt: x[2].alt,
                              className: "tpl-finale-doodle-img",
                            }),
                          }),
                        }),
                      ],
                    }),
                    (0, s.jsxs)("div", {
                      className: "tpl-finale-text-box",
                      children: [
                        (0, s.jsx)("h1", {
                          className: "tpl-finale-title",
                          children: "PEACE TREATY SIGNED! \uD83D\uDD4A️",
                        }),
                        (0, s.jsx)("p", {
                          className: "tpl-finale-subtitle",
                          children: "New Beginnings Ahead",
                        }),
                        (0, s.jsx)("p", {
                          className: "tpl-finale-message",
                          children:
                            "Thank you for being the most forgiving and wonderful person. I love you to the moon and back and I'm never letting go! \uD83D\uDC9A\uD83D\uDE4F",
                        }),
                        (0, s.jsx)("div", {
                          className: "tpl-finale-hearts",
                          children: "❤️❤️❤️❤️❤️",
                        }),
                      ],
                    }),
                    (0, s.jsx)("a", {
                      href: "/MYOL",
                      className: "",
                      children: "",
                    }),
                  ],
                }),
              ],
            });
          };
        var N = a(9076),
          j = a(4572),
          y = a(5864),
          b = a(8713),
          v = a(1123);
        a(5408);
        let k = [
            {
              image: "/template/slide-bunny.webp",
              title: "I Know I Hurt You",
              messageKey: "sorryMessage1",
              defaultMessage:
                "Seeing you upset breaks my heart more than anything. I never meant to make you feel this way.",
            },
            {
              image: "/template/slide-bears.webp",
              title: "You Mean Everything",
              messageKey: "sorryMessage2",
              defaultMessage:
                "You're not just my best friend, you're my person. Life without our laughs is just... gray.",
            },
            {
              image: "/template/slide-sorry-bear.webp",
              title: "I'm Truly Sorry",
              messageKey: "sorryMessage3",
              defaultMessage:
                "I messed up, and I own it. No excuses, just genuine regret for hurting my favorite person.",
            },
          ],
          w = function ({ shortCode: e }) {
            let [t, a] = (0, l.useState)(1),
              [r, d] = (0, l.useState)(null),
              [p, h] = (0, l.useState)(!0),
              [x, w] = (0, l.useState)(null),
              I = (0, l.useRef)(!1);
            (0, l.useEffect)(() => {
              I.current ||
                ((I.current = !0),
                (async () => {
                  if (!e) {
                    w("Invalid share link"), h(!1);
                    return;
                  }
                  h(!0), w(null);
                  try {
                    if ("test123" === e) {
                      let e = null;
                      try {
                        e = (0, b.bi)("sorry_test_data");
                      } catch {}
                      if (e) {
                        let t = JSON.parse(e);
                        if (!(0, j.u0)()) {
                          let e = crypto.randomUUID();
                          (0, j.mY)(e);
                        }
                        (0, j.xS)(t), d(t), h(!1);
                        return;
                      }
                      throw Error(
                        "."
                      );
                    }
                    let t = await (0, N.gb)(e);
                    if (!t.success)
                      throw Error(t.message || "Failed to load sorry data");
                    let a = t.data;
                    a.sessionId &&
                      ((0, j.mY)(a.sessionId),
                      (0, y.xf)(a.sessionId, e).catch(() => {}),
                      (0, y.MR)(a.sessionId).catch(() => {})),
                      (0, j.xS)(a),
                      d(a),
                      h(!1);
                  } catch (e) {
                    v.Cp(
                      e instanceof Error
                        ? e
                        : Error(String(e ?? "Load sorry card failed")),
                      {
                        tags: {
                          userAction: "load_sorry_card",
                          component: "TemplateReceiverPage",
                        },
                      }
                    ),
                      console.error("Error loading sorry card:", e),
                      w(e.message || "Failed to load sorry card"),
                      h(!1);
                  }
                })());
            }, [e]);
            let M = (e) => {
              a(e);
            };
            return p
              ? (0, s.jsx)("div", {
                  className: "template-receiver-page",
                  children: (0, s.jsxs)("div", {
                    className: "template-loading",
                    children: [
                      (0, s.jsx)("div", { className: "template-spinner" }),
                      (0, s.jsx)("p", {
                        children: "Preparing something special...",
                      }),
                    ],
                  }),
                })
              : x
              ? (0, s.jsx)("div", {
                  className: "template-receiver-page",
                  children: (0, s.jsxs)("div", {
                    className: "template-error",
                    children: [
                      (0, s.jsx)("h2", { children: "Oops" }),
                      (0, s.jsx)("p", { children: x }),
                      (0, s.jsx)("p", {
                        className: "template-error-hint",
                        children: "Please check the link and try again.",
                      }),
                    ],
                  }),
                })
              : (0, s.jsxs)("div", {
                  className: "template-receiver-page",
                  children: [
                    (0, s.jsx)(n, {}),
                    (0, s.jsxs)("div", {
                      className: "template-stage-wrapper",
                      children: [
                        1 === t &&
                          (0, s.jsx)(i, {
                            onNext: () => M(2),
                            recipientName: r?.recipientName || r?.userName,
                          }),
                        2 === t &&
                          (0, s.jsx)(c, {
                            config: k[0],
                            message: r?.[k[0].messageKey],
                            onNext: () => M(3),
                            onBack: () => M(1),
                          }),
                        3 === t &&
                          (0, s.jsx)(c, {
                            config: k[1],
                            message: r?.[k[1].messageKey],
                            onNext: () => M(4),
                            onBack: () => M(2),
                          }),
                        4 === t &&
                          (0, s.jsx)(c, {
                            config: k[2],
                            message: r?.[k[2].messageKey],
                            onNext: () => M(5),
                            onBack: () => M(3),
                          }),
                        5 === t &&
                          (0, s.jsx)(o, {
                            onOpen: () => M(6),
                            onBack: () => M(4),
                          }),
                        6 === t &&
                          (0, s.jsx)(m, {
                            sorryData: r,
                            onNext: () => M(7),
                            onBack: () => M(5),
                          }),
                        7 === t &&
                          (0, s.jsx)(u, {
                            onComplete: () => M(8),
                            onBack: () => M(6),
                          }),
                        8 === t &&
                          (0, s.jsx)(f, {
                            onNext: () => M(9),
                            onBack: () => M(7),
                          }),
                        9 === t &&
                          (0, s.jsx)(g, {
                            onReplay: () => M(1),
                            onBack: () => M(8),
                          }),
                      ],
                    }),
                  ],
                });
          };
        var I = a(3321);
        function M() {
          let e = (0, I.useParams)().code;
          return (0, s.jsx)(w, { shortCode: e });
        }
      },
      4266: () => {},
      5408: () => {},
      7139: () => {},
      7413: () => {},
      8165: (e, t, a) => {
        "use strict";
        a.d(t, { d: () => l });
        var s = a(2115);
        function l(e, t = 45, a = 0, r = !0) {
          let [n, i] = (0, s.useState)(""),
            [c, o] = (0, s.useState)(!1),
            d = (0, s.useRef)(null),
            m = (0, s.useRef)(null);
          return (
            (0, s.useEffect)(() => {
              if ((i(""), o(!1), r && e))
                return (
                  (m.current = setTimeout(() => {
                    let a = 0;
                    d.current = setInterval(() => {
                      a++,
                        i(e.slice(0, a)),
                        a >= e.length && (clearInterval(d.current), o(!0));
                    }, t);
                  }, a)),
                  () => {
                    clearTimeout(m.current), clearInterval(d.current);
                  }
                );
            }, [e, t, a, r]),
            {
              displayText: n,
              isComplete: c,
              skip: (0, s.useCallback)(() => {
                clearTimeout(m.current), clearInterval(d.current), i(e), o(!0);
              }, [e]),
            }
          );
        }
      },
      8617: () => {},
      9071: () => {},
    },
    (e) => {
      e.O(0, [278, 856, 441, 295, 358], () => e((e.s = 4066))), (_N_E = e.O());
    },
  ]);
