!(function () {
  try {
    var e =
        "u" > typeof window
          ? window
          : "u" > typeof global
          ? global
          : "u" > typeof globalThis
          ? globalThis
          : "u" > typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "a695c203-0bdd-4f50-a27f-5e127a76c5b6"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-a695c203-0bdd-4f50-a27f-5e127a76c5b6"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [219],
    {
      8: (e, n, t) => {
        "use strict";
        t.r(n), t.d(n, { default: () => l });
        var s = t(5155),
          i = t(1123),
          r = t(2115);
        function l({ error: e, reset: n }) {
          return (
            (0, r.useEffect)(() => {
              i.Cp(e);
            }, [e]),
            (0, s.jsx)("html", {
              children: (0, s.jsx)("body", {
                children: (0, s.jsx)("div", {
                  style: {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    minHeight: "100vh",
                    fontFamily: "sans-serif",
                  },
                  children: (0, s.jsxs)("div", {
                    style: { textAlign: "center" },
                    children: [
                      (0, s.jsx)("h2", { children: "Something went wrong" }),
                      (0, s.jsx)("button", {
                        onClick: () => n(),
                        style: {
                          marginTop: 16,
                          padding: "8px 24px",
                          cursor: "pointer",
                        },
                        children: "Try again",
                      }),
                    ],
                  }),
                }),
              }),
            })
          );
        }
      },
      3004: (e, n, t) => {
        Promise.resolve().then(t.bind(t, 8));
      },
    },
    (e) => {
      e.O(0, [441, 295, 358], () => e((e.s = 3004))), (_N_E = e.O());
    },
  ]);
