!(function () {
  try {
    var e =
        "u" > typeof window
          ? window
          : "u" > typeof global
          ? global
          : "u" > typeof globalThis
          ? globalThis
          : "u" > typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "361f4f80-1fc8-4acf-a0d5-d60d4a2e367d"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-361f4f80-1fc8-4acf-a0d5-d60d4a2e367d"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [177],
    {
      635: (e) => {
        e.exports = {
          style: {
            fontFamily: "'Dancing Script', 'Dancing Script Fallback'",
            fontStyle: "normal",
          },
          className: "__className_7c1fd4",
          variable: "__variable_7c1fd4",
        };
      },
      2177: (e) => {
        e.exports = {
          style: {
            fontFamily: "'Lobster', 'Lobster Fallback'",
            fontWeight: 400,
            fontStyle: "normal",
          },
          className: "__className_fe84a7",
          variable: "__variable_fe84a7",
        };
      },
      4862: (e, t, i) => {
        Promise.resolve().then(i.bind(i, 6335)),
          Promise.resolve().then(i.t.bind(i, 2593, 23)),
          Promise.resolve().then(i.t.bind(i, 8087, 23)),
          Promise.resolve().then(i.t.bind(i, 6328, 23)),
          Promise.resolve().then(i.t.bind(i, 6037, 23)),
          Promise.resolve().then(i.t.bind(i, 635, 23)),
          Promise.resolve().then(i.t.bind(i, 2177, 23)),
          Promise.resolve().then(i.t.bind(i, 6872, 23));
      },
      6037: (e) => {
        e.exports = {
          style: {
            fontFamily: "'Caveat', 'Caveat Fallback'",
            fontStyle: "normal",
          },
          className: "__className_694c5f",
          variable: "__variable_694c5f",
        };
      },
      6328: (e) => {
        e.exports = {
          style: {
            fontFamily: "'DM Serif Display', 'DM Serif Display Fallback'",
            fontWeight: 400,
            fontStyle: "normal",
          },
          className: "__className_0e4539",
          variable: "__variable_0e4539",
        };
      },
      6335: (e, t, i) => {
        "use strict";
        let r;
        i.d(t, { default: () => O });
        var n = i(2115);
        let a = -1,
          s = (e) => {
            addEventListener(
              "pageshow",
              (t) => {
                t.persisted && ((a = t.timeStamp), e(t));
              },
              !0
            );
          },
          l = (e, t, i, r) => {
            let n, a;
            return (s) => {
              let l;
              t.value >= 0 &&
                (s || r) &&
                ((a = t.value - (n ?? 0)) || void 0 === n) &&
                ((n = t.value),
                (t.delta = a),
                (l = t.value),
                (t.rating =
                  l > i[1] ? "poor" : l > i[0] ? "needs-improvement" : "good"),
                e(t));
            };
          },
          o = (e) => {
            requestAnimationFrame(() => requestAnimationFrame(e));
          },
          d = () => {
            let e = performance.getEntriesByType("navigation")[0];
            if (e && e.responseStart > 0 && e.responseStart < performance.now())
              return e;
          },
          c = () => d()?.activationStart ?? 0,
          m = (e, t = -1) => {
            let i = d(),
              r = "navigate";
            return (
              a >= 0
                ? (r = "back-forward-cache")
                : i &&
                  (document.prerendering || c() > 0
                    ? (r = "prerender")
                    : document.wasDiscarded
                    ? (r = "restore")
                    : i.type && (r = i.type.replace(/_/g, "-"))),
              {
                name: e,
                value: t,
                rating: "good",
                delta: 0,
                entries: [],
                id: `v5-${Date.now()}-${
                  Math.floor(0x82f79cd8fff * Math.random()) + 1e12
                }`,
                navigationType: r,
              }
            );
          },
          f = new WeakMap();
        function u(e, t) {
          return f.get(e) || f.set(e, new t()), f.get(e);
        }
        class h {
          t;
          i = 0;
          o = [];
          h(e) {
            if (e.hadRecentInput) return;
            let t = this.o[0],
              i = this.o.at(-1);
            this.i &&
            t &&
            i &&
            e.startTime - i.startTime < 1e3 &&
            e.startTime - t.startTime < 5e3
              ? ((this.i += e.value), this.o.push(e))
              : ((this.i = e.value), (this.o = [e])),
              this.t?.(e);
          }
        }
        let p = (e, t, i = {}) => {
            try {
              if (PerformanceObserver.supportedEntryTypes.includes(e)) {
                let r = new PerformanceObserver((e) => {
                  queueMicrotask(() => {
                    t(e.getEntries());
                  });
                });
                return r.observe({ type: e, buffered: !0, ...i }), r;
              }
            } catch {}
          },
          v = (e) => {
            let t = !1;
            return () => {
              t || (e(), (t = !0));
            };
          },
          g = -1,
          b = new Set(),
          y = () =>
            "hidden" !== document.visibilityState || document.prerendering
              ? 1 / 0
              : 0,
          T = (e) => {
            if ("hidden" === document.visibilityState) {
              if ("visibilitychange" === e.type) for (let e of b) e();
              isFinite(g) ||
                ((g = "visibilitychange" === e.type ? e.timeStamp : 0),
                removeEventListener("prerenderingchange", T, !0));
            }
          },
          _ = () => {
            if (g < 0) {
              let e = c();
              (g =
                (document.prerendering
                  ? void 0
                  : globalThis.performance
                      .getEntriesByType("visibility-state")
                      .find((t) => "hidden" === t.name && t.startTime >= e)
                      ?.startTime) ?? y()),
                addEventListener("visibilitychange", T, !0),
                addEventListener("prerenderingchange", T, !0),
                s(() => {
                  setTimeout(() => {
                    g = y();
                  });
                });
            }
            return {
              get firstHiddenTime() {
                return g;
              },
              onHidden(e) {
                b.add(e);
              },
            };
          },
          C = (e) => {
            document.prerendering
              ? addEventListener("prerenderingchange", e, !0)
              : e();
          },
          L = [1800, 3e3],
          S = (e, t = {}) => {
            C(() => {
              let i = _(),
                r,
                n = m("FCP"),
                a = p("paint", (e) => {
                  for (let t of e)
                    "first-contentful-paint" === t.name &&
                      (a.disconnect(),
                      t.startTime < i.firstHiddenTime &&
                        ((n.value = Math.max(t.startTime - c(), 0)),
                        n.entries.push(t),
                        r(!0)));
                });
              a &&
                ((r = l(e, n, L, t.reportAllChanges)),
                s((i) => {
                  (r = l(e, (n = m("FCP")), L, t.reportAllChanges)),
                    o(() => {
                      (n.value = performance.now() - i.timeStamp), r(!0);
                    });
                }));
            });
          },
          E = [0.1, 0.25],
          k = 0,
          w = 1 / 0,
          I = 0,
          P = (e) => {
            for (let t of e)
              t.interactionId &&
                ((w = Math.min(w, t.interactionId)),
                (k = (I = Math.max(I, t.interactionId)) ? (I - w) / 7 + 1 : 0));
          },
          F = () => (r ? k : performance.interactionCount ?? 0),
          M = 0;
        class N {
          l = [];
          u = new Map();
          m;
          p;
          v() {
            (M = F()), (this.l.length = 0), this.u.clear();
          }
          T() {
            let e = Math.min(this.l.length - 1, Math.floor((F() - M) / 50));
            return this.l[e];
          }
          h(e) {
            if (
              (this.m?.(e), !e.interactionId && "first-input" !== e.entryType)
            )
              return;
            let t = this.l.at(-1),
              i = this.u.get(e.interactionId);
            if (i || this.l.length < 10 || e.duration > t.L) {
              if (
                (i
                  ? e.duration > i.L
                    ? ((i.entries = [e]), (i.L = e.duration))
                    : e.duration === i.L &&
                      e.startTime === i.entries[0].startTime &&
                      i.entries.push(e)
                  : ((i = { id: e.interactionId, entries: [e], L: e.duration }),
                    this.u.set(i.id, i),
                    this.l.push(i)),
                this.l.sort((e, t) => t.L - e.L),
                this.l.length > 10)
              )
                for (let e of this.l.splice(10)) this.u.delete(e.id);
              this.p?.(i);
            }
          }
        }
        let A = (e) => {
            let t = globalThis.requestIdleCallback || setTimeout,
              i = globalThis.cancelIdleCallback || clearTimeout;
            if ("hidden" === document.visibilityState) e();
            else {
              let r = v(e),
                n = -1,
                a = () => {
                  i(n), r();
                };
              addEventListener("visibilitychange", a, {
                once: !0,
                capture: !0,
              }),
                (n = t(() => {
                  removeEventListener("visibilitychange", a, { capture: !0 }),
                    r();
                }));
            }
          },
          D = [200, 500];
        class x {
          m;
          h(e) {
            this.m?.(e);
          }
        }
        let $ = [2500, 4e3],
          H = [800, 1800],
          q = (e) => {
            document.prerendering
              ? C(() => q(e))
              : "complete" !== document.readyState
              ? addEventListener("load", () => q(e), !0)
              : setTimeout(e);
          };
        function B(e) {
          let t =
            "good" === e.rating
              ? "\uD83D\uDFE2"
              : "needs-improvement" === e.rating
              ? "\uD83D\uDFE1"
              : "\uD83D\uDD34";
          console.log(
            `[WebVitals] ${t} ${e.name}: ${Math.round(e.value)}${
              "CLS" === e.name ? "" : "ms"
            } (${e.rating})`
          );
        }
        function O() {
          return (
            (0, n.useEffect)(() => {
              S(B),
                ((e, t = {}) => {
                  C(() => {
                    let i = _(),
                      r,
                      n = m("LCP"),
                      a = u(t, x),
                      d = (e) => {
                        for (let s of (t.reportAllChanges || (e = e.slice(-1)),
                        e))
                          a.h(s),
                            s.startTime < i.firstHiddenTime &&
                              ((n.value = Math.max(s.startTime - c(), 0)),
                              (n.entries = [s]),
                              r());
                      },
                      f = p("largest-contentful-paint", d);
                    if (f) {
                      r = l(e, n, $, t.reportAllChanges);
                      let i = v(() => {
                          d(f.takeRecords()), f.disconnect(), r(!0);
                        }),
                        a = (e) => {
                          e.isTrusted &&
                            (A(i),
                            removeEventListener(e.type, a, { capture: !0 }));
                        };
                      for (let e of ["keydown", "click", "visibilitychange"])
                        addEventListener(e, a, { capture: !0 });
                      s((i) => {
                        (r = l(e, (n = m("LCP")), $, t.reportAllChanges)),
                          o(() => {
                            (n.value = performance.now() - i.timeStamp), r(!0);
                          });
                      });
                    }
                  });
                })(B),
                ((e, t = {}) => {
                  let i = _();
                  S(
                    v(() => {
                      let r,
                        n = m("CLS", 0),
                        a = u(t, h),
                        d = (e) => {
                          for (let t of e) a.h(t);
                          a.i > n.value &&
                            ((n.value = a.i), (n.entries = a.o), r());
                        },
                        c = p("layout-shift", d);
                      c &&
                        ((r = l(e, n, E, t.reportAllChanges)),
                        i.onHidden(() => {
                          d(c.takeRecords()), r(!0);
                        }),
                        s(() => {
                          (a.i = 0),
                            o(
                              (r = l(
                                e,
                                (n = m("CLS", 0)),
                                E,
                                t.reportAllChanges
                              ))
                            );
                        }),
                        setTimeout(r));
                    })
                  );
                })(B),
                ((e, t = {}) => {
                  if (
                    !globalThis.PerformanceEventTiming ||
                    !("interactionId" in PerformanceEventTiming.prototype)
                  )
                    return;
                  let i = _();
                  C(() => {
                    "interactionCount" in performance ||
                      r ||
                      (r = p("event", P, { durationThreshold: 0 }));
                    let n,
                      a = m("INP"),
                      o = u(t, N),
                      d = (e) => {
                        A(() => {
                          for (let t of e) o.h(t);
                          let t = o.T();
                          t &&
                            t.L !== a.value &&
                            ((a.value = t.L), (a.entries = t.entries), n());
                        });
                      },
                      c = p("event", d, {
                        durationThreshold: t.durationThreshold ?? 40,
                      });
                    (n = l(e, a, D, t.reportAllChanges)),
                      c &&
                        (c.observe({ type: "first-input", buffered: !0 }),
                        i.onHidden(() => {
                          d(c.takeRecords()), n(!0);
                        }),
                        s(() => {
                          o.v(),
                            (n = l(e, (a = m("INP")), D, t.reportAllChanges));
                        }));
                  });
                })(B),
                ((e, t = {}) => {
                  let i = m("TTFB"),
                    r = l(e, i, H, t.reportAllChanges);
                  q(() => {
                    let n = d();
                    n &&
                      ((i.value = Math.max(n.responseStart - c(), 0)),
                      (i.entries = [n]),
                      r(!0),
                      s(() => {
                        (r = l(e, (i = m("TTFB", 0)), H, t.reportAllChanges))(
                          !0
                        );
                      }));
                  });
                })(B);
            }, []),
            null
          );
        }
      },
      6872: () => {},
      8087: (e) => {
        e.exports = {
          style: {
            fontFamily: "'Inter', 'Inter Fallback'",
            fontStyle: "normal",
          },
          className: "__className_04b02f",
          variable: "__variable_04b02f",
        };
      },
    },
    (e) => {
      e.O(0, [726, 441, 295, 358], () => e((e.s = 4862))), (_N_E = e.O());
    },
  ]);
