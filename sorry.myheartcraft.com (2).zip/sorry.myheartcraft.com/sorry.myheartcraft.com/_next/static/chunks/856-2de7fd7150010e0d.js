!(function () {
  try {
    var e =
        "u" > typeof window
          ? window
          : "u" > typeof global
          ? global
          : "u" > typeof globalThis
          ? globalThis
          : "u" > typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "82748488-88ff-4c2d-b37e-30c1d28793f8"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-82748488-88ff-4c2d-b37e-30c1d28793f8"));
  } catch (e) {}
})();
("use strict");
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [856],
  {
    2748: (e, t, r) => {
      r.d(t, { a: () => i });
      var n = r(1123);
      async function i(e, t, r = {}) {
        let a;
        try {
          a = await fetch(e, t);
        } catch (t) {
          return (
            n.Cp(t, {
              tags: {
                userAction: "fetch_network_error",
                url: String(e),
                ...(r.context?.userAction
                  ? { userAction: r.context.userAction }
                  : {}),
              },
            }),
            null
          );
        }
        if (!a.ok) {
          let t = 404 === a.status,
            i = String(e),
            o = /\/api\/session\//.test(i);
          (t && o) ||
            n.Cp(Error(`HTTP ${a.status} ${a.statusText} — ${i}`), {
              level: a.status >= 500 ? "error" : "warning",
              tags: {
                userAction: r.context?.userAction || "fetch_http_error",
                httpStatus: a.status,
                url: i,
              },
            });
        }
        return a;
      }
    },
    4572: (e, t, r) => {
      r.d(t, { mY: () => u, rm: () => s, u0: () => c, xS: () => l });
      let n = "sorry_session_id",
        i = {};
      function a(e) {
        try {
          return localStorage.getItem(e);
        } catch {
          return i[e] ?? null;
        }
      }
      function o(e, t) {
        try {
          localStorage.setItem(e, t);
        } catch {
          i[e] = t;
        }
      }
      function s() {
        let e = a(n);
        return (
          e ||
            o(
              n,
              (e =
                crypto.randomUUID?.() ||
                `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`)
            ),
          e
        );
      }
      function c() {
        return a(n);
      }
      function u(e) {
        o(n, e);
      }
      function l(e) {
        o("sorry_data", JSON.stringify(e));
      }
    },
    5864: (e, t, r) => {
      r.d(t, {
        $d: () => l,
        Al: () => u,
        MR: () => s,
        NF: () => d,
        xf: () => c,
      });
      var n = r(2748);
      let i = {};
      function a() {
        let e = (function (e) {
          try {
            return localStorage.getItem(e);
          } catch {
            return i[e] ?? null;
          }
        })("sorry_device_id");
        if (!e) {
          e =
            crypto.randomUUID?.() ||
            `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
          var t = "sorry_device_id",
            r = e;
          try {
            localStorage.setItem(t, r);
          } catch {
            i[t] = r;
          }
        }
        return e;
      }
      let o = !1;
      async function s(e) {
        let t, r, n;
        if (!e) return null;
        if (o)
          return (
            console.debug("Session tracking already in progress, skipping"),
            null
          );
        o = !0;
        let i = (function () {
            let e = document.referrer;
            if (!e) return { source: "direct", medium: "direct" };
            try {
              let t = new URL(e).hostname.toLowerCase();
              if (t.includes("instagram") || t.includes("l.instagram"))
                return { url: e, source: "instagram", medium: "social" };
              if (t.includes("whatsapp") || t.includes("wa.me"))
                return { url: e, source: "whatsapp", medium: "social" };
              if (
                t.includes("facebook") ||
                t.includes("fb.com") ||
                t.includes("fb.me")
              )
                return { url: e, source: "facebook", medium: "social" };
              if (
                t.includes("twitter") ||
                t.includes("t.co") ||
                t.includes("x.com")
              )
                return { url: e, source: "twitter", medium: "social" };
              if (t.includes("google"))
                return { url: e, source: "google", medium: "organic" };
              if (t.includes("t.me") || t.includes("telegram"))
                return { url: e, source: "telegram", medium: "social" };
              return { url: e, source: "other", medium: "referral" };
            } catch {
              return { source: "direct", medium: "direct" };
            }
          })(),
          s =
            (r = (t = new URLSearchParams(window.location.search)).get(
              "source"
            )) || t.get("utm_campaign"),
          c =
            (n = new URLSearchParams(window.location.search)).get("userId") ||
            n.get("user_id") ||
            null;
        try {
          let t = JSON.stringify({
              sessionId: e,
              deviceId: a(),
              landingUrl: window.location.href,
              referrer: { ...i, campaign: s, ...(c ? { userId: c } : {}) },
              deviceInfo: (function () {
                if ("u" < typeof navigator)
                  return {
                    os: "Unknown",
                    osVersion: "",
                    browser: "Unknown",
                    browserVersion: "",
                    deviceType: "desktop",
                    model: "",
                    userAgent: "",
                  };
                let e = navigator.userAgent,
                  t = "Unknown",
                  r = "",
                  n = "";
                if (/iPhone/i.test(e)) {
                  (t = "iOS"), (n = "iPhone");
                  let i = e.match(/OS ([\d_]+)/);
                  i && (r = i[1].replace(/_/g, "."));
                } else if (/iPad/i.test(e)) {
                  (t = "iOS"), (n = "iPad");
                  let i = e.match(/OS ([\d_]+)/);
                  i && (r = i[1].replace(/_/g, "."));
                } else if (/Android/i.test(e)) {
                  t = "Android";
                  let i = e.match(/Android ([\d.]+)/);
                  i && (r = i[1]);
                  let a = e.match(/Android[\d.\s]+;\s*([^;)]+)/);
                  a && (n = a[1].trim());
                } else if (/Windows NT/i.test(e)) {
                  t = "Windows";
                  let n = e.match(/Windows NT ([\d.]+)/);
                  n &&
                    (r =
                      { "10.0": "10/11", 6.3: "8.1", 6.2: "8", 6.1: "7" }[
                        n[1]
                      ] || n[1]);
                } else if (/Mac OS X/i.test(e)) {
                  t = "macOS";
                  let n = e.match(/Mac OS X ([\d_]+)/);
                  n && (r = n[1].replace(/_/g, "."));
                } else /Linux/i.test(e) && (t = "Linux");
                let i = "Unknown",
                  a = "";
                /SamsungBrowser\/([\d.]+)/i.test(e)
                  ? ((i = "Samsung Internet"),
                    (a = e.match(/SamsungBrowser\/([\d.]+)/i)?.[1] || ""))
                  : /OPR\/([\d.]+)/i.test(e)
                  ? ((i = "Opera"), (a = e.match(/OPR\/([\d.]+)/i)?.[1] || ""))
                  : /EdgA?\/([\d.]+)/i.test(e)
                  ? ((i = "Edge"), (a = e.match(/EdgA?\/([\d.]+)/i)?.[1] || ""))
                  : /FxiOS\/([\d.]+)/i.test(e)
                  ? ((i = "Firefox"),
                    (a = e.match(/FxiOS\/([\d.]+)/i)?.[1] || ""))
                  : /Firefox\/([\d.]+)/i.test(e)
                  ? ((i = "Firefox"),
                    (a = e.match(/Firefox\/([\d.]+)/i)?.[1] || ""))
                  : /CriOS\/([\d.]+)/i.test(e)
                  ? ((i = "Chrome (iOS)"),
                    (a = e.match(/CriOS\/([\d.]+)/i)?.[1] || ""))
                  : /Chrome\/([\d.]+)/i.test(e)
                  ? ((i = "Chrome"),
                    (a = e.match(/Chrome\/([\d.]+)/i)?.[1] || ""))
                  : /Version\/([\d.]+).*Safari/i.test(e)
                  ? ((i = "Safari"),
                    (a = e.match(/Version\/([\d.]+)/i)?.[1] || ""))
                  : /FBAV\/|FBAN\//i.test(e)
                  ? (i = "Facebook In-App")
                  : /Instagram\//i.test(e) && (i = "Instagram In-App");
                let o = "desktop";
                return (
                  /iPad/i.test(e)
                    ? (o = "tablet")
                    : /Mobi|Android|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
                        e
                      ) && (o = "mobile"),
                  {
                    os: t,
                    osVersion: r,
                    browser: i,
                    browserVersion: a,
                    deviceType: o,
                    model: n,
                    userAgent: e,
                  }
                );
              })(),
            }),
            r = await fetch("/api/analytics/session", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: t,
            });
          if (r.ok) return await r.json();
          return null;
        } catch (e) {
          return console.debug("Analytics session tracking failed:", e), null;
        } finally {
          o = !1;
        }
      }
      async function c(e, t) {
        if (!e || !t) return;
        let r = document.referrer ? "referred" : "direct";
        try {
          await (0, n.a)(
            "/api/analytics/share",
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                sessionId: e,
                deviceId: a(),
                shortCode: t,
                shareType: r,
              }),
            },
            {
              context: {
                userAction: "analytics_share",
                errorCode: "ANALYTICS_SHARE_FAILED",
              },
            }
          );
        } catch (e) {
          console.debug("Analytics share tracking failed:", e);
        }
      }
      async function u(e, t, r) {
        if (e && t && r)
          try {
            await (0, n.a)(
              "/api/analytics/url-copy",
              {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  sessionId: e,
                  deviceId: a(),
                  shortCode: t,
                  url: r,
                }),
              },
              {
                context: {
                  userAction: "analytics_url_copy",
                  errorCode: "ANALYTICS_URL_COPY_FAILED",
                },
              }
            );
          } catch (e) {
            console.debug("Analytics URL copy tracking failed:", e);
          }
      }
      async function l(e, t) {
        if (e && t && 0 !== t.length)
          try {
            await (0, n.a)(
              "/api/analytics/user-interaction",
              {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  sessionId: e,
                  deviceId: a(),
                  interactions: t,
                }),
              },
              {
                context: {
                  userAction: "analytics_user_interaction",
                  errorCode: "ANALYTICS_INTERACTION_FAILED",
                },
              }
            );
          } catch (e) {
            console.debug("Analytics user interaction tracking failed:", e);
          }
      }
      async function d(e, t, r) {
        if (t && e)
          try {
            await (0, n.a)("/api/analytics/user-interaction", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                sessionId: t,
                deviceId: a(),
                interactions: [
                  {
                    interactionType: "QR_CARD_ACTION",
                    fieldName: e,
                    fieldValue: r || "",
                    previousValue: null,
                  },
                ],
              }),
            });
          } catch (e) {
            console.debug("Analytics QR card action tracking failed:", e);
          }
      }
    },
    8713: (e, t, r) => {
      function n(e) {
        try {
          return localStorage.getItem(e);
        } catch {
          return null;
        }
      }
      function i(e, t) {
        try {
          localStorage.setItem(e, t);
        } catch {}
      }
      function a(e) {
        try {
          localStorage.removeItem(e);
        } catch {}
      }
      r.d(t, { FX: () => i, Pw: () => a, bi: () => n });
    },
    9076: (e, t, r) => {
      r.d(t, {
        $L: () => u,
        GE: () => l,
        G_: () => h,
        Jv: () => d,
        KF: () => c,
        aw: () => g,
        eO: () => p,
        gb: () => y,
        h4: () => s,
        lD: () => f,
        mY: () => o,
        pF: () => m,
        pl: () => S,
      });
      var n = r(1123),
        i = r(2748);
      async function a(e, t = {}) {
        let r = new AbortController(),
          o = setTimeout(() => r.abort(), 2e4);
        try {
          let n = await (0, i.a)(
            `${e}`,
            {
              headers: { "Content-Type": "application/json", ...t.headers },
              ...t,
              signal: r.signal,
            },
            {
              context: {
                componentName: "API",
                userAction: `api_${e}`,
                errorCode: "API_CALL_FAILED",
              },
            }
          );
          if (!n)
            return {
              success: !1,
              message: "Network error occurred",
              data: null,
            };
          let a = await n.text();
          if (!a)
            return {
              success: !1,
              message: n.ok
                ? "Empty response from server"
                : `Server error (${n.status})`,
              status: n.status,
              data: null,
            };
          try {
            return JSON.parse(a);
          } catch {
            return {
              success: !1,
              message: n.ok
                ? "Invalid JSON response"
                : `Server error (${n.status})`,
              status: n.status,
              data: null,
            };
          }
        } catch (r) {
          let t = "AbortError" === r.name;
          return (
            t &&
              n.Cp(r, {
                tags: {
                  userAction: "api_timeout",
                  endpoint: e,
                  errorCode: "API_TIMEOUT",
                },
              }),
            console.error(`API call failed${t ? " (timeout)" : ""}:`, e, r),
            {
              success: !1,
              message: t
                ? "Request timed out — please check your connection"
                : r.message || "Network error occurred",
              data: null,
            }
          );
        } finally {
          clearTimeout(o);
        }
      }
      async function o() {
        return a("/api/price");
      }
      async function s(e, t) {
        return a("/api/session/register", {
          method: "POST",
          body: JSON.stringify({
            sessionId: e,
            userName: t.recipientName,
            ...t,
          }),
        });
      }
      async function c(e) {
        return a("/api/payment/verify", {
          method: "POST",
          body: JSON.stringify(e),
        });
      }
      async function u(e, t) {
        return a("/api/razorpay/checkout", {
          method: "POST",
          body: JSON.stringify({ sessionId: e, userName: t }),
        });
      }
      async function l(e) {
        return a("/api/razorpay/verify", {
          method: "POST",
          body: JSON.stringify(e),
        });
      }
      async function d(e) {
        return a("/api/url/generate", {
          method: "POST",
          body: JSON.stringify({ sessionId: e }),
        });
      }
      async function f(e) {
        try {
          let t = await fetch(`/api/session/${e}`, {
            headers: { "Content-Type": "application/json" },
          });
          if (!t.ok)
            return {
              success: !1,
              message: `Server error (${t.status})`,
              data: null,
            };
          let r = await t.text();
          if (!r)
            return {
              success: !1,
              message: "Empty response from server",
              data: null,
            };
          return JSON.parse(r);
        } catch (e) {
          return (
            console.debug("Session status check failed:", e),
            { success: !1, message: e.message || "Network error", data: null }
          );
        }
      }
      async function y(e) {
        return a(`/api/url/resolve/${e}`);
      }
      async function m(e, t, r) {
        return a("/api/paytm/pay", {
          method: "POST",
          body: JSON.stringify({ sessionId: e, targetApp: t, deviceOS: r }),
        });
      }
      async function p(e) {
        return a(`/api/paytm/status/${encodeURIComponent(e)}`);
      }
      async function g(e, t) {
        return a("/api/paytm/validate-vpa", {
          method: "POST",
          body: JSON.stringify({ sessionId: e, vpa: t }),
        });
      }
      async function h(e, t) {
        return a("/api/paytm/collect", {
          method: "POST",
          body: JSON.stringify({ sessionId: e, vpa: t }),
        });
      }
      async function S(e, t) {
        return a("/api/phone/collect", {
          method: "POST",
          body: JSON.stringify({ sessionId: e, phoneNumber: t }),
        });
      }
    },
  },
]);
