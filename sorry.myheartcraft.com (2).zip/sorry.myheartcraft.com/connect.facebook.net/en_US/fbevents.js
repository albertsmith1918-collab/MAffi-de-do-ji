/**
 * Copyright (c) 2017-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to use,
 * copy, modify, and distribute this software in source code or binary form for use
 * in connection with the web services and APIs provided by Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use of
 * this software is subject to the Facebook Platform Policy
 * [http://developers.facebook.com/policy/]. This copyright notice shall be
 * included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
fbq.version = "2.9.313";
fbq._releaseSegment = "stable";
fbq.pendingConfigs = ["global_config"];
fbq.__openBridgeRollout = 1.0;
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    if (
      ((a.execStart =
        e.performance && e.performance.now && e.performance.now()),
      !(function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })())
    )
      return;
    function i(e, t, n) {
      return (
        (t = f(t)),
        l(
          e,
          m() ? Reflect.construct(t, n || [], f(e).constructor) : t.apply(e, n)
        )
      );
    }
    function l(e, t) {
      if (t && (G(t) == "object" || typeof t == "function")) return t;
      if (t !== void 0)
        throw new TypeError(
          "Derived constructors may only return object or undefined"
        );
      return s(e);
    }
    function s(e) {
      if (e === void 0)
        throw new ReferenceError(
          "this hasn't been initialised - super() hasn't been called"
        );
      return e;
    }
    function u(e, t) {
      if (typeof t != "function" && t !== null)
        throw new TypeError(
          "Super expression must either be null or a function"
        );
      (e.prototype = Object.create(t && t.prototype, {
        constructor: { value: e, writable: !0, configurable: !0 },
      })),
        Object.defineProperty(e, "prototype", { writable: !1 }),
        t && _(e, t);
    }
    function c(e) {
      var t = typeof Map == "function" ? new Map() : void 0;
      return (
        (c = function (n) {
          if (n === null || !p(n)) return n;
          if (typeof n != "function")
            throw new TypeError(
              "Super expression must either be null or a function"
            );
          if (t !== void 0) {
            if (t.has(n)) return t.get(n);
            t.set(n, e);
          }
          function e() {
            return d(n, arguments, f(this).constructor);
          }
          return (
            (e.prototype = Object.create(n.prototype, {
              constructor: {
                value: e,
                enumerable: !1,
                writable: !0,
                configurable: !0,
              },
            })),
            _(e, n)
          );
        }),
        c(e)
      );
    }
    function d(e, t, n) {
      if (m()) return Reflect.construct.apply(null, arguments);
      var r = [null];
      r.push.apply(r, t);
      var o = new (e.bind.apply(e, r))();
      return n && _(o, n.prototype), o;
    }
    function m() {
      try {
        var e = !Boolean.prototype.valueOf.call(
          Reflect.construct(Boolean, [], function () {})
        );
      } catch (e) {}
      return (m = function () {
        return !!e;
      })();
    }
    function p(e) {
      try {
        return Function.toString.call(e).indexOf("[native code]") !== -1;
      } catch (t) {
        return typeof e == "function";
      }
    }
    function _(e, t) {
      return (
        (_ = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (e, t) {
              return (e.__proto__ = t), e;
            }),
        _(e, t)
      );
    }
    function f(e) {
      return (
        (f = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (e) {
              return e.__proto__ || Object.getPrototypeOf(e);
            }),
        f(e)
      );
    }
    function g() {
      var e,
        t,
        n = typeof Symbol == "function" ? Symbol : {},
        r = n.iterator || "@@iterator",
        o = n.toStringTag || "@@toStringTag";
      function a(n, r, o, a) {
        var s = r && r.prototype instanceof l ? r : l,
          u = Object.create(s.prototype);
        return (
          h(
            u,
            "_invoke",
            (function (n, r, o) {
              var a,
                l,
                s,
                u = 0,
                c = o || [],
                d = !1,
                m = {
                  p: 0,
                  n: 0,
                  v: e,
                  a: p,
                  f: p.bind(e, 4),
                  d: function (n, r) {
                    return (a = n), (l = 0), (s = e), (m.n = r), i;
                  },
                };
              function p(n, r) {
                for (l = n, s = r, t = 0; !d && u && !o && t < c.length; t++) {
                  var o,
                    a = c[t],
                    p = m.p,
                    _ = a[2];
                  n > 3
                    ? (o = _ === r) &&
                      ((s = a[(l = a[4]) ? 5 : ((l = 3), 3)]),
                      (a[4] = a[5] = e))
                    : a[0] <= p &&
                      ((o = n < 2 && p < a[1])
                        ? ((l = 0), (m.v = r), (m.n = a[1]))
                        : p < _ &&
                          (o = n < 3 || a[0] > r || r > _) &&
                          ((a[4] = n), (a[5] = r), (m.n = _), (l = 0)));
                }
                if (o || n > 1) return i;
                throw ((d = !0), r);
              }
              return function (o, c, _) {
                if (u > 1) throw TypeError("Generator is already running");
                for (
                  d && c === 1 && p(c, _), l = c, s = _;
                  (t = l < 2 ? e : s) || !d;

                ) {
                  a ||
                    (l
                      ? l < 3
                        ? (l > 1 && (m.n = -1), p(l, s))
                        : (m.n = s)
                      : (m.v = s));
                  try {
                    if (((u = 2), a)) {
                      if ((l || (o = "next"), (t = a[o]))) {
                        if (!(t = t.call(a, s)))
                          throw TypeError("iterator result is not an object");
                        if (!t.done) return t;
                        (s = t.value), l < 2 && (l = 0);
                      } else
                        l === 1 && (t = a.return) && t.call(a),
                          l < 2 &&
                            ((s = TypeError(
                              "The iterator does not provide a '" +
                                o +
                                "' method"
                            )),
                            (l = 1));
                      a = e;
                    } else if ((t = (d = m.n < 0) ? s : n.call(r, m)) !== i)
                      break;
                  } catch (t) {
                    (a = e), (l = 1), (s = t);
                  } finally {
                    u = 1;
                  }
                }
                return { value: t, done: d };
              };
            })(n, o, a),
            !0
          ),
          u
        );
      }
      var i = {};
      function l() {}
      function s() {}
      function u() {}
      t = Object.getPrototypeOf;
      var c = [][r]
          ? t(t([][r]()))
          : (h((t = {}), r, function () {
              return this;
            }),
            t),
        d = (u.prototype = l.prototype = Object.create(c));
      function m(e) {
        return (
          Object.setPrototypeOf
            ? Object.setPrototypeOf(e, u)
            : ((e.__proto__ = u), h(e, o, "GeneratorFunction")),
          (e.prototype = Object.create(d)),
          e
        );
      }
      return (
        (s.prototype = u),
        h(d, "constructor", u),
        h(u, "constructor", s),
        (s.displayName = "GeneratorFunction"),
        h(u, o, "GeneratorFunction"),
        h(d),
        h(d, o, "Generator"),
        h(d, r, function () {
          return this;
        }),
        h(d, "toString", function () {
          return "[object Generator]";
        }),
        (g = function () {
          return { w: a, m: m };
        })()
      );
    }
    function h(e, t, n, r) {
      var o = Object.defineProperty;
      try {
        o({}, "", {});
      } catch (e) {
        o = 0;
      }
      (h = function (t, n, r, a) {
        function e(e, n) {
          h(t, e, function (t) {
            return this._invoke(e, n, t);
          });
        }
        n
          ? o
            ? o(t, n, {
                value: r,
                enumerable: !a,
                configurable: !a,
                writable: !a,
              })
            : (t[n] = r)
          : (e("next", 0), e("throw", 1), e("return", 2));
      }),
        h(e, t, n, r);
    }
    function y(e, t, n, r, o, a, i) {
      try {
        var l = e[a](i),
          s = l.value;
      } catch (e) {
        return void n(e);
      }
      l.done ? t(s) : Promise.resolve(s).then(r, o);
    }
    function C(e) {
      return function () {
        var t = this,
          n = arguments;
        return new Promise(function (r, o) {
          var a = e.apply(t, n);
          function i(e) {
            y(a, r, o, i, l, "next", e);
          }
          function l(e) {
            y(a, r, o, i, l, "throw", e);
          }
          i(void 0);
        });
      };
    }
    function b(e, t) {
      var n = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t &&
          (r = r.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })),
          n.push.apply(n, r);
      }
      return n;
    }
    function v(e) {
      for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {};
        t % 2
          ? b(Object(n), !0).forEach(function (t) {
              S(e, t, n[t]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
          : b(Object(n)).forEach(function (t) {
              Object.defineProperty(
                e,
                t,
                Object.getOwnPropertyDescriptor(n, t)
              );
            });
      }
      return e;
    }
    function S(e, t, n) {
      return (
        (t = M(t)) in e
          ? Object.defineProperty(e, t, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (e[t] = n),
        e
      );
    }
    function R(e, t) {
      return k(e) || E(e, t) || V(e, t) || L();
    }
    function L() {
      throw new TypeError(
        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
      );
    }
    function E(e, t) {
      var n =
        e == null
          ? null
          : (typeof Symbol != "undefined" &&
              e[
                typeof Symbol == "function" ? Symbol.iterator : "@@iterator"
              ]) ||
            e["@@iterator"];
      if (n != null) {
        var r,
          o,
          a,
          i,
          l = [],
          s = !0,
          u = !1;
        try {
          if (((a = (n = n.call(e)).next), t === 0)) {
            if (Object(n) !== n) return;
            s = !1;
          } else
            for (
              ;
              !(s = (r = a.call(n)).done) && (l.push(r.value), l.length !== t);
              s = !0
            );
        } catch (e) {
          (u = !0), (o = e);
        } finally {
          try {
            if (!s && n.return != null && ((i = n.return()), Object(i) !== i))
              return;
          } finally {
            if (u) throw o;
          }
        }
        return l;
      }
    }
    function k(e) {
      if (Array.isArray(e)) return e;
    }
    function I(e) {
      return x(e) || D(e) || V(e) || T();
    }
    function T() {
      throw new TypeError(
        "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
      );
    }
    function D(e) {
      if (
        (typeof Symbol != "undefined" &&
          e[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] !=
            null) ||
        e["@@iterator"] != null
      )
        return Array.from(e);
    }
    function x(e) {
      if (Array.isArray(e)) return H(e);
    }
    function $(e, t) {
      if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function");
    }
    function P(e, t) {
      for (var n = 0; n < t.length; n++) {
        var r = t[n];
        (r.enumerable = r.enumerable || !1),
          (r.configurable = !0),
          "value" in r && (r.writable = !0),
          Object.defineProperty(e, M(r.key), r);
      }
    }
    function N(e, t, n) {
      return (
        t && P(e.prototype, t),
        n && P(e, n),
        Object.defineProperty(e, "prototype", { writable: !1 }),
        e
      );
    }
    function M(e) {
      var t = w(e, "string");
      return G(t) == "symbol" ? t : t + "";
    }
    function w(e, t) {
      if (G(e) != "object" || !e) return e;
      var n =
        e[typeof Symbol == "function" ? Symbol.toPrimitive : "@@toPrimitive"];
      if (n !== void 0) {
        var r = n.call(e, t || "default");
        if (G(r) != "object") return r;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return (t === "string" ? String : Number)(e);
    }
    function A(e, t) {
      O(e, t), t.add(e);
    }
    function F(e, t, n) {
      O(e, t), t.set(e, n);
    }
    function O(e, t) {
      if (t.has(e))
        throw new TypeError(
          "Cannot initialize the same private elements twice on an object"
        );
    }
    function B(e, t) {
      return e.get(q(e, t));
    }
    function W(e, t, n) {
      return e.set(q(e, t), n), n;
    }
    function q(e, t, n) {
      if (typeof e == "function" ? e === t : e.has(t))
        return arguments.length < 3 ? t : n;
      throw new TypeError("Private element is not present on this object");
    }
    function U(e, t) {
      var n =
        (typeof Symbol != "undefined" &&
          e[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"]) ||
        e["@@iterator"];
      if (!n) {
        if (
          Array.isArray(e) ||
          (n = V(e)) ||
          (t && e && typeof e.length == "number")
        ) {
          n && (e = n);
          var r = 0,
            o = function () {};
          return {
            s: o,
            n: function () {
              return r >= e.length ? { done: !0 } : { done: !1, value: e[r++] };
            },
            e: function (t) {
              throw t;
            },
            f: o,
          };
        }
        throw new TypeError(
          "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
        );
      }
      var a,
        i = !0,
        l = !1;
      return {
        s: function () {
          n = n.call(e);
        },
        n: function () {
          var e = n.next();
          return (i = e.done), e;
        },
        e: function (t) {
          (l = !0), (a = t);
        },
        f: function () {
          try {
            i || n.return == null || n.return();
          } finally {
            if (l) throw a;
          }
        },
      };
    }
    function V(e, t) {
      if (e) {
        if (typeof e == "string") return H(e, t);
        var n = {}.toString.call(e).slice(8, -1);
        return (
          n === "Object" && e.constructor && (n = e.constructor.name),
          n === "Map" || n === "Set"
            ? Array.from(e)
            : n === "Arguments" ||
              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
            ? H(e, t)
            : void 0
        );
      }
    }
    function H(e, t) {
      (t == null || t > e.length) && (t = e.length);
      for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
      return r;
    }
    function G(e) {
      "@babel/helpers - typeof";
      return (
        (G =
          typeof Symbol == "function" &&
          typeof (typeof Symbol == "function"
            ? Symbol.iterator
            : "@@iterator") == "symbol"
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  typeof Symbol == "function" &&
                  e.constructor === Symbol &&
                  e !==
                    (typeof Symbol == "function"
                      ? Symbol.prototype
                      : "@@prototype")
                  ? "symbol"
                  : typeof e;
              }),
        G(e)
      );
    }
    a.__fbeventsModules ||
      ((a.__fbeventsModules = {}),
      (a.__fbeventsResolvedModules = {}),
      (a.getFbeventsModules = function (e) {
        return (
          a.__fbeventsResolvedModules[e] ||
            (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
          a.__fbeventsResolvedModules[e]
        );
      }),
      (a.fbIsModuleLoaded = function (e) {
        return !!a.__fbeventsModules[e];
      }),
      (a.ensureModuleRegistered = function (e, t) {
        a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
      })),
      a.ensureModuleRegistered("gateCheck", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsEvents"),
                t = e.gateCheckEvent,
                n = a.getFbeventsModules("SignalsFBEventsLogging"),
                r = n.logUserError;
              function i(e, n, o, a) {
                var i = function () {},
                  l = typeof n == "function" ? n : i,
                  s = typeof o == "function" ? o : i;
                if (typeof e != "string" || e === "") {
                  r({
                    type: "INVALID_FBQ_METHOD_PARAMETER",
                    method: "gateCheck",
                    invalidParamName: "gateName",
                    invalidParamValue: e,
                    params: [e, n, o, a],
                  });
                  return;
                }
                t.trigger(e, l, s, typeof a == "string" ? a : null);
              }
              o.exports = i;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("generateEventId", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              function e() {
                var e = new Date().getTime(),
                  t = "xxxxxxxsx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
                    /[xy]/g,
                    function (t) {
                      var n = (e + Math.random() * 16) % 16 | 0;
                      return (
                        (e = Math.floor(e / 16)),
                        (t === "x" ? n : (n & 3) | 8).toString(16)
                      );
                    }
                  );
                return t;
              }
              function t(t, n) {
                var r = e();
                return (
                  (n != null ? n : "none") +
                  "." +
                  (t != null ? t : "none") +
                  "." +
                  r
                );
              }
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("handleEventIdOverride", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging");
              function t(t, n, r, o, a) {
                if (t != null && (t.eventID != null || t.event_id != null)) {
                  var i = t.eventID,
                    l = t.event_id,
                    s = i != null ? i : l;
                  s !== null &&
                    G(s) === "object" &&
                    ("eventID" in s || "event_id" in s
                      ? (s = s.eventID != null ? s.eventID : s.event_id)
                      : e.logUserError({
                          pixelID: o || "",
                          type: "INVALID_EVENT_ID_FORMAT",
                          eventName: a,
                        })),
                    s == null &&
                      (n.event_id != null || n.eventID != null) &&
                      e.consoleWarn(
                        "eventID is being sent in the 3rd parameter, it should be in the 4th parameter."
                      ),
                    r.containsKey("eid")
                      ? s == null || s.length == 0
                        ? e.logUserError({
                            pixelID: o || "",
                            type: "NO_EVENT_ID",
                          })
                        : r.replaceEntry("eid", s)
                      : r.append("eid", s);
                }
              }
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("normalizeSignalsFBEventsDOBType", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules(
                  "normalizeSignalsFBEventsStringType"
                ),
                t = e.normalize,
                n = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                r = n.looksLikeHashed,
                i = n.trim,
                l = a.getFbeventsModules("SignalsFBEventsLogging"),
                s = l.logError;
              function u(e, t, n) {
                var r = new Date().getFullYear();
                return !(
                  e < 1800 ||
                  e > r + 1 ||
                  t < 1 ||
                  t > 12 ||
                  n < 1 ||
                  n > 31
                );
              }
              function c(e) {
                return e.replace(/\D/g, " ");
              }
              function d(e, t, n) {
                var r = 0,
                  o = 0,
                  a = 0;
                return (
                  e > 31
                    ? ((r = e), (o = t > 12 ? n : t), (a = t > 12 ? t : n))
                    : t > 31
                    ? ((r = t), (o = n > 12 ? e : n), (a = n > 12 ? n : e))
                    : ((r = n), (o = e > 12 ? t : e), (a = e > 12 ? e : t)),
                  u(r, o, a)
                    ? String(r).padStart(4, "0") +
                      String(o).padStart(2, "0") +
                      String(a).padStart(2, "0")
                    : null
                );
              }
              function m(e) {
                var t = i(c(e)),
                  n = t.split(" ").filter(function (e) {
                    return e.length > 0;
                  });
                if (n.length >= 3) {
                  var r = parseInt(n[0]),
                    o = parseInt(n[1]),
                    a = parseInt(n[2]),
                    l = d(r, o, a);
                  if (l != null) return l;
                }
                return n.length === 1 && n[0].length === 8 ? n[0] : e;
              }
              function p(e) {
                return r(e) ? e : m(e);
              }
              function _(e, n, r) {
                if (e == null) return null;
                if (typeof e != "string") return e;
                try {
                  return r
                    ? t(e, { lowercase: !0, strip: "whitespace_only" })
                    : p(e);
                } catch (e) {
                  (e.message = "[normalizeDOB]: ".concat(e.message)), s(e);
                }
                return e;
              }
              o.exports = _;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "normalizeSignalsFBEventsEmailType",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  t = e.looksLikeHashed,
                  n = e.trim,
                  r =
                    /^[\w!#\$%&\'\*\+\/\=\?\^`\{\|\}~\-]+(:?\.[\w!#\$%&\'\*\+\/\=\?\^`\{\|\}~\-]+)*@(?:[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?$/i;
                function i(e) {
                  return r.test(e);
                }
                function l(e) {
                  var r = null;
                  if (e != null)
                    if (t(e)) r = e;
                    else {
                      var o = n(e.toLowerCase());
                      r = i(o) ? o : null;
                    }
                  return r;
                }
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("normalizeSignalsFBEventsEnumType", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsShared"),
                t = e.unicodeSafeTruncate,
                n = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                r = n.looksLikeHashed,
                i = n.trim;
              function l(e) {
                var n =
                    arguments.length > 1 && arguments[1] !== void 0
                      ? arguments[1]
                      : {},
                  o = null,
                  a = n.caseInsensitive,
                  l = n.lowercase,
                  s = n.options,
                  u = n.truncate,
                  c = n.uppercase;
                if (e != null && s != null && Array.isArray(s) && s.length)
                  if (typeof e == "string" && r(e)) o = e;
                  else {
                    var d = i(String(e));
                    if (
                      (l === !0 && (d = d.toLowerCase()),
                      c === !0 && (d = d.toUpperCase()),
                      u != null && u !== 0 && (d = t(d, u)),
                      a === !0)
                    ) {
                      for (var m = d.toLowerCase(), p = 0; p < s.length; ++p)
                        if (m === s[p].toLowerCase()) {
                          d = s[p];
                          break;
                        }
                    }
                    o = s.indexOf(d) > -1 ? d : null;
                  }
                return o;
              }
              o.exports = l;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "normalizeSignalsFBEventsPhoneNumberType",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                  t = e.logError,
                  n = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  r = n.looksLikeHashed,
                  i = /^0*/,
                  l = /[\-@#<>\'\",; ]|\(|\)|\+|[a-z]/gi,
                  s =
                    /(?:(?![0-9\uD800-\uDFFF])[^]|[\uD800-\uDBFF][\uDC00-\uDFFF])/gi;
                function u(e, n, r) {
                  if (!r)
                    try {
                      return d(e);
                    } catch (e) {
                      (e.message = "[normalizePhoneNumber]: ".concat(
                        e.message
                      )),
                        t(e);
                    }
                  return c(e);
                }
                function c(e) {
                  var t = null;
                  if (e != null)
                    if (r(e)) t = e;
                    else {
                      var n = String(e);
                      t = n.replace(l, "").replace(i, "");
                    }
                  return t;
                }
                function d(e) {
                  return e == null
                    ? null
                    : r(e)
                    ? e
                    : String(e).replace(s, "").replace(i, "");
                }
                o.exports = u;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "normalizeSignalsFBEventsPostalCodeType",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  t = e.looksLikeHashed,
                  n = e.trim;
                function r(e) {
                  var r = null;
                  if (e != null && typeof e == "string")
                    if (t(e)) r = e;
                    else {
                      var o = n(String(e).toLowerCase().split("-", 1)[0]);
                      o.length >= 2 && (r = o);
                    }
                  return r;
                }
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "normalizeSignalsFBEventsStringType",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                  t = e.keys,
                  n = a.getFbeventsModules("SignalsFBEventsShared"),
                  r = n.unicodeSafeTruncate,
                  i = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  l = i.looksLikeHashed,
                  s = i.strip,
                  u = a.getFbeventsModules("SignalsPixelPIIConstants"),
                  c = u.STATE_MAPPINGS,
                  d = u.COUNTRY_MAPPINGS,
                  m = a.getFbeventsModules("SignalsFBEventsLogging"),
                  p = m.logError;
                function _(e) {
                  var t =
                      arguments.length > 1 && arguments[1] !== void 0
                        ? arguments[1]
                        : {},
                    n = null;
                  if (e != null)
                    if (l(e) && typeof e == "string")
                      t.rejectHashed !== !0 && (n = e);
                    else {
                      var o = String(e);
                      t.strip != null && (o = s(o, t.strip)),
                        t.lowercase === !0
                          ? (o = o.toLowerCase())
                          : t.uppercase === !0 && (o = o.toUpperCase()),
                        t.truncate != null &&
                          t.truncate !== 0 &&
                          (o = r(o, t.truncate)),
                        t.test != null && t.test !== ""
                          ? (n = new RegExp(t.test).test(o) ? o : null)
                          : (n = o);
                    }
                  return n;
                }
                function f(e) {
                  return _(e, { strip: "whitespace_and_punctuation" });
                }
                function g(e, n) {
                  if (e.length === 2) return e;
                  if (n[e] != null) return n[e];
                  var r = U(t(n)),
                    o;
                  try {
                    for (r.s(); !(o = r.n()).done; ) {
                      var a = o.value;
                      if (e.includes(a)) {
                        var i = n[a];
                        return i;
                      }
                    }
                  } catch (e) {
                    r.e(e);
                  } finally {
                    r.f();
                  }
                  return e.toLowerCase();
                }
                function h(e, t) {
                  if (l(e) || typeof e != "string") return e;
                  var n = e;
                  switch (
                    ((n = n.toLowerCase().trim()),
                    (n = n.replace(/[^a-z]/g, "")),
                    (n = g(n, t)),
                    n.length)
                  ) {
                    case 0:
                      return null;
                    case 1:
                      return n;
                    default:
                      return n.substring(0, 2);
                  }
                }
                function y(e, t, n) {
                  if (e == null) return null;
                  var r = e;
                  if (!n)
                    try {
                      r = h(r, d);
                    } catch (e) {
                      (e.message = "[NormalizeCountry]: " + e.message), p(e);
                    }
                  return _(r, {
                    truncate: 2,
                    strip: "all_non_latin_alpha_numeric",
                    test: "^[a-z]+",
                    lowercase: !0,
                  });
                }
                function C(e, t, n) {
                  if (e == null) return null;
                  var r = e;
                  if (!n)
                    try {
                      r = h(r, c);
                    } catch (e) {
                      (e.message = "[NormalizeState]: " + e.message), p(e);
                    }
                  return _(r, {
                    truncate: 2,
                    strip: "all_non_latin_alpha_numeric",
                    test: "^[a-z]+",
                    lowercase: !0,
                  });
                }
                function b(e) {
                  return _(e, {
                    strip: "all_non_latin_alpha_numeric",
                    test: "^[a-z]+",
                  });
                }
                o.exports = {
                  normalize: _,
                  normalizeName: f,
                  normalizeCity: b,
                  normalizeState: C,
                  normalizeCountry: y,
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("PixelQueue", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsLogging"),
                n = t.logWarning,
                r = a.getFbeventsModules("WebStorage"),
                i = r.getLocalStorage,
                l = a.getFbeventsModules("WebStorageMutex"),
                s = a.getFbeventsModules("SignalsFBEventsPageStatusMonitor"),
                u = s.initPageStatusMonitor,
                c = s.subscribeToPageStatus,
                d = 1440 * 60 * 1e3,
                m = 30 * 1e3,
                p = 5;
              function _(e) {
                var t = e.prev,
                  n = e.next;
                n && (n.prev = t),
                  t && (t.next = n),
                  (e.next = null),
                  (e.prev = null);
              }
              function f(e, t) {
                return {
                  item: e,
                  next: null,
                  prev: null,
                  retryCount: 0,
                  enqueuedAt: t != null ? t : Date.now(),
                };
              }
              function g() {
                return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
                  /[xy]/g,
                  function (e) {
                    var t = (Math.random() * 16) | 0,
                      n = e === "x" ? t : (t & 3) | 8;
                    return n.toString(16);
                  }
                );
              }
              function h(e, t) {
                var n;
                return (
                  e +
                  "^$" +
                  ((n = t == null ? void 0 : t.queueNameSuffix) !== null &&
                  n !== void 0
                    ? n
                    : "")
                );
              }
              var y = new WeakMap(),
                C = new WeakMap(),
                b = new WeakMap(),
                v = new WeakMap(),
                S = new WeakMap(),
                R = new WeakMap(),
                L = new WeakMap(),
                E = new WeakMap(),
                k = new WeakMap(),
                I = new WeakMap(),
                T = new WeakMap(),
                D = new WeakMap(),
                x = new WeakMap(),
                P = new WeakMap(),
                M = new WeakMap(),
                w = new WeakSet(),
                O = (function () {
                  function t(n, r) {
                    var o,
                      a,
                      i = this;
                    $(this, t),
                      A(this, w),
                      F(this, y, void 0),
                      F(this, C, void 0),
                      F(this, b, void 0),
                      F(this, v, void 0),
                      F(this, S, void 0),
                      F(this, R, void 0),
                      F(this, L, void 0),
                      F(this, E, 0),
                      F(this, k, void 0),
                      F(this, I, void 0),
                      F(this, T, void 0),
                      F(this, D, void 0),
                      F(this, x, void 0),
                      F(this, P, void 0),
                      F(this, M, void 0);
                    var l = {
                      item: null,
                      prev: null,
                      next: null,
                      retryCount: 0,
                      enqueuedAt: 0,
                    };
                    W(y, this, l),
                      W(C, this, l),
                      W(b, this, l.next),
                      W(v, this, n),
                      W(
                        R,
                        this,
                        (o = r == null ? void 0 : r.queueNameSuffix) !== null &&
                          o !== void 0
                          ? o
                          : ""
                      ),
                      W(S, this, h(n, r)),
                      W(L, this, null),
                      W(E, this, 0),
                      W(
                        k,
                        this,
                        (a = r == null ? void 0 : r.maxAgeInMs) !== null &&
                          a !== void 0
                          ? a
                          : d
                      ),
                      W(D, this, B(S, this) + "^$" + g()),
                      W(T, this, null),
                      W(x, this, !1),
                      W(P, this, !1),
                      W(M, this, !1),
                      W(I, this, [
                        c(function (e) {
                          e === "inactive" && q(w, i, H).call(i);
                        }),
                      ]),
                      typeof e != "undefined" && e.requestAnimationFrame
                        ? e.requestAnimationFrame(function () {
                            return q(w, i, z).call(i);
                          })
                        : setTimeout(function () {
                            return q(w, i, z).call(i);
                          }, 0);
                  }
                  return N(t, [
                    {
                      key: "setHandler",
                      value: function (t) {
                        return W(L, this, t), q(w, this, Q).call(this), this;
                      },
                    },
                    {
                      key: "enqueue",
                      value: function (t) {
                        q(w, this, X).call(this, t),
                          this.isActive()
                            ? q(w, this, Q).call(this)
                            : q(w, this, J).call(this);
                      },
                    },
                    {
                      key: "dequeueItem",
                      value: function () {
                        if (B(T, this) != null) return null;
                        for (var e = B(b, this); e && e.retryCount >= p; )
                          e = e.next;
                        return e
                          ? (W(b, this, e.next), e)
                          : (W(b, this, null), null);
                      },
                    },
                    {
                      key: "markItemAsCompleted",
                      value: function (t) {
                        var e,
                          n,
                          r = t.prev,
                          o = t.next;
                        _(t),
                          B(C, this) === t &&
                            W(C, this, r != null ? r : B(y, this)),
                          B(b, this) === t && W(b, this, o),
                          W(E, this, ((e = B(E, this)), (n = e--), e)),
                          this.isActive() || q(w, this, J).call(this);
                      },
                    },
                    {
                      key: "markItemAsFailed",
                      value: function (t) {
                        var e = t.retryCount || 0,
                          n = e + 1;
                        (t.retryCount = n),
                          !(n >= p) &&
                            (B(C, this) !== t &&
                              (_(t),
                              B(b, this) === t && W(b, this, t.next),
                              q(w, this, V).call(this, t)),
                            this.isActive() && q(w, this, Q).call(this));
                      },
                    },
                    {
                      key: "markItem",
                      value: function (t, n) {
                        n
                          ? this.markItemAsCompleted(t)
                          : this.markItemAsFailed(t);
                      },
                    },
                    {
                      key: "length",
                      value: function () {
                        return B(E, this);
                      },
                    },
                    {
                      key: "isActive",
                      value: function () {
                        var e = B(T, this);
                        return e == null
                          ? !0
                          : Date.now() - e > m
                          ? (q(w, this, G).call(this), !0)
                          : !1;
                      },
                    },
                    {
                      key: "getFullName",
                      value: function () {
                        return B(S, this);
                      },
                    },
                    {
                      key: "getQueueNameSuffix",
                      value: function () {
                        return B(R, this);
                      },
                    },
                    {
                      key: "disableStorage",
                      value: function () {
                        W(M, this, !0);
                      },
                    },
                    {
                      key: "destroy",
                      value: function () {
                        B(I, this).forEach(function (e) {
                          return e();
                        });
                      },
                    },
                  ]);
                })();
              function V(e) {
                var t,
                  n =
                    (t = B(C, this)) !== null && t !== void 0 ? t : B(y, this);
                (n.next = e),
                  (e.prev = n),
                  (e.next = null),
                  W(C, this, e),
                  B(b, this) == null && W(b, this, e);
              }
              function H() {
                B(T, this) == null &&
                  (W(T, this, Date.now()), q(w, this, j).call(this));
              }
              function G() {
                (B(T, this) != null || !B(x, this)) &&
                  (W(x, this, !0), W(T, this, null), q(w, this, z).call(this));
              }
              function z() {
                q(w, this, Y).call(this), q(w, this, K).call(this);
              }
              function j() {
                q(w, this, J).call(this);
              }
              function K() {
                B(E, this) > 0 && B(L, this) && B(L, this).call(this, this);
              }
              function Q() {
                var t = this;
                if (!B(P, this) && !(B(E, this) === 0 || !B(L, this))) {
                  W(P, this, !0);
                  var r = function () {
                    try {
                      W(P, t, !1), q(w, t, K).call(t);
                    } catch (e) {
                      n(e, "pixel", "qualityChecker");
                    }
                  };
                  typeof e != "undefined" && e.requestAnimationFrame
                    ? e.requestAnimationFrame(r)
                    : setTimeout(r, 0);
                }
              }
              function X(e, t) {
                var n,
                  r,
                  o = f(e, t);
                q(w, this, V).call(this, o),
                  W(E, this, ((n = B(E, this)), (r = n++), n));
              }
              function Y() {
                var e = this,
                  t = i();
                if (t) {
                  var r = this.getFullName() + "^$",
                    o = new l(r);
                  o.lock(function (o) {
                    var a = Date.now() - B(k, e);
                    try {
                      for (var i = 0; i < t.length; i++) {
                        var l = t.key(i);
                        if (typeof l == "string" && l.startsWith(r)) {
                          var s = t.getItem(l);
                          if ((t.removeItem(l), s != null && s.startsWith("{")))
                            try {
                              var u = JSON.parse(s);
                              if (u.ts > a) {
                                var c = U(u.items),
                                  d;
                                try {
                                  for (c.s(); !(d = c.n()).done; ) {
                                    var m,
                                      p = d.value,
                                      _ =
                                        (m = p.enqueuedAt) !== null &&
                                        m !== void 0
                                          ? m
                                          : u.ts,
                                      f = p.item;
                                    _ > a && q(w, e, X).call(e, f, _);
                                  }
                                } catch (e) {
                                  c.e(e);
                                } finally {
                                  c.f();
                                }
                              }
                            } catch (e) {}
                        }
                      }
                    } catch (e) {
                      n(e, "pixel", "qualityChecker");
                    } finally {
                      o.unlock(), q(w, e, Q).call(e);
                    }
                  });
                }
              }
              function J() {
                var e = i();
                if (e && !B(M, this)) {
                  var t = q(w, this, Z).call(this);
                  if (t.length === 0) {
                    e.getItem(B(D, this)) != null && e.removeItem(B(D, this));
                    return;
                  }
                  var r = { ts: Date.now(), items: t };
                  try {
                    e.setItem(B(D, this), JSON.stringify(r));
                  } catch (e) {
                    n(e, "pixel", "qualityChecker");
                  }
                }
              }
              function Z() {
                for (
                  var e = [], t = B(y, this).next, n = Date.now() - B(k, this);
                  t;

                )
                  t.enqueuedAt > n &&
                    e.push({ item: t.item, enqueuedAt: t.enqueuedAt }),
                    (t = t.next);
                return e;
              }
              typeof e != "undefined" && u(), (o.exports = O);
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsConvertNodeToHTMLElement", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              function e(e) {
                return (typeof HTMLElement == "undefined"
                  ? "undefined"
                  : G(HTMLElement)) === "object"
                  ? e instanceof HTMLElement
                  : e !== null &&
                      G(e) === "object" &&
                      e.nodeType === Node.ELEMENT_NODE &&
                      typeof e.nodeName == "string";
              }
              function t(t) {
                return e(t) ? t : null;
              }
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsEventPayload", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                t = new WeakMap(),
                n = (function () {
                  function n() {
                    $(this, n), F(this, t, void 0), W(t, this, new Map());
                  }
                  return N(
                    n,
                    [
                      {
                        key: "has",
                        value: function (n) {
                          return B(t, this).has(n);
                        },
                      },
                      {
                        key: "get",
                        value: function (n) {
                          var e = B(t, this).get(n);
                          return e == null || e.length === 0
                            ? null
                            : e[e.length - 1];
                        },
                      },
                      {
                        key: "getAll",
                        value: function (n) {
                          var e = B(t, this).get(n);
                          return e ? I(e) : null;
                        },
                      },
                      {
                        key: "getEventId",
                        value: function () {
                          for (
                            var e = [
                                "eid",
                                "eid[]",
                                encodeURIComponent("eid[]"),
                              ],
                              t = 0,
                              n = e;
                            t < n.length;
                            t++
                          ) {
                            var r = n[t],
                              o = this.get(r);
                            if (o != null && o.length > 0) return o;
                          }
                          return null;
                        },
                      },
                      {
                        key: "getAllParams",
                        value: function () {
                          var e = [],
                            n = U(B(t, this).entries()),
                            r;
                          try {
                            for (n.s(); !(r = n.n()).done; ) {
                              var o = R(r.value, 2),
                                a = o[0],
                                i = o[1],
                                l = U(i),
                                s;
                              try {
                                for (l.s(); !(s = l.n()).done; ) {
                                  var u = s.value;
                                  e.push({ name: a, value: u });
                                }
                              } catch (e) {
                                l.e(e);
                              } finally {
                                l.f();
                              }
                            }
                          } catch (e) {
                            n.e(e);
                          } finally {
                            n.f();
                          }
                          return e;
                        },
                      },
                      {
                        key: "forEach",
                        value: function (n) {
                          var e = U(B(t, this).entries()),
                            r;
                          try {
                            for (e.s(); !(r = e.n()).done; ) {
                              var o = R(r.value, 2),
                                a = o[0],
                                i = o[1],
                                l = U(i),
                                s;
                              try {
                                for (l.s(); !(s = l.n()).done; ) {
                                  var u = s.value;
                                  n(a, u);
                                }
                              } catch (e) {
                                l.e(e);
                              } finally {
                                l.f();
                              }
                            }
                          } catch (t) {
                            e.e(t);
                          } finally {
                            e.f();
                          }
                        },
                      },
                      {
                        key: "set",
                        value: function (n, r) {
                          return B(t, this).set(n, [r]), this;
                        },
                      },
                      {
                        key: "setFromArray",
                        value: function (n, r) {
                          return r.length > 0 && B(t, this).set(n, I(r)), this;
                        },
                      },
                      {
                        key: "setAsDict",
                        value: function (t, n) {
                          for (var e = 0; e < n.length; e++)
                            this.set("".concat(t, "[").concat(e, "]"), n[e]);
                          return this;
                        },
                      },
                      {
                        key: "append",
                        value: function (n, r) {
                          var e = B(t, this).get(n);
                          return (
                            e != null ? e.push(r) : B(t, this).set(n, [r]), this
                          );
                        },
                      },
                      {
                        key: "delete",
                        value: function (n) {
                          return B(t, this).delete(n), this;
                        },
                      },
                      {
                        key: "merge",
                        value: function (t) {
                          var e = this;
                          return (
                            t.forEach(function (t, n) {
                              e.append(t, n);
                            }),
                            this
                          );
                        },
                      },
                      {
                        key: "toQueryString",
                        value: function () {
                          var e = [];
                          return (
                            this.forEach(function (t, n) {
                              e.push(
                                "".concat(t, "=").concat(encodeURIComponent(n))
                              );
                            }),
                            e.join("&")
                          );
                        },
                      },
                      {
                        key: "toFormData",
                        value: function () {
                          var t = new FormData(),
                            n = e.eval("fix_fbevent_uri_error");
                          return (
                            this.forEach(function (e, r) {
                              if (n)
                                try {
                                  t.append(decodeURIComponent(e), r);
                                } catch (n) {
                                  t.append(e, r);
                                }
                              else t.append(decodeURIComponent(e), r);
                            }),
                            t
                          );
                        },
                      },
                      {
                        key: "toObject",
                        value: function () {
                          var e = {};
                          return (
                            this.forEach(function (t, n) {
                              e[t] = n;
                            }),
                            e
                          );
                        },
                      },
                      {
                        key: "toJSON",
                        value: function () {
                          return this.getAllParams();
                        },
                      },
                    ],
                    [
                      {
                        key: "fromJSON",
                        value: function (t) {
                          var e = new n(),
                            r = U(t),
                            o;
                          try {
                            for (r.s(); !(o = r.n()).done; ) {
                              var a = o.value,
                                i = a.name,
                                l = a.value;
                              e.append(i, l);
                            }
                          } catch (e) {
                            r.e(e);
                          } finally {
                            r.f();
                          }
                          return e;
                        },
                      },
                    ]
                  );
                })();
              o.exports = n;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsEventValidation", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                t = e.logUserError,
                n = /^[+-]?\d+(\.\d+)?$/,
                r = "number",
                i = "currency_code",
                l = {
                  AED: 1,
                  ARS: 1,
                  AUD: 1,
                  BOB: 1,
                  BRL: 1,
                  CAD: 1,
                  CHF: 1,
                  CLP: 1,
                  CNY: 1,
                  COP: 1,
                  CRC: 1,
                  CZK: 1,
                  DKK: 1,
                  EUR: 1,
                  GBP: 1,
                  GTQ: 1,
                  HKD: 1,
                  HNL: 1,
                  HUF: 1,
                  IDR: 1,
                  ILS: 1,
                  INR: 1,
                  ISK: 1,
                  JPY: 1,
                  KRW: 1,
                  MOP: 1,
                  MXN: 1,
                  MYR: 1,
                  NIO: 1,
                  NOK: 1,
                  NZD: 1,
                  PEN: 1,
                  PHP: 1,
                  PLN: 1,
                  PYG: 1,
                  QAR: 1,
                  RON: 1,
                  RUB: 1,
                  SAR: 1,
                  SEK: 1,
                  SGD: 1,
                  THB: 1,
                  TRY: 1,
                  TWD: 1,
                  USD: 1,
                  UYU: 1,
                  VEF: 1,
                  VND: 1,
                  ZAR: 1,
                },
                s = {
                  value: { isRequired: !0, type: r },
                  currency: { isRequired: !0, type: i },
                },
                u = {
                  AddPaymentInfo: {},
                  AddToCart: {},
                  AddToWishlist: {},
                  CompleteRegistration: {},
                  Contact: {},
                  CustomEvent: {
                    validationSchema: { event: { isRequired: !0 } },
                  },
                  CustomizeProduct: {},
                  Donate: {},
                  FindLocation: {},
                  InitiateCheckout: {},
                  Lead: {},
                  PageView: {},
                  PixelInitialized: {},
                  Purchase: { validationSchema: s },
                  Schedule: {},
                  Search: {},
                  StartTrial: {},
                  SubmitApplication: {},
                  Subscribe: {},
                  ViewContent: {},
                },
                c = {
                  agent: !0,
                  automaticmatchingconfig: !0,
                  codeless: !0,
                  tracksingleonly: !0,
                  "cbdata.onetrustid": !0,
                },
                d = Object.prototype.hasOwnProperty;
              function m() {
                return { error: null, warnings: [] };
              }
              function p(e) {
                return { error: e, warnings: [] };
              }
              function _(e) {
                return { error: null, warnings: e };
              }
              function f(e) {
                if (e) {
                  var t = e.toLowerCase(),
                    n = c[t];
                  if (n !== !0)
                    return p({
                      metadata: t,
                      type: "UNSUPPORTED_METADATA_ARGUMENT",
                    });
                }
                return m();
              }
              function g(e) {
                var t =
                  arguments.length > 1 && arguments[1] !== void 0
                    ? arguments[1]
                    : {};
                if (!e) return p({ type: "NO_EVENT_NAME" });
                var n = u[e];
                return n
                  ? h(e, t, n)
                  : _([{ eventName: e, type: "NONSTANDARD_EVENT" }]);
              }
              function h(e, t, o) {
                var a = o.validationSchema,
                  s = [];
                for (var u in a)
                  if (d.call(a, u)) {
                    var c = a[u],
                      m = t[u];
                    if (c) {
                      if (c.isRequired != null && !d.call(t, u))
                        return p({
                          eventName: e,
                          param: u,
                          type: "REQUIRED_PARAM_MISSING",
                        });
                      if (c.type != null && typeof c.type == "string") {
                        var f = !0;
                        switch (c.type) {
                          case r:
                            {
                              var g =
                                (typeof m == "string" ||
                                  typeof m == "number") &&
                                n.test("".concat(m));
                              g &&
                                Number(m) < 0 &&
                                s.push({
                                  eventName: e || "null",
                                  param: u,
                                  type: "NEGATIVE_EVENT_PARAM",
                                }),
                                (f = g);
                            }
                            break;
                          case i:
                            f = typeof m == "string" && !!l[m.toUpperCase()];
                            break;
                        }
                        if (!f)
                          return p({
                            eventName: e,
                            param: u,
                            type: "INVALID_PARAM",
                          });
                      }
                    }
                  }
                return _(s);
              }
              function y(e, n) {
                var r = g(e, n);
                if ((r.error && t(r.error), r.warnings))
                  for (var o = 0; o < r.warnings.length; o++) t(r.warnings[o]);
                return r;
              }
              o.exports = {
                validateEvent: g,
                validateEventAndLog: y,
                validateMetadata: f,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsAddGmailSuffixToEmail",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  t = e.looksLikeHashed,
                  n = a.getFbeventsModules("SignalsFBEventsLogging"),
                  r = n.logError;
                function i(e) {
                  try {
                    if (e == null || G(e) !== "object") return e;
                    e.em != null &&
                      e.em.trim() !== "" &&
                      !t(e.em) &&
                      typeof e.em == "string" &&
                      !e.em.includes("@") &&
                      (e.em = e.em + "@gmail.com"),
                      e.email != null &&
                        e.email.trim() !== "" &&
                        !t(e.email) &&
                        typeof e.email == "string" &&
                        !e.email.includes("@") &&
                        (e.email = e.email + "@gmail.com");
                  } catch (e) {
                    (e.message = "[NormalizeAddSuffix]:" + e.message), r(e);
                  }
                  return e;
                }
                o.exports = i;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsAsyncParamUtils", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("signalsFBEventsSendEventImpl");
              function t(e) {
                for (
                  e.asyncParamPromisesAllSettled = !0;
                  e.eventQueue.length > 0;

                ) {
                  var t = e.eventQueue.shift();
                  n(e, t);
                }
              }
              function n(t, n) {
                var r = I(t.asyncParamFetchers.values()),
                  o = U(r),
                  a;
                try {
                  for (o.s(); !(a = o.n()).done; ) {
                    var i = a.value,
                      l = i.callback;
                    l != null && l(i.result, n, t);
                  }
                } catch (e) {
                  o.e(e);
                } finally {
                  o.f();
                }
                e(n, t);
              }
              function r(e) {
                var n = I(e.asyncParamFetchers.keys());
                Promise.allSettled(
                  I(e.asyncParamFetchers.values()).map(function (e) {
                    return e.request;
                  })
                ).then(function (r) {
                  (e.asyncParamPromisesAllSettled = !0),
                    r.forEach(function (t, r) {
                      if (t.status === "fulfilled") {
                        var o = n[r],
                          a = e.asyncParamFetchers.get(o);
                        a != null &&
                          a.result == null &&
                          ((a.result = t.value),
                          e.asyncParamFetchers.set(o, a));
                      }
                    }),
                    t(e);
                });
              }
              o.exports = {
                flushAsyncParamEventQueue: t,
                registerAsyncParamAllSettledListener: r,
                appendAsyncParamsAndSendEvent: n,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsAutomaticPageViewEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent");
                function t() {
                  return [];
                }
                o.exports = new e(t);
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsBaseEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                t = e.map,
                n = e.keys,
                r = (function () {
                  function e(t) {
                    $(this, e),
                      S(this, "_regKey", 0),
                      S(this, "_subscriptions", {}),
                      (this._coerceArgs = t || null);
                  }
                  return N(e, [
                    {
                      key: "listen",
                      value: function (t) {
                        var e = this,
                          n = "".concat(this._regKey++);
                        return (
                          (this._subscriptions[n] = t),
                          function () {
                            delete e._subscriptions[n];
                          }
                        );
                      },
                    },
                    {
                      key: "listenOnce",
                      value: function (t) {
                        var e = null,
                          n = function () {
                            return (
                              e && e(), (e = null), t.apply(void 0, arguments)
                            );
                          };
                        return (e = this.listen(n)), e;
                      },
                    },
                    {
                      key: "trigger",
                      value: function () {
                        for (
                          var e = this,
                            r = arguments.length,
                            o = new Array(r),
                            a = 0;
                          a < r;
                          a++
                        )
                          o[a] = arguments[a];
                        return t(n(this._subscriptions), function (t) {
                          if (
                            t in e._subscriptions &&
                            e._subscriptions[t] != null
                          ) {
                            var n;
                            return (n = e._subscriptions)[t].apply(n, o);
                          } else return null;
                        });
                      },
                    },
                    {
                      key: "triggerWeakly",
                      value: function () {
                        var e =
                          this._coerceArgs != null
                            ? this._coerceArgs.apply(this, arguments)
                            : null;
                        return e == null ? [] : this.trigger.apply(this, I(e));
                      },
                    },
                  ]);
                })();
              o.exports = r;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsBotBlockingConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    rules: t.objectWithFields({
                      spider_bot_rules: t.string(),
                      browser_patterns: t.string(),
                    }),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsBrowserPropertiesConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    delayInMs: t.allowNull(t.number()),
                    enableEventSuppression: t.allowNull(t.boolean()),
                    enableBackupTimeout: t.allowNull(t.boolean()),
                    experiment: t.allowNull(t.string()),
                    fbcParamsConfig: t.allowNull(
                      t.objectWithFields({
                        params: t.allowNull(
                          t.arrayOf(
                            t.objectWithFields({
                              ebp_path: t.string(),
                              prefix: t.string(),
                              query: t.string(),
                            })
                          )
                        ),
                      })
                    ),
                    enableFbcParamSplitIOS: t.allowNull(t.boolean()),
                    enableFbcParamSplitAndroid: t.allowNull(t.boolean()),
                    enableAemSourceTagToLocalStorage: t.allowNull(t.boolean()),
                    enableEBPaaP: t.allowNull(t.boolean()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsBrowserPropertiesPlatformConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    enableIOS: t.allowNull(t.boolean()),
                    enableAndroid: t.allowNull(t.boolean()),
                    platformKeys: t.allowNull(t.arrayOf(t.string())),
                    usePlatformKeys: t.allowNull(t.boolean()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsBufferConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    delayInMs: t.number(),
                    experimentName: t.allowNull(t.string()),
                    enableMultiEid: t.allowNull(t.boolean()),
                    onlyBufferPageView: t.allowNull(t.boolean()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsCCRuleEvaluatorConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    ccRules: t.allowNull(
                      t.arrayOf(
                        t.allowNull(
                          t.objectWithFields({
                            id: t.allowNull(t.stringOrNumber()),
                            rule: t.allowNull(t.objectOrString()),
                          })
                        )
                      )
                    ),
                    wcaRules: t.allowNull(
                      t.arrayOf(
                        t.allowNull(
                          t.objectWithFields({
                            id: t.allowNull(t.stringOrNumber()),
                            rule: t.allowNull(t.objectOrString()),
                          })
                        )
                      )
                    ),
                    valueRules: t.allowNull(
                      t.arrayOf(
                        t.allowNull(
                          t.objectWithFields({
                            id: t.allowNull(t.string()),
                            rule: t.allowNull(t.object()),
                          })
                        )
                      )
                    ),
                    blacklistedIframeReferrers: t.allowNull(
                      t.mapOf(t.boolean())
                    ),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsCensor", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                t = e.each,
                n = e.map;
              function r(e) {
                if (e == null) return null;
                if (e === "") return "";
                if (typeof e == "number") e = e.toString();
                else if (typeof e != "string") return null;
                var t = /[A-Z]/g,
                  n = /[a-z]/g,
                  r = /[0-9]/g,
                  o =
                    /(?:[\0-\x1F0-9A-Za-z\x7F-\u201C\u201E-\uD7FF\uE000-\uFFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])/g,
                  a = e.replace(t, "^");
                return (
                  (a = a.replace(n, "*")),
                  (a = a.replace(r, "#")),
                  (a = a.replace(o, "~")),
                  a
                );
              }
              var i = [
                  "ph",
                  "phone",
                  "em",
                  "email",
                  "fn",
                  "ln",
                  "f_name",
                  "l_name",
                  "external_id",
                  "gender",
                  "db",
                  "dob",
                  "ct",
                  "st",
                  "zp",
                  "country",
                  "city",
                  "state",
                  "zip",
                  "zip_code",
                  "zp",
                  "cn",
                  "firstName",
                  "surname",
                  "pn",
                  "gender",
                  "name",
                  "lastName",
                  "bd",
                  "first_name",
                  "address",
                  "last_name",
                  "birthday",
                  "email_preferences_token",
                  "consent_global_email_nl",
                  "consent_global_email_drip",
                  "consent_fide_email_nl",
                  "consent_fide_email_drip",
                  "$country",
                  "$city",
                  "$gender",
                  "dOB",
                  "user_email",
                  "email_sha256",
                  "primaryPhone",
                  "lastNameEng",
                  "firstNameEng",
                  "eMailAddress",
                  "pp",
                  "postcode",
                  "profile_name",
                  "account_name",
                  "email_paypal",
                  "zip_code",
                  "fbq_custom_name",
                ],
                l = n(i, function (e) {
                  return "ud[".concat(e, "]");
                }).concat(
                  n(i, function (e) {
                    return "udff[".concat(e, "]");
                  })
                );
              function s(e) {
                var n = {};
                return (
                  t(i, function (t) {
                    var o = r(e[t]);
                    o != null && (n[t] = o);
                  }),
                  n
                );
              }
              o.exports = {
                censoredIneligibleKeysWithUD: l,
                getCensoredPayload: s,
                censorPII: r,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsCheckGateEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = new e();
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsClientHintConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    delayInMs: t.allowNull(t.number()),
                    disableBackupTimeout: t.allowNull(t.boolean()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsClientSidePixelForkingConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    forkedPixelIds: t.allowNull(t.arrayOf(t.string())),
                    forkedPixelIdsInBrowserChannel: t.allowNull(
                      t.arrayOf(t.string())
                    ),
                    forkedPixelIdsInServerChannel: t.allowNull(
                      t.arrayOf(t.string())
                    ),
                    forkedPixelsInBrowserChannel: t.arrayOf(
                      t.objectWithFields({
                        destination_pixel_id: t.string(),
                        domains: t.allowNull(t.arrayOf(t.string())),
                      })
                    ),
                    forkedPixelsInServerChannel: t.arrayOf(
                      t.objectWithFields({
                        destination_pixel_id: t.string(),
                        domains: t.allowNull(t.arrayOf(t.string())),
                      })
                    ),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsCoerceAutomaticMatchingConfig",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.coerce,
                  n = e.Typed,
                  r = n.objectWithFields({
                    selectedMatchKeys: n.arrayOf(n.string()),
                  });
                o.exports = function (e) {
                  return t(e, r);
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsCoerceBatchingConfig",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = e.enforce,
                  i = function (o) {
                    var e = n(
                      o,
                      t.objectWithFields({
                        max_batch_size: t.number(),
                        wait_time_ms: t.number(),
                      })
                    );
                    return e != null
                      ? {
                          batchWaitTimeMs: e.wait_time_ms,
                          maxBatchSize: e.max_batch_size,
                        }
                      : r(
                          o,
                          t.objectWithFields({
                            batchWaitTimeMs: t.number(),
                            maxBatchSize: t.number(),
                          })
                        );
                  };
                o.exports = function (e) {
                  return n(e, i);
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsCoerceInferredEventsConfig",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.coerce,
                  n = e.Typed,
                  r = n.objectWithFields({
                    buttonSelector: n.allowNull(n.string()),
                    disableRestrictedData: n.allowNull(n.boolean()),
                  });
                o.exports = function (e) {
                  return t(e, r);
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsCoerceParameterExtractors",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                  t = e.filter,
                  n = e.map,
                  r = a.getFbeventsModules(
                    "signalsFBEventsCoerceStandardParameter"
                  );
                function i(e) {
                  if (e == null || G(e) !== "object") return null;
                  var t = e.domain_uri,
                    n = e.event_type,
                    r = e.extractor_type,
                    o = e.id,
                    a = typeof t == "string" ? t : null,
                    i =
                      n != null && typeof n == "string" && n !== "" ? n : null,
                    l =
                      o != null && typeof o == "string" && o !== "" ? o : null,
                    s =
                      r === "CONSTANT_VALUE" ||
                      r === "CSS" ||
                      r === "GLOBAL_VARIABLE" ||
                      r === "GTM" ||
                      r === "JSON_LD" ||
                      r === "META_TAG" ||
                      r === "OPEN_GRAPH" ||
                      r === "RDFA" ||
                      r === "SCHEMA_DOT_ORG" ||
                      r === "URI"
                        ? r
                        : null;
                  return a != null && i != null && l != null && s != null
                    ? { domain_uri: a, event_type: i, extractor_type: s, id: l }
                    : null;
                }
                function l(e) {
                  if (e == null || G(e) !== "object") return null;
                  var t = e.extractor_config;
                  if (t == null || G(t) !== "object") return null;
                  var n = t.parameter_type,
                    o = t.value,
                    a = r(n),
                    i =
                      o != null && typeof o == "string" && o !== "" ? o : null;
                  return a != null && i != null
                    ? { parameter_type: a, value: i }
                    : null;
                }
                function s(e) {
                  if (e == null || G(e) !== "object") return null;
                  var t = e.parameter_type,
                    n = e.selector,
                    o = r(t),
                    a =
                      n != null && typeof n == "string" && n !== "" ? n : null;
                  return o != null && a != null
                    ? { parameter_type: o, selector: a }
                    : null;
                }
                function u(e) {
                  if (e == null || G(e) !== "object") return null;
                  var r = e.extractor_config;
                  if (r == null || G(r) !== "object") return null;
                  var o = r.parameter_selectors;
                  if (Array.isArray(o)) {
                    var a = n(o, s),
                      i = t(a, Boolean);
                    if (a.length === i.length)
                      return { parameter_selectors: i };
                  }
                  return null;
                }
                function c(e) {
                  if (e == null || G(e) !== "object") return null;
                  var t = e.extractor_config;
                  if (t == null || G(t) !== "object") return null;
                  var n = t.context,
                    o = t.parameter_type,
                    a = t.value,
                    i =
                      n != null && typeof n == "string" && n !== "" ? n : null,
                    l = r(o),
                    s =
                      a != null && typeof a == "string" && a !== "" ? a : null;
                  return i != null && l != null && s != null
                    ? { context: i, parameter_type: l, value: s }
                    : null;
                }
                function d(e) {
                  var t = i(e);
                  if (t == null || e == null || G(e) !== "object") return null;
                  var n = t.domain_uri,
                    r = t.event_type,
                    o = t.extractor_type,
                    a = t.id;
                  if (o === "CSS") {
                    var s = u(e);
                    if (s != null)
                      return {
                        domain_uri: n,
                        event_type: r,
                        extractor_config: s,
                        extractor_type: "CSS",
                        id: a,
                      };
                  }
                  if (o === "CONSTANT_VALUE") {
                    var d = l(e);
                    if (d != null)
                      return {
                        domain_uri: n,
                        event_type: r,
                        extractor_config: d,
                        extractor_type: "CONSTANT_VALUE",
                        id: a,
                      };
                  }
                  if (o === "GLOBAL_VARIABLE")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "GLOBAL_VARIABLE",
                      id: a,
                    };
                  if (o === "GTM")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "GTM",
                      id: a,
                    };
                  if (o === "JSON_LD")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "JSON_LD",
                      id: a,
                    };
                  if (o === "META_TAG")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "META_TAG",
                      id: a,
                    };
                  if (o === "OPEN_GRAPH")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "OPEN_GRAPH",
                      id: a,
                    };
                  if (o === "RDFA")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "RDFA",
                      id: a,
                    };
                  if (o === "SCHEMA_DOT_ORG")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "SCHEMA_DOT_ORG",
                      id: a,
                    };
                  if (o === "URI") {
                    var m = c(e);
                    if (m != null)
                      return {
                        domain_uri: n,
                        event_type: r,
                        extractor_config: m,
                        extractor_type: "URI",
                        id: a,
                      };
                  }
                  return null;
                }
                o.exports = d;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("signalsFBEventsCoercePixelID", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                t = e.logUserError,
                n = a.getFbeventsModules("SignalsFBEventsTyped"),
                r = n.Typed,
                i = n.coerce;
              function l(e) {
                var n = i(e, r.fbid());
                if (n == null) {
                  var o = JSON.stringify(n);
                  return (
                    t({
                      pixelID: o != null ? o : "undefined",
                      type: "INVALID_PIXEL_ID",
                    }),
                    null
                  );
                }
                return n;
              }
              o.exports = l;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "signalsFBEventsCoerceStandardParameter",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                  t = e.FBSet,
                  n = new t([
                    "content_category",
                    "content_ids",
                    "content_name",
                    "content_type",
                    "currency",
                    "contents",
                    "num_items",
                    "order_id",
                    "predicted_ltv",
                    "search_string",
                    "status",
                    "subscription_id",
                    "value",
                    "id",
                    "item_price",
                    "quantity",
                    "ct",
                    "db",
                    "em",
                    "external_id",
                    "fn",
                    "ge",
                    "ln",
                    "namespace",
                    "ph",
                    "st",
                    "zp",
                  ]);
                function r(e) {
                  return typeof e == "string" && n.has(e) ? e : null;
                }
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsComparedManagers", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsURLManager"),
                r = a.getFbeventsModules("SignalsFBEventsCookieManager"),
                i = a.getFbeventsModules("SignalsFBEventsRawCookieOps"),
                l = i.readCookieRaw,
                s = i.doRawCookieWrite,
                u = a.getFbeventsModules("SignalsFBEventsLogging"),
                c = u.logWarning,
                d = !1;
              function m(e) {
                d = e;
              }
              function p() {
                var t = n.href,
                  r = e.getURL();
                return (
                  t !== r &&
                    c(
                      new Error(
                        "[URLManager] getURL mismatch: control="
                          .concat(t, ", test=")
                          .concat(r)
                      )
                    ),
                  d ? r : t
                );
              }
              function _() {
                var n = t.referrer,
                  r = e.getReferrer();
                return (
                  n !== r &&
                    c(
                      new Error(
                        "[URLManager] getReferrer mismatch: control="
                          .concat(n, ", test=")
                          .concat(r)
                      )
                    ),
                  d ? r : n
                );
              }
              function f(e) {
                var t = l(e),
                  n = r.getCookieRaw(e);
                return (
                  t !== n &&
                    c(
                      new Error(
                        "[CookieManager] getCookieRaw mismatch: cookie name=".concat(
                          e
                        )
                      )
                    ),
                  d ? n : t
                );
              }
              function g(e) {
                d ? r.setCookieRaw(e) : s(e);
              }
              o.exports = {
                getComparedURL: p,
                getComparedReferrer: _,
                getComparedCookieRaw: f,
                setComparedCookieRaw: g,
                setRolloutEnabled: m,
                updateCookieCache: r.updateCookieCache,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsConfigLoadedEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("signalsFBEventsCoercePixelID");
              function n(e) {
                var n = t(e);
                return n != null ? [n] : null;
              }
              var r = new e(n);
              o.exports = r;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsConfigStore", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules(
                  "signalsFBEventsCoerceAutomaticMatchingConfig"
                ),
                t = a.getFbeventsModules("signalsFBEventsCoerceBatchingConfig"),
                n = a.getFbeventsModules(
                  "signalsFBEventsCoerceInferredEventsConfig"
                ),
                r = a.getFbeventsModules("signalsFBEventsCoercePixelID"),
                i = a.getFbeventsModules("SignalsFBEventsLogging"),
                l = i.logError,
                s = a.getFbeventsModules("SignalsFBEventsUtils"),
                u = s.hasOwn,
                c = a.getFbeventsModules("SignalsFBEventsQE"),
                d = a.getFbeventsModules(
                  "SignalsFBEventsBrowserPropertiesConfigTypedef"
                ),
                m = a.getFbeventsModules("SignalsFBEventsBufferConfigTypedef"),
                p = a.getFbeventsModules(
                  "SignalsFBEventsESTRuleEngineConfigTypedef"
                ),
                _ = a.getFbeventsModules(
                  "SignalsFBEventsDataProcessingOptionsConfigTypedef"
                ),
                f = a.getFbeventsModules(
                  "SignalsFBEventsDisabledExtensionsConfigTypedef"
                ),
                g = a.getFbeventsModules(
                  "SignalsFBEventsDefaultCustomDataConfigTypedef"
                ),
                h = a.getFbeventsModules(
                  "SignalsFBEventsMicrodataConfigTypedef"
                ),
                y = a.getFbeventsModules(
                  "SignalsFBEventsOpenBridgeConfigTypedef"
                ),
                C = a.getFbeventsModules(
                  "SignalsFBEventsParallelFireConfigTypedef"
                ),
                b = a.getFbeventsModules(
                  "SignalsFBEventsProhibitedSourcesTypedef"
                ),
                v = a.getFbeventsModules(
                  "SignalsFBEventsTriggerSgwPixelTrackCommandConfigTypedef"
                ),
                R = a.getFbeventsModules("SignalsFBEventsTyped"),
                L = R.Typed,
                E = R.coerce,
                k = a.getFbeventsModules("SignalsFBEventsUnwantedDataTypedef"),
                I = a.getFbeventsModules(
                  "SignalsFBEventsEventValidationConfigTypedef"
                ),
                T = a.getFbeventsModules(
                  "SignalsFBEventsProtectedDataModeConfigTypedef"
                ),
                D = a.getFbeventsModules(
                  "SignalsFBEventsClientHintConfigTypedef"
                ),
                x = a.getFbeventsModules(
                  "SignalsFBEventsCCRuleEvaluatorConfigTypedef"
                ),
                P = a.getFbeventsModules(
                  "SignalsFBEventsRestrictedDomainsConfigTypedef"
                ),
                M = a.getFbeventsModules(
                  "SignalsFBEventsIABPCMAEBridgeConfigTypedef"
                ),
                w = a.getFbeventsModules(
                  "SignalsFBEventsCookieDeprecationLabelConfigTypedef"
                ),
                A = a.getFbeventsModules(
                  "SignalsFBEventsUnwantedEventsConfigTypedef"
                ),
                F = a.getFbeventsModules(
                  "SignalsFBEventsUnwantedEventNamesConfigTypedef"
                ),
                O = a.getFbeventsModules(
                  "SignalsFBEventsUnwantedParamsConfigTypedef"
                ),
                B = a.getFbeventsModules(
                  "SignalsFBEventsStandardParamChecksConfigTypedef"
                ),
                W = a.getFbeventsModules(
                  "SignalsFBEventsSmartSetupPixelConfigTypedef"
                ),
                q = a.getFbeventsModules(
                  "SignalsFBEventsClientSidePixelForkingConfigTypedef"
                ),
                U = a.getFbeventsModules("SignalsFBEventsCookieConfigTypedef"),
                V = a.getFbeventsModules("SignalsFBEventsGatingConfigTypedef"),
                H = a.getFbeventsModules(
                  "SignalsFBEventsProhibitedPixelConfigTypedef"
                ),
                G = a.getFbeventsModules("SignalsFBEventsWebchatConfigTypedef"),
                z = a.getFbeventsModules(
                  "SignalsFBEventsImagePixelOpenBridgeConfigTypedef"
                ),
                j = a.getFbeventsModules(
                  "SignalsFBEventsBotBlockingConfigTypedef"
                ),
                K = a.getFbeventsModules(
                  "SignalsFBEventsURLMetadataConfigTypedef"
                ),
                Q = a.getFbeventsModules(
                  "SignalsFBEventsQualityCheckerConfigTypedef"
                ),
                X = a.getFbeventsModules("SignalsFBEventsMetaQEConfigTypedef"),
                Y = a.getFbeventsModules(
                  "SignalsFBEventsGoogleAnalyticsBridgeConfigTypedef"
                ),
                J = a.getFbeventsModules(
                  "SignalsFBEventsBrowserPropertiesPlatformConfigTypedef"
                ),
                Z = a.getFbeventsModules(
                  "SignalsFBEventsMicrodataFieldTransmissionConfigTypedef"
                ),
                ee = a.getFbeventsModules(
                  "SignalsFBEventsRegexParamFilterConfigTypedef"
                ),
                te = a.getFbeventsModules(
                  "SignalsFBEventsMicrodataCoverageConfigTypedef"
                ),
                ne = te.SignalsFBEventsMicrodataCoverageConfigTypedef,
                re = a.getFbeventsModules(
                  "SignalsFBEventsShopifySandboxContextConfigTypedef"
                ),
                oe = a.getFbeventsModules(
                  "SignalsFBEventsShopifySandboxConfigTypedef"
                ),
                ae = "global",
                ie = {
                  automaticMatching: e,
                  openbridge: y,
                  batching: t,
                  inferredEvents: n,
                  microdata: h,
                  prohibitedSources: b,
                  unwantedData: k,
                  dataProcessingOptions: _,
                  parallelfire: C,
                  buffer: m,
                  browserProperties: d,
                  defaultCustomData: g,
                  estRuleEngine: p,
                  eventValidation: I,
                  protectedDataMode: T,
                  clientHint: D,
                  ccRuleEvaluator: x,
                  restrictedDomains: P,
                  IABPCMAEBridge: M,
                  cookieDeprecationLabel: w,
                  unwantedEvents: A,
                  unwantedEventNames: F,
                  unwantedParams: O,
                  standardParamChecks: B,
                  smartSetup: W,
                  clientSidePixelForking: q,
                  cookie: U,
                  gating: V,
                  prohibitedPixels: H,
                  triggersgwpixeltrackcommand: v,
                  webchat: G,
                  imagepixelopenbridge: z,
                  botblocking: j,
                  disabledExtensions: f,
                  urlMetadata: K,
                  qualityChecker: Q,
                  metaQE: X,
                  googleAnalyticsBridge: Y,
                  browserPropertiesPlatform: J,
                  microdataFieldTransmission: Z,
                  regexParamFilter: ee,
                  microdataCoverage: ne,
                  shopifySandboxContext: re,
                  shopifySandbox: oe,
                };
              function le() {
                for (var e = {}, t = Object.keys(ie), n = 0; n < t.length; n++)
                  e[t[n]] = {};
                return e;
              }
              var se = (function () {
                function e() {
                  $(this, e), S(this, "_configStore", le());
                }
                return N(e, [
                  {
                    key: "set",
                    value: function (t, n, o) {
                      var e = t == null ? ae : r(t);
                      if (e != null) {
                        var a = ue(n);
                        a != null &&
                          this._configStore[a] != null &&
                          (this._configStore[a][e] =
                            ie[a] != null ? ie[a](o) : o);
                      }
                    },
                  },
                  {
                    key: "setExperimental",
                    value: function (t) {
                      var e = E(
                        t,
                        L.objectWithFields({
                          config: L.object(),
                          experimentName: L.string(),
                          pixelID: r,
                          pluginName: L.string(),
                        })
                      );
                      if (e != null) {
                        var n = e.config,
                          o = e.experimentName,
                          a = e.pixelID,
                          i = e.pluginName;
                        c.isInTest(o) && this.set(a, i, n);
                      }
                    },
                  },
                  {
                    key: "get",
                    value: function (t, n) {
                      return this._configStore[n][t != null ? t : ae];
                    },
                  },
                  {
                    key: "getWithGlobalFallback",
                    value: function (t, n) {
                      var e = ae,
                        r = this._configStore[n];
                      return t != null && u(r, t) && (e = t), r[e];
                    },
                  },
                  {
                    key: "getAutomaticMatchingConfig",
                    value: function (t) {
                      return (
                        l(
                          new Error(
                            "Calling legacy api getAutomaticMatchingConfig"
                          )
                        ),
                        this.get(t, "automaticMatching")
                      );
                    },
                  },
                  {
                    key: "getInferredEventsConfig",
                    value: function (t) {
                      return (
                        l(
                          new Error(
                            "Calling legacy api getInferredEventsConfig"
                          )
                        ),
                        this.get(t, "inferredEvents")
                      );
                    },
                  },
                ]);
              })();
              function ue(e) {
                var t,
                  n = E(e, L.string());
                if (n == null) return null;
                var r = Object.keys(ie);
                return (t = r.find(function (e) {
                  return e === n;
                })) !== null && t !== void 0
                  ? t
                  : null;
              }
              o.exports = new se();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsCookieConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    fbcParamsConfig: t.allowNull(
                      t.objectWithFields({
                        params: t.arrayOf(
                          t.objectWithFields({
                            ebp_path: t.string(),
                            prefix: t.string(),
                            query: t.string(),
                          })
                        ),
                      })
                    ),
                    enableFbcParamSplitAll: t.allowNull(t.boolean()),
                    maxMultiFbcQueueSize: t.allowNull(t.number()),
                    enableFbcParamSplitSafariOnly: t.allowNull(t.boolean()),
                    enableAemSourceTagToLocalStorage: t.allowNull(t.boolean()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsCookieDeprecationLabelConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    delayInMs: t.allowNull(t.number()),
                    disableBackupTimeout: t.allowNull(t.boolean()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsCookieManager", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsRawCookieOps"),
                t = e.readCookieRaw,
                n = e.doRawCookieWrite,
                r = [];
              function i(e) {
                for (var n = 0; n < r.length; n++) {
                  var o = r[n];
                  if (o != null && !o.disabled) return o.getCookieRaw(e);
                }
                return t(e);
              }
              function l(e) {
                for (var t = 0; t < r.length; t++) {
                  var o = r[t];
                  if (o != null && !o.disabled && o.setCookieRaw != null) {
                    o.setCookieRaw(e);
                    return;
                  }
                }
                n(e);
              }
              function s(e, t) {
                for (var n = 0; n < r.length; n++) {
                  var o = r[n];
                  if (o != null && !o.disabled && o.updateCookieCache != null) {
                    o.updateCookieCache(e, t);
                    return;
                  }
                }
              }
              o.exports = {
                providers: r,
                getCookieRaw: i,
                setCookieRaw: l,
                updateCookieCache: s,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsCorrectPIIPlacement",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                  t = e.logError,
                  n = a.getFbeventsModules("SignalsFBEventsUtils"),
                  r = n.each,
                  i = n.keys,
                  l = a.getFbeventsModules("SignalsPixelPIIUtils"),
                  s = l.isZipCode,
                  u = a.getFbeventsModules("SignalsPixelPIIUtils"),
                  c = u.isEmail,
                  d = u.isPhoneNumber,
                  m = u.getGenderCharacter,
                  p = a.getFbeventsModules("SignalsPixelPIIConstants"),
                  _ = p.PII_KEYS_TO_ALIASES_EXPANDED;
                function f(e) {
                  try {
                    if (e == null || G(e) !== "object") return e;
                    var n = {};
                    r(i(e), function (t) {
                      typeof t == "string" && typeof t.toLowerCase == "function"
                        ? (n[t.toLowerCase()] = e[t])
                        : (n[t] = e[t]);
                    }),
                      r(i(_), function (t) {
                        if (e[t] == null) {
                          var o = _[t];
                          r(o, function (r) {
                            e[t] == null &&
                              r in n &&
                              n[r] != null &&
                              (e[t] = n[r]);
                          });
                        }
                      }),
                      r(i(e), function (t) {
                        var n = e[t];
                        if (n != null) {
                          if (e.em == null && c(n)) {
                            e.em = n;
                            return;
                          }
                          if (e.ph == null && d(n)) {
                            e.ph = n;
                            return;
                          }
                          if (e.zp == null && s(n)) {
                            e.zp = n;
                            return;
                          }
                          if (
                            e.ge == null &&
                            typeof n == "string" &&
                            typeof n.toLowerCase == "function" &&
                            (m(n.toLowerCase()) == "m" ||
                              m(n.toLowerCase()) == "f")
                          ) {
                            e.ge = m(n);
                            return;
                          }
                        }
                      });
                  } catch (e) {
                    (e.message = "[Placement Fix]:" + e.message), t(e);
                  }
                  return e;
                }
                o.exports = f;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsCreateTrustedTypePolicy",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              a = o.exports;
            return (
              (function () {
                "use strict";
                function t(t, n) {
                  try {
                    if (e.trustedTypes && e.trustedTypes.createPolicy) {
                      var r = e.trustedTypes;
                      return r.createPolicy(t, { createScriptURL: n });
                    }
                  } catch (e) {}
                  return null;
                }
                o.exports = t;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsDataProcessingOptionsConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    dataProcessingOptions: t.withValidation({
                      def: t.arrayOf(t.string()),
                      validators: [
                        function (e) {
                          return e.reduce(function (e, t) {
                            return e === !0 && t === "LDU";
                          }, !0);
                        },
                      ],
                    }),
                    dataProcessingCountry: t.withValidation({
                      def: t.allowNull(t.number()),
                      validators: [
                        function (e) {
                          return e === null || e === 0 || e === 1;
                        },
                      ],
                    }),
                    dataProcessingState: t.withValidation({
                      def: t.allowNull(t.number()),
                      validators: [
                        function (e) {
                          return e === null || e === 0 || e === 1e3;
                        },
                      ],
                    }),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsDefaultCustomDataConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    enable_order_id: t.boolean(),
                    enable_value: t.boolean(),
                    enable_currency: t.boolean(),
                    enable_contents: t.boolean(),
                    enable_content_ids: t.boolean(),
                    enable_content_type: t.boolean(),
                    experiment: t.allowNull(t.string()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsDisabledExtensionsConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    disabledExtensions: t.withValidation({
                      def: t.arrayOf(t.string()),
                      validators: [
                        function (e) {
                          return e.reduce(function (e, t) {
                            return (
                              e === !0 &&
                              t ===
                                "whatsapp_marketing_messaging_customer_subscription"
                            );
                          }, !0);
                        },
                      ],
                    }),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsDoAutomaticMatching",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                  t = e.keys,
                  n = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                  r = a.getFbeventsModules("SignalsFBEventsEvents"),
                  i = r.piiAutomatched;
                function l(e, r, o, a, l, s) {
                  var u = s != null ? s : n.get(r.id, "automaticMatching");
                  if (t(o).length > 0 && u != null) {
                    var c = u.selectedMatchKeys;
                    for (var d in o)
                      c.indexOf(d) >= 0 &&
                        ((r.userDataFormFields[d] = o[d]),
                        l != null &&
                          d in l &&
                          (r.censoredUserDataFormatFormFields[d] = l[d]),
                        a != null &&
                          d in a &&
                          (r.alternateUserDataFormFields[d] = a[d]));
                    i.trigger(r);
                  }
                }
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsESTRuleEngineConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    experimentName: t.allowNull(t.string()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsEvents", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsCheckGateEvent"),
                n = a.getFbeventsModules("SignalsFBEventsConfigLoadedEvent"),
                r = a.getFbeventsModules("SignalsFBEventsFiredEvent"),
                i = a.getFbeventsModules(
                  "SignalsFBEventsGetCustomParametersEvent"
                ),
                l = a.getFbeventsModules(
                  "SignalsFBEventsGetIWLParametersEvent"
                ),
                s = a.getFbeventsModules("SignalsFBEventsIWLBootStrapEvent"),
                u = a.getFbeventsModules("SignalsFBEventsPIIAutomatchedEvent"),
                c = a.getFbeventsModules("SignalsFBEventsPIIConflictingEvent"),
                d = a.getFbeventsModules("SignalsFBEventsPIIInvalidatedEvent"),
                m = a.getFbeventsModules("SignalsFBEventsPluginLoadedEvent"),
                p = a.getFbeventsModules("SignalsFBEventsSetEventIDEvent"),
                _ = a.getFbeventsModules(
                  "SignalsFBEventsSetIWLExtractorsEvent"
                ),
                f = a.getFbeventsModules(
                  "SignalsFBEventsSetIWLParameterRulesEvent"
                ),
                g = a.getFbeventsModules("SignalsFBEventsSetESTRules"),
                h = a.getFbeventsModules("SignalsFBEventsSetCCRules"),
                y = a.getFbeventsModules(
                  "SignalsFBEventsValidateCustomParametersEvent"
                ),
                C = a.getFbeventsModules(
                  "SignalsFBEventsLateValidateCustomParametersEvent"
                ),
                b = a.getFbeventsModules(
                  "SignalsFBEventsValidateUrlParametersEvent"
                ),
                v = a.getFbeventsModules(
                  "SignalsFBEventsValidateGetClickIDFromBrowserProperties"
                ),
                S = a.getFbeventsModules(
                  "SignalsFBEventsValidateGetIMEFromBrowserPropertiesPlatform"
                ),
                R = a.getFbeventsModules("SignalsFBEventsExtractPII"),
                L = a.getFbeventsModules(
                  "SignalsFBEventsGetAutomaticParametersEvent"
                ),
                E = a.getFbeventsModules("SignalsFBEventsSendEventEvent"),
                k = a.getFbeventsModules(
                  "SignalsFBEventsAutomaticPageViewEvent"
                ),
                I = a.getFbeventsModules("SignalsFBEventsWebChatEvent"),
                T = {
                  gateCheckEvent: t,
                  configLoaded: n,
                  execEnd: new e(),
                  fired: r,
                  getCustomParameters: i,
                  getIWLParameters: l,
                  iwlBootstrap: s,
                  piiAutomatched: u,
                  piiConflicting: c,
                  piiInvalidated: d,
                  pluginLoaded: m,
                  setEventId: p,
                  setIWLExtractors: _,
                  setIWLParameterRules: f,
                  setESTRules: g,
                  setCCRules: h,
                  validateCustomParameters: y,
                  lateValidateCustomParameters: C,
                  validateUrlParameters: b,
                  getClickIDFromBrowserProperties: v,
                  getIMEFromBrowserPropertiesPlatform: S,
                  extractPii: R,
                  getAutomaticParameters: L,
                  SendEventEvent: E,
                  automaticPageView: k,
                  webchatEvent: I,
                };
              o.exports = T;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsEventValidationConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    unverifiedEventNames: t.allowNull(t.arrayOf(t.string())),
                    enableEventSanitization: t.allowNull(t.boolean()),
                    restrictedEventNames: t.allowNull(t.arrayOf(t.string())),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsExperimentNames", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              o.exports = {
                NO_OP_EXPERIMENT: "no_op_exp",
                AUTOMATIC_PARAMETERS_JSON_AUTO_FIX:
                  "automatic_parameters_json_auto_fix",
                BUTTON_CLICK_OPTIMIZE_EXPERIMENT_V2:
                  "button_click_optimize_experiment_v2",
                HIGH_FETCH_PRIORITY_IMAGE: "high_fetch_priority_image",
                MICRODATA_REFACTOR_MIGRATION_AUTOMATIC_PARAMETERS:
                  "microdata_refactor_migration_automatic_parameters",
                MICRODATA_REFACTOR_MIGRATION_PAGE_META_DATA:
                  "microdata_refactor_migration_page_meta_data",
                COOKIE_TTL_FIX: "cookie_ttl_fix",
                IN_MEMORY_COOKIE_JAR: "in_memory_cookie_jar",
                PAGE_TITLE_OG_FALLBACK: "page_title_og_fallback",
                ANDROID_IAB_MAX_GET_LENGTH_32K:
                  "android_iab_max_get_length_32k",
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsExperimentsTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.arrayOf(
                    t.objectWithFields({
                      allocation: t.number(),
                      code: t.string(),
                      name: t.string(),
                      passRate: t.number(),
                    })
                  );
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsExperimentsV2Typedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.arrayOf(
                    t.objectWithFields({
                      evaluationType: t.enumeration({
                        eventlevel: "EVENT_LEVEL",
                        pageloadlevel: "PAGE_LOAD_LEVEL",
                      }),
                      universe: t.string(),
                      allocation: t.number(),
                      code: t.string(),
                      name: t.string(),
                      passRate: t.number(),
                    })
                  );
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsExtractPII", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                n = a.getFbeventsModules("SignalsFBEventsTyped"),
                r = n.Typed,
                i = n.coerce;
              function l(e, n, o) {
                var a = i(e, t),
                  l = r.allowNull(r.object()),
                  s = r.allowNull(r.object());
                return a != null ? [{ pixel: a, form: l, button: s }] : null;
              }
              var s = new e(l);
              o.exports = s;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsFBQ", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var r = a.getFbeventsModules("SignalsEventValidation"),
                i = a.getFbeventsModules("handleEventIdOverride"),
                l = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                s = a.getFbeventsModules("SignalsFBEventsEvents"),
                u = s.configLoaded,
                c = a.getFbeventsModules("SignalsFBEventsFireLock"),
                d = a.getFbeventsModules("SignalsFBEventsJSLoader"),
                m = a.getFbeventsModules("SignalsFBEventsLogging"),
                p = a.getFbeventsModules("SignalsFBEventsOptIn"),
                _ = a.getFbeventsModules("SignalsFBEventsUtils"),
                f = a.getFbeventsModules("SignalsFBEventsGetValidUrl"),
                g = a.getFbeventsModules("SignalsFBEventsResolveLink"),
                h = a.getFbeventsModules("SignalsFBEventsQEV2"),
                y = a.getFbeventsModules("SignalsFBEventsModuleEncodings"),
                C = a.getFbeventsModules("SignalsParamList"),
                b = a.getFbeventsModules("signalsFBEventsSendEvent"),
                R = b.sendEvent,
                L = a.getFbeventsModules("SignalsFBEventsAsyncParamUtils"),
                E = L.registerAsyncParamAllSettledListener,
                k = L.flushAsyncParamEventQueue,
                T = _.each,
                D = _.keys,
                x = _.map,
                P = _.some,
                M = m.logError,
                w = m.logUserError,
                A = a.getFbeventsModules("SignalsFBEventsPixelQueueState"),
                F = A.trySetQueueHandler,
                O = {
                  AutomaticMatching: !0,
                  AutomaticMatchingForPartnerIntegrations: !0,
                  DefaultCustomData: !0,
                  Buffer: !0,
                  CommonIncludes: !0,
                  FirstPartyCookies: !0,
                  IWLBootstrapper: !0,
                  IWLParameters: !0,
                  IWLParameterRules: !0,
                  IdentifyIntegration: !0,
                  InferredEvents: !0,
                  Microdata: !0,
                  MicrodataJsonLd: !0,
                  OpenBridge: !0,
                  ParallelFire: !0,
                  ProhibitedSources: !0,
                  Timespent: !0,
                  UnwantedData: !0,
                  LocalComputation: !0,
                  IABPCMAEBridge: !0,
                  BrowserProperties: !0,
                  ESTRuleEngine: !0,
                  EventValidation: !0,
                  ProtectedDataMode: !0,
                  PrivacySandbox: !0,
                  ClientHint: !0,
                  CCRuleEvaluator: !0,
                  ProhibitedPixels: !0,
                  LastExternalReferrer: !0,
                  CookieDeprecationLabel: !0,
                  UnwantedEvents: !0,
                  UnwantedEventNames: !0,
                  UnwantedParams: !0,
                  StandardParamChecks: !0,
                  ShopifyAppIntegratedPixel: !0,
                  ShopifySandbox: !0,
                  clientSidePixelForking: !0,
                  ShadowTest: !0,
                  TopicsAPI: !0,
                  Gating: !0,
                  AutomaticParameters: !0,
                  LeadEventId: !0,
                  EngagementData: !0,
                  TriggerSgwPixelTrackCommand: !0,
                  DomainBlocking: !0,
                  WebChat: !0,
                  ScrollDepth: !0,
                  PageMetadata: !0,
                  WebsitePerformance: !0,
                  ImagePixelOpenBridge: !0,
                  SmartSetup: !0,
                  BotBlocking: !0,
                  URLParamSchematization: !0,
                  URLMetadata: !0,
                  PrivacyPreservingDataLookup: !0,
                  GoogleAnalyticsBridge: !0,
                  BrowserPropertiesPlatform: !0,
                  MicrodataFieldTransmission: !0,
                  RegexParamFilter: !0,
                  MicrodataCoverage: !0,
                },
                B = {
                  Track: 0,
                  TrackCustom: 4,
                  TrackSingle: 1,
                  TrackSingleCustom: 2,
                  TrackSingleSystem: 3,
                  TrackSystem: 5,
                },
                W = "global_config",
                q = 200,
                U = [
                  "InferredEvents",
                  "Microdata",
                  "AutomaticParameters",
                  "EngagementData",
                  "PageMetadata",
                  "ScrollDepth",
                  "WebChat",
                  "MicrodataCoverage",
                  "MicrodataFieldTransmission",
                ],
                V = { AutomaticSetup: U },
                H = {
                  AutomaticMatching: ["inferredevents", "identity"],
                  AutomaticMatchingForPartnerIntegrations: [
                    "automaticmatchingforpartnerintegrations",
                  ],
                  CommonIncludes: ["commonincludes"],
                  DefaultCustomData: ["defaultcustomdata"],
                  FirstPartyCookies: ["cookie"],
                  IWLBootstrapper: ["iwlbootstrapper"],
                  IWLParameters: ["iwlparameters"],
                  IWLParameterRules: ["iwlparameterrules"],
                  ESTRuleEngine: ["estruleengine"],
                  IdentifyIntegration: ["identifyintegration"],
                  Buffer: ["buffer"],
                  InferredEvents: ["inferredevents", "identity"],
                  Microdata: ["microdata", "identity"],
                  MicrodataJsonLd: ["jsonld_microdata"],
                  ParallelFire: ["parallelfire"],
                  ProhibitedSources: ["prohibitedsources"],
                  Timespent: ["timespent"],
                  UnwantedData: ["unwanteddata"],
                  LocalComputation: ["localcomputation"],
                  IABPCMAEBridge: ["iabpcmaebridge"],
                  BrowserProperties: ["browserproperties"],
                  EventValidation: ["eventvalidation"],
                  ProtectedDataMode: ["protecteddatamode"],
                  PrivacySandbox: ["privacysandbox"],
                  ClientHint: ["clienthint"],
                  CCRuleEvaluator: ["ccruleevaluator"],
                  ProhibitedPixels: ["prohibitedpixels"],
                  LastExternalReferrer: ["lastexternalreferrer"],
                  CookieDeprecationLabel: ["cookiedeprecationlabel"],
                  UnwantedEvents: ["unwantedevents"],
                  UnwantedEventNames: ["unwantedeventnames"],
                  UnwantedParams: ["unwantedparams"],
                  ShopifyAppIntegratedPixel: ["shopifyappintegratedpixel"],
                  ShopifySandbox: ["shopifysandbox"],
                  clientSidePixelForking: ["clientsidepixelforking"],
                  TopicsAPI: ["topicsapi"],
                  Gating: ["gating"],
                  AutomaticParameters: ["automaticparameters"],
                  LeadEventId: ["leadeventid"],
                  EngagementData: ["engagementdata"],
                  TriggerSgwPixelTrackCommand: ["triggersgwpixeltrackcommand"],
                  DomainBlocking: ["domainblocking"],
                  WebChat: ["webchat"],
                  ScrollDepth: ["scrolldepth"],
                  PageMetadata: ["pagemetadata"],
                  WebsitePerformance: ["websiteperformance"],
                  ImagePixelOpenBridge: ["imagepixelopenbridge"],
                  SmartSetup: ["smartsetup"],
                  BotBlocking: ["botblocking"],
                  URLParamSchematization: ["urlparamschematization"],
                  URLMetadata: ["urlmetadata"],
                  PrivacyPreservingDataLookup: ["privacypreservingdatalookup"],
                  GoogleAnalyticsBridge: ["googleanalyticsbridge"],
                  BrowserPropertiesPlatform: ["browserpropertiesplatform"],
                  MicrodataFieldTransmission: ["microdatafieldtransmission"],
                  RegexParamFilter: ["regexparamfilter"],
                  MicrodataCoverage: ["microdatacoverage"],
                };
              function G(e) {
                return !!(O[e] || V[e]);
              }
              var z = function (t) {
                var e = t.pixelID,
                  n = t.version,
                  r = t.releaseSegment,
                  o = t.noMin,
                  a = t.domain,
                  i = new C(function (e) {
                    return { finalValue: e };
                  });
                return (
                  i.append("v", n),
                  i.append("r", r),
                  o === !0 && i.append("no_min", !0),
                  a != null && a != "" && i.append("domain", a),
                  y.addEncodings(i),
                  ""
                    .concat(d.CONFIG.CDN_BASE_URL, "signals/config/")
                    .concat(e, "?")
                    .concat(i.toPayload().toQueryString())
                );
              };
              function j(e) {
                var t = e.pixelID,
                  n = e.version,
                  r = e.releaseSegment,
                  o = e.domain,
                  a = e.noMin;
                d.loadJSFile(
                  z({
                    pixelID: t,
                    version: n,
                    releaseSegment: r,
                    noMin: a,
                    domain: o,
                  })
                );
              }
              var K = (function () {
                function o(e, t) {
                  var n = this;
                  $(this, o),
                    S(this, "VALID_FEATURES", O),
                    S(this, "optIns", new p(V)),
                    S(this, "configsLoaded", {}),
                    S(this, "locks", c.global),
                    S(this, "pluginConfig", l),
                    S(this, "disableFirstPartyCookies", !1),
                    S(this, "disableAutoConfig", !1),
                    S(this, "disableSmartSetup", !1),
                    S(this, "asyncParamFetchers", new Map()),
                    S(this, "eventQueue", []),
                    S(this, "asyncParamPromisesAllSettled", !0),
                    S(this, "disableAsyncParamBackupTimeout", !1),
                    S(this, "fbp", null),
                    (this.VERSION = e.version),
                    (this.RELEASE_SEGMENT = e._releaseSegment),
                    (this.pixelsByID = t),
                    (this.fbq = e),
                    T(e.pendingConfigs || [], function (e) {
                      return n.locks.lockConfig(e);
                    });
                }
                return N(o, [
                  {
                    key: "optIn",
                    value: function (t, n) {
                      var e = this,
                        r =
                          arguments.length > 2 && arguments[2] !== void 0
                            ? arguments[2]
                            : !1;
                      if (typeof n != "string" || !G(n))
                        throw new Error(
                          'Invalid Argument: "' +
                            n +
                            '" is not a valid opt-in feature'
                        );
                      return (
                        G(n) &&
                          (this.optIns.optIn(t, n, r),
                          T([n].concat(I(V[n] || [])), function (t) {
                            H[t] &&
                              T(H[t], function (t) {
                                return e.fbq.loadPlugin(t);
                              });
                          })),
                        this
                      );
                    },
                  },
                  {
                    key: "optOut",
                    value: function (t, n) {
                      return this.optIns.optOut(t, n), this;
                    },
                  },
                  {
                    key: "consent",
                    value: function (t) {
                      return (
                        t === "revoke"
                          ? this.locks.lockConsent()
                          : t === "grant"
                          ? this.locks.unlockConsent()
                          : w({ action: t, type: "INVALID_CONSENT_ACTION" }),
                        this
                      );
                    },
                  },
                  {
                    key: "setUserProperties",
                    value: function (t, n) {
                      var e = this.pluginConfig.get(
                        null,
                        "dataProcessingOptions"
                      );
                      if (
                        !(e != null && e.dataProcessingOptions.includes("LDU"))
                      ) {
                        if (!_.hasOwn(this.pixelsByID, t)) {
                          w({ pixelID: t, type: "PIXEL_NOT_INITIALIZED" });
                          return;
                        }
                        this.trackSingleSystem({
                          systemCategory: "user_properties",
                          pixel: t,
                          eventName: "UserProperties",
                          customData: v({}, n),
                        });
                      }
                    },
                  },
                  {
                    key: "trackSingle",
                    value: function (t, n, o, a) {
                      return (
                        r.validateEventAndLog(n, o),
                        this.trackSingleGeneric({
                          pixel: t,
                          eventName: n,
                          customData: o,
                          trackMethod: B.TrackSingle,
                          eventData: a,
                        })
                      );
                    },
                  },
                  {
                    key: "trackSingleCustom",
                    value: function (t, n, r, o) {
                      return this.trackSingleGeneric({
                        pixel: t,
                        eventName: n,
                        customData: r,
                        trackMethod: B.TrackSingleCustom,
                        eventData: o,
                      });
                    },
                  },
                  {
                    key: "trackSingleSystem",
                    value: function (t) {
                      var e = t.systemCategory,
                        n = t.pixel,
                        r = t.eventName,
                        o = t.customData,
                        a = t.eventData,
                        i = t.customParams,
                        l = t.experimentId;
                      return this.trackSingleGeneric({
                        pixel: n,
                        eventName: r,
                        customData: o,
                        trackMethod: B.TrackSingleSystem,
                        eventData: a || null,
                        systemCategory: e,
                        customParams: i,
                        experimentId: l,
                      });
                    },
                  },
                  {
                    key: "trackSingleGeneric",
                    value: function (t) {
                      var e = t.pixel,
                        n = t.eventName,
                        r = t.customData,
                        o = t.trackMethod,
                        a = t.eventData,
                        i = t.systemCategory,
                        l = t.customParams,
                        s = t.experimentId,
                        u = typeof e == "string" ? e : e.id,
                        c = s;
                      if (
                        ((c == null || c === "") && (c = Date.now().toString()),
                        !_.hasOwn(this.pixelsByID, u))
                      ) {
                        var d = { pixelID: u, type: "PIXEL_NOT_INITIALIZED" };
                        return (
                          i == null
                            ? w(d)
                            : M(new Error(d.type + " " + d.pixelID)),
                          this
                        );
                      }
                      var m = this.getDefaultSendData(u, n, a, c);
                      return (
                        (m.customData = r),
                        i != null && (m.customParameters = { es: i }),
                        l != null &&
                          (m.customParameters = v(
                            v({}, m.customParameters),
                            l
                          )),
                        (m.customParameters = v(
                          v({}, m.customParameters),
                          {},
                          { tm: "".concat(o) }
                        )),
                        this.fire(m, !1),
                        this
                      );
                    },
                  },
                  {
                    key: "_validateSend",
                    value: function (t, n) {
                      if (!t.eventName || !t.eventName.length) {
                        var e = h.isInMetaQEControl(t.pixelId);
                        if (!e)
                          (t.eventName = ""),
                            (t.customParameters = v(
                              v({}, t.customParameters),
                              {},
                              { "ie[d]": "1" }
                            )),
                            w({ type: "NO_EVENT_NAME" });
                        else throw new Error("Event name not specified");
                      }
                      if (!t.pixelId || !t.pixelId.length)
                        throw new Error("PixelId not specified");
                      if (
                        (t.set &&
                          T(
                            x(D(t.set), function (e) {
                              return r.validateMetadata(e);
                            }),
                            function (e) {
                              if (e.error) throw new Error(e.error);
                              e.warnings.length && T(e.warnings, w);
                            }
                          ),
                        n)
                      ) {
                        var o = r.validateEvent(
                          t.eventName,
                          t.customData || {}
                        );
                        if (o.error) throw new Error(o.error);
                        o.warnings && o.warnings.length && T(o.warnings, w);
                      }
                      return this;
                    },
                  },
                  {
                    key: "_argsHasAnyUserData",
                    value: function (t) {
                      var e = t.userData != null && D(t.userData).length > 0,
                        n =
                          t.userDataFormFields != null &&
                          D(t.userDataFormFields).length > 0;
                      return e || n;
                    },
                  },
                  {
                    key: "fire",
                    value: function (n) {
                      var t =
                        arguments.length > 1 && arguments[1] !== void 0
                          ? arguments[1]
                          : !1;
                      if (
                        (this._validateSend(n, t),
                        (this._argsHasAnyUserData(n) &&
                          !this.fbq.loadPlugin("identity")) ||
                          this.locks.isLocked())
                      )
                        return e.fbq("fire", n), this;
                      var r = n.customParameters,
                        o = "";
                      r && r.es && typeof r.es == "string" && (o = r.es),
                        (n.customData = n.customData || {});
                      var a = this.fbq.getEventCustomParameters(
                        this.getPixel(n.pixelId),
                        n.eventName,
                        n.customData,
                        o,
                        n.eventData
                      );
                      return (
                        i(
                          n.eventData,
                          n.customData || {},
                          a,
                          n.pixelId,
                          n.eventName
                        ),
                        r &&
                          T(D(r), function (e) {
                            if (a.containsKey(e)) {
                              var t = h.isInMetaQEControl(n.pixelId);
                              if (!t)
                                a.replaceEntry(e, r[e]), a.append("ie[c]", "1");
                              else
                                throw new Error(
                                  "Custom parameter ".concat(
                                    e,
                                    " already specified."
                                  )
                                );
                            } else a.append(e, r[e]);
                          }),
                        R(
                          {
                            customData: n.customData,
                            customParams: a,
                            eventName: n.eventName,
                            eventData: n.eventData,
                            id: n.pixelId,
                            piiTranslator: null,
                            experimentId: n.experimentId,
                          },
                          this
                        ),
                        this
                      );
                    },
                  },
                  {
                    key: "callMethod",
                    value: function (t) {
                      var e = t[0],
                        n = Array.prototype.slice.call(t, 1);
                      if (typeof e != "string") {
                        w({ type: "FBQ_NO_METHOD_NAME" });
                        return;
                      }
                      if (typeof this[e] == "function")
                        try {
                          this[e].apply(this, n);
                        } catch (e) {
                          M(e);
                        }
                      else w({ method: e, type: "INVALID_FBQ_METHOD" });
                    },
                  },
                  {
                    key: "getDefaultSendData",
                    value: function (t, n, r, o) {
                      var e = this.getPixel(t),
                        a = {
                          eventData: r || {},
                          eventName: n,
                          pixelId: t,
                          experimentId: o,
                        };
                      return (
                        e &&
                          (e.userData && (a.userData = e.userData),
                          e.agent != null && e.agent !== ""
                            ? (a.set = { agent: e.agent })
                            : this.fbq.agent != null &&
                              this.fbq.agent !== "" &&
                              (a.set = { agent: this.fbq.agent })),
                        a
                      );
                    },
                  },
                  {
                    key: "getOptedInPixels",
                    value: function (t) {
                      var e = this;
                      return this.optIns.listPixelIds(t).map(function (t) {
                        return e.pixelsByID[t];
                      });
                    },
                  },
                  {
                    key: "getPixel",
                    value: function (t) {
                      return this.pixelsByID[t];
                    },
                  },
                  {
                    key: "loadConfig",
                    value: function (r) {
                      if (
                        !(
                          this.fbq.disableConfigLoading === !0 ||
                          _.hasOwn(this.configsLoaded, r)
                        ) &&
                        (this.locks.lockConfig(r),
                        !this.fbq.pendingConfigs ||
                          P(this.fbq.pendingConfigs, function (e) {
                            return e === r;
                          }) === !1)
                      ) {
                        var e = n.href,
                          o = t.referrer,
                          a = g(e, o, { google: !0 }),
                          i = f(a),
                          l = "";
                        i != null && (l = i.hostname),
                          j({
                            pixelID: r,
                            version: this.VERSION,
                            releaseSegment:
                              this.RELEASE_SEGMENT != null
                                ? this.RELEASE_SEGMENT
                                : "stable",
                            domain: l,
                            noMin: this.fbq._no_min,
                          });
                      }
                    },
                  },
                  {
                    key: "configLoaded",
                    value: function (t) {
                      var e = this;
                      (this.configsLoaded[t] = !0),
                        u.trigger(t),
                        this.locks.releaseConfig(t),
                        F(
                          t,
                          this.fbq.version,
                          this.fbq._releaseSegment,
                          this.pluginConfig.get(t, "qualityChecker")
                        ),
                        t !== W &&
                          (E(this),
                          this.disableAsyncParamBackupTimeout ||
                            setTimeout(function () {
                              k(e);
                            }, q));
                    },
                  },
                ]);
              })();
              o.exports = K;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsFeatureGate", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsConfigStore");
              function t(e, t) {
                return isNaN(t) ? !1 : n(e, t.toString());
              }
              function n(t, n) {
                var r = e.get(n, "gating");
                if (r == null || r.gatings == null) return !1;
                var o = r.gatings.find(function (e) {
                  return e != null && e.name === t;
                });
                return o != null && o.passed === !0;
              }
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsFillParamList", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsParamList"),
                n = a.getFbeventsModules("SignalsFBEventsUtils"),
                r = n.hasOwn,
                i = a.getFbeventsModules("SignalsFBEventsQE"),
                l = a.getFbeventsModules("SignalsFBEventsQEV2"),
                s = a.getFbeventsModules("SignalsFBEventsComparedManagers"),
                u = e.top !== e;
              function c(n) {
                var o = n.customData,
                  a = n.customParams,
                  c = n.eventName,
                  d = n.id,
                  m = n.piiTranslator,
                  p = n.documentLink,
                  _ = n.referrerLink,
                  f = n.timestamp,
                  g = n.experimentId,
                  h = o != null ? v({}, o) : null,
                  y = s.getComparedURL();
                r(n, "documentLink") ? (y = p) : (n.documentLink = y);
                var C = s.getComparedReferrer();
                r(n, "referrerLink") ? (C = _) : (n.referrerLink = C);
                var b = new t(m);
                b.append("id", d),
                  b.append("ev", c),
                  b.append("dl", y),
                  b.append("rl", C),
                  b.append("if", u),
                  b.append("ts", f),
                  b.append("cd", h),
                  b.append("sw", e.screen.width),
                  b.append("sh", e.screen.height),
                  a && b.addRange(a);
                var S = i.get();
                S != null && b.append("exp", i.getCode()),
                  l.isInTest("event_level_no_op_experiment", g);
                var R = d == null ? void 0 : d.toString(),
                  L = l.getExperimentResultParams(g, R);
                return L != null && L.length > 0 && b.append("expv2", L), b;
              }
              o.exports = c;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsFilterProtectedModeEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsTyped"),
                  n = t.Typed,
                  r = a.getFbeventsModules(
                    "SignalsFBEventsMessageParamsTypedef"
                  ),
                  i = new e(n.tuple([r]));
                o.exports = i;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsFiredEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsEventPayload");
              function n(e, n) {
                var r = null;
                (e === "GET" ||
                  e === "POST" ||
                  e === "BEACON" ||
                  e === "FETCH") &&
                  (r = e);
                var o = n instanceof t ? n : null;
                return r != null && o != null ? [r, o] : null;
              }
              var r = new e(n);
              o.exports = r;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsFireEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                t = e.logInfo,
                n = a.getFbeventsModules("SignalsFBEventsEvents"),
                r = n.fired,
                i = a.getFbeventsModules("SignalsFBEventsQE"),
                l = a.getFbeventsModules("SignalsFBEventsExperimentNames"),
                s = l.NO_OP_EXPERIMENT,
                u = a.getFbeventsModules("SignalsFBEventsQEV2"),
                c = a.getFbeventsModules("signalsFBEventsSendBeacon"),
                d = a.getFbeventsModules("signalsFBEventsSendGET"),
                m = a.getFbeventsModules("signalsFBEventsSendFormPOST"),
                p = a.getFbeventsModules("SignalsFBEventsForkEvent"),
                _ = a.getFbeventsModules("SignalsFBEventsGetTimingsEvent"),
                f = a.getFbeventsModules("signalsFBEventsGetIsChrome"),
                g = a.getFbeventsModules("signalsFBEventsFillParamList"),
                h = "SubscribedButtonClick";
              function y(e) {
                p.trigger(e),
                  e.id === "568414510204424" &&
                    t(
                      new Error("Event fired for pixel 568414510204424"),
                      "pixel",
                      e.eventName
                    );
                var n = g(e);
                _.trigger(n), i.isInTest(s);
                var r = n.toPayload();
                C(r, e.experimentId);
              }
              function C(e, t) {
                var n = e.get("ev"),
                  o = !f();
                if (o && n === h && c(e)) {
                  r.trigger("BEACON", e);
                  return;
                }
                var a = e.get("id"),
                  i = !u.isInMetaQEControl(a),
                  l = u.getExperimentResultParams(t, a);
                if (d(e, { highFetchPriority: i, expv2: l })) {
                  r.trigger("GET", e);
                  return;
                }
                if (o && c(e)) {
                  r.trigger("BEACON", e);
                  return;
                }
                m(e), r.trigger("POST", e);
              }
              o.exports = y;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsFireLock", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function (e) {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsUtils"),
                n = t.each,
                r = t.hasOwn,
                i = t.keys,
                l = (function () {
                  function e() {
                    $(this, e),
                      S(this, "_locks", {}),
                      S(this, "_callbacks", []);
                  }
                  return N(e, [
                    {
                      key: "lock",
                      value: function (t) {
                        this._locks[t] = !0;
                      },
                    },
                    {
                      key: "release",
                      value: function (t) {
                        r(this._locks, t) &&
                          (delete this._locks[t],
                          i(this._locks).length === 0 &&
                            n(this._callbacks, function (e) {
                              return e(t);
                            }));
                      },
                    },
                    {
                      key: "onUnlocked",
                      value: function (t) {
                        this._callbacks.push(t);
                      },
                    },
                    {
                      key: "isLocked",
                      value: function () {
                        return i(this._locks).length > 0;
                      },
                    },
                    {
                      key: "lockPlugin",
                      value: function (t) {
                        this.lock("plugin:".concat(t));
                      },
                    },
                    {
                      key: "releasePlugin",
                      value: function (t) {
                        this.release("plugin:".concat(t));
                      },
                    },
                    {
                      key: "lockConfig",
                      value: function (t) {
                        this.lock("config:".concat(t));
                      },
                    },
                    {
                      key: "releaseConfig",
                      value: function (t) {
                        this.release("config:".concat(t));
                      },
                    },
                    {
                      key: "lockConsent",
                      value: function () {
                        this.lock("consent");
                      },
                    },
                    {
                      key: "unlockConsent",
                      value: function () {
                        this.release("consent");
                      },
                    },
                  ]);
                })();
              (e = l), S(l, "global", new e()), (o.exports = l);
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsForkEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsParamList"),
                n = a.getFbeventsModules("SignalsFBEventsTyped"),
                r = n.Typed,
                i = r.objectWithFields({
                  customData: r.allowNull(r.object()),
                  customParams: function (n) {
                    return n instanceof t ? n : void 0;
                  },
                  eventName: r.string(),
                  id: r.string(),
                  piiTranslator: function (t) {
                    return typeof t == "function" ? t : void 0;
                  },
                  documentLink: r.allowNull(r.string()),
                  referrerLink: r.allowNull(r.string()),
                }),
                l = new e(r.tuple([i]));
              o.exports = l;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsGatingConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    gatings: t.arrayOf(
                      t.allowNull(
                        t.objectWithFields({
                          name: t.allowNull(t.string()),
                          passed: t.allowNull(t.boolean()),
                        })
                      )
                    ),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsGetAutomaticParametersEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsTyped"),
                  n = t.Typed,
                  r = t.coerce;
                function i(e, t) {
                  var o = r(e, n.string()),
                    a = r(t, n.string());
                  return o != null && a != null ? [o, a] : null;
                }
                var l = new e(i);
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsGetCustomParametersEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  n = a.getFbeventsModules("SignalsFBEventsTyped"),
                  r = n.Typed,
                  i = n.coerce;
                function l(e, n, o, a, l) {
                  var s = i(e, t),
                    u = i(n, r.string()),
                    c = {};
                  o != null && G(o) === "object" && (c = o);
                  var d = a != null && typeof a == "string" ? a : null,
                    m = {};
                  return (
                    l != null && G(l) === "object" && (m = l),
                    s != null && u != null ? [s, u, c, d, m] : null
                  );
                }
                var s = new e(l);
                o.exports = s;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("signalsFBEventsGetIsChrome", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              function t() {
                var t = e.chrome,
                  n = e.navigator,
                  r = n.vendor,
                  o = e.opr !== void 0,
                  a = n.userAgent.indexOf("Edg") > -1,
                  i = n.userAgent.match("CriOS");
                return (
                  !i &&
                  t !== null &&
                  t !== void 0 &&
                  r === "Google Inc." &&
                  o === !1 &&
                  a === !1
                );
              }
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsGetIWLParametersEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsConvertNodeToHTMLElement"),
                  n = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  r = a.getFbeventsModules("SignalsFBEventsTyped"),
                  i = r.coerce;
                function l() {
                  for (
                    var e = arguments.length, r = new Array(e), o = 0;
                    o < e;
                    o++
                  )
                    r[o] = arguments[o];
                  var a = r[0];
                  if (a == null || G(a) !== "object") return null;
                  var l = a.unsafePixel,
                    s = a.unsafeTarget,
                    u = i(l, n),
                    c = s instanceof Node ? t(s) : null;
                  return u != null && c != null
                    ? [{ pixel: u, target: c }]
                    : null;
                }
                o.exports = new e(l);
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsGetTimingsEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsParamList");
              function n(e) {
                var n = e instanceof t ? e : null;
                return n != null ? [n] : null;
              }
              var r = new e(n);
              o.exports = r;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsGetValidUrl", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              o.exports = function (t) {
                if (t == null) return null;
                try {
                  var e = new URL(t);
                  return e;
                } catch (e) {
                  return null;
                }
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsGoogleAnalyticsBridgeConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({ measurementId: t.string() });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsGuardrail", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsGuardrailTypedef"),
                t = a.getFbeventsModules("SignalsFBEventsTyped"),
                n = t.coerce,
                r = function () {
                  return Math.random();
                },
                i = {};
              function l(e) {
                var t = e.passRate;
                t != null && (e.passed = r() < t);
              }
              var s = (function () {
                function t() {
                  $(this, t);
                }
                return N(t, [
                  {
                    key: "setGuardrails",
                    value: function (r) {
                      var t = n(r, e);
                      if (t != null) {
                        this._guardrails = t;
                        var o = U(this._guardrails),
                          a;
                        try {
                          for (o.s(); !(a = o.n()).done; ) {
                            var l = a.value;
                            if (l.name != null) {
                              var s = l.name,
                                u = { passed: null },
                                c = v(v({}, u), l);
                              i[s] = c;
                            }
                          }
                        } catch (e) {
                          o.e(e);
                        } finally {
                          o.f();
                        }
                      }
                    },
                  },
                  {
                    key: "eval",
                    value: function (t, n) {
                      var e = i[t];
                      return e
                        ? e.enableForPixels && e.enableForPixels.includes(n)
                          ? !0
                          : e.passed != null
                          ? e.passed
                          : (l(e), e.passed != null ? e.passed : !1)
                        : !1;
                    },
                  },
                  {
                    key: "enable",
                    value: function (t) {
                      var e = i[t];
                      if (e != null) e.passed = !0;
                      else {
                        var n = { passed: !0 };
                        i[t] = n;
                      }
                    },
                  },
                  {
                    key: "disable",
                    value: function (t) {
                      var e = i[t];
                      if (e != null) e.passed = !1;
                      else {
                        var n = { passed: !1 };
                        i[t] = n;
                      }
                    },
                  },
                ]);
              })();
              o.exports = new s();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsGuardrailTypedef", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                t = e.Typed,
                n = t.arrayOf(
                  t.objectWithFields({
                    name: t.allowNull(t.string()),
                    passRate: t.allowNull(t.number()),
                    enableForPixels: t.allowNull(t.arrayOf(t.string())),
                    code: t.allowNull(t.string()),
                    passed: t.allowNull(t.boolean()),
                  })
                );
              o.exports = n;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsIABPCMAEBridgeConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    enableAutoEventId: t.allowNull(t.boolean()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsImagePixelOpenBridgeConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({ enabled: t.boolean() });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("signalsFBEventsInjectMethod", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("signalsFBEventsMakeSafe");
              function t(t, n, r) {
                var o = t[n],
                  a = e(r);
                t[n] = function () {
                  for (
                    var e = arguments.length, t = new Array(e), n = 0;
                    n < e;
                    n++
                  )
                    t[n] = arguments[n];
                  var r = o.apply(this, t);
                  return a.apply(this, t), r;
                };
              }
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsIsHostMeta", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              o.exports = function (t) {
                if (typeof t != "string") return !1;
                var e = t.match(/^(.*\.)*(meta\.com)\.?$/i);
                return e !== null;
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsIsURLFromMeta", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("signalsFBEventsIsHostMeta");
              function t(e) {
                if (typeof e != "string" || e === "") return null;
                try {
                  var t = new URL(e);
                  return t.hostname;
                } catch (e) {
                  return null;
                }
              }
              function n(n, r) {
                var o = t(n),
                  a = t(r),
                  i = o != null && e(o),
                  l = a != null && e(a);
                return i || l;
              }
              o.exports = n;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsIWLBootStrapEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("signalsFBEventsCoercePixelID");
              function n() {
                for (
                  var e = arguments.length, n = new Array(e), r = 0;
                  r < e;
                  r++
                )
                  n[r] = arguments[r];
                var o = n[0];
                if (o == null || G(o) !== "object") return null;
                var a = o.graphToken,
                  i = o.pixelID,
                  l = t(i);
                return a != null && typeof a == "string" && l != null
                  ? [{ graphToken: a, pixelID: l }]
                  : null;
              }
              var r = new e(n);
              o.exports = r;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsJSLoader", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules(
                  "signalsFBEventsCreateTrustedTypePolicy"
                ),
                n = a.getFbeventsModules("SignalsFBEventsUtils"),
                r = n.stringStartsWith,
                i = {
                  CDN_BASE_URL: "https://connect.facebook.net/",
                  SGW_INSTANCE_FRL: "https://gw.conversionsapigateway.com",
                };
              function l() {
                for (
                  var e = t.getElementsByTagName("script"), n = 0;
                  n < e.length;
                  n++
                ) {
                  var r = e[n];
                  if (r && r.src && r.src.indexOf(i.CDN_BASE_URL) !== -1)
                    return r;
                }
                return null;
              }
              var s = e("connect.facebook.net/fbevents", function (e) {
                var t = r(e, i.CDN_BASE_URL),
                  n = r(e, i.SGW_INSTANCE_FRL);
                if (!t && !n) throw new Error("Disallowed script URL");
                return e;
              });
              function u(e) {
                var n = t.createElement("script");
                s != null ? (n.src = s.createScriptURL(e)) : (n.src = e),
                  (n.async = !0);
                var r = l();
                r && r.parentNode
                  ? r.parentNode.insertBefore(n, r)
                  : t.head && t.head.firstChild && t.head.appendChild(n);
              }
              o.exports = { CONFIG: i, loadJSFile: u };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsLateValidateCustomParametersEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsTyped"),
                  n = t.coerce,
                  r = t.Typed;
                function i() {
                  for (
                    var e = arguments.length, t = new Array(e), o = 0;
                    o < e;
                    o++
                  )
                    t[o] = arguments[o];
                  return n(
                    t,
                    r.tuple([r.string(), r.object(), r.string(), r.identity()])
                  );
                }
                var l = new e(i);
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsLegacyExperimentGroupsTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.enforce,
                  r = a.getFbeventsModules("SignalsFBEventsTypeVersioning"),
                  i = r.upgrade;
                function l(e) {
                  return e != null && G(e) === "object"
                    ? Object.values(e)
                    : null;
                }
                var s = function (r) {
                  var e = Array.isArray(r) ? r : l(r);
                  return n(
                    e,
                    t.arrayOf(
                      t.objectWithFields({
                        code: t.string(),
                        name: t.string(),
                        passRate: t.number(),
                        range: t.tuple([t.number(), t.number()]),
                      })
                    )
                  );
                };
                function u(e) {
                  var t = e.name,
                    n = e.code,
                    r = e.range,
                    o = e.passRate;
                  return {
                    allocation: r[1] - r[0],
                    code: n,
                    name: t,
                    passRate: o,
                  };
                }
                o.exports = i(s, function (e) {
                  return e.map(u);
                });
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsLogging", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var n = a.getFbeventsModules("signalsFBEventsIsURLFromMeta"),
                r = a.getFbeventsModules("SignalsFBEventsUtils"),
                i = r.hasOwn,
                l = r.isArray,
                s = r.isInstanceOf,
                u = r.map,
                c = a.getFbeventsModules("SignalsParamList"),
                d = a.getFbeventsModules("signalsFBEventsSendGET"),
                m = a.getFbeventsModules("SignalsFBEventsJSLoader"),
                p = !1;
              function _() {
                p = !0;
              }
              var f = !0;
              function g() {
                f = !1;
              }
              var h = !1;
              function y() {
                h = !0;
              }
              var C = "console",
                b = "warn",
                v = [];
              function S(t) {
                e[C] && e[C][b] && (e[C][b](t), h && v.push(t));
              }
              var R = !1;
              function L() {
                R = !0;
              }
              function E(e) {
                R || S("[Meta Pixel] - ".concat(e));
              }
              var k = "Meta Pixel Error",
                I = function () {
                  e.postMessage != null && e.postMessage.apply(e, arguments);
                },
                T = {};
              function D(e) {
                switch (e.type) {
                  case "FBQ_NO_METHOD_NAME":
                    return "You must provide an argument to fbq().";
                  case "INVALID_FBQ_METHOD": {
                    var t = e.method;
                    return "\"fbq('".concat(
                      t,
                      "', ...);\" is not a valid fbq command."
                    );
                  }
                  case "INVALID_FBQ_METHOD_PARAMETER": {
                    var n = e.invalidParamName,
                      r = e.invalidParamValue,
                      o = e.method,
                      a = e.params;
                    return "Call to \"fbq('"
                      .concat(o, "', ")
                      .concat($(a), ');" with parameter "')
                      .concat(n, '" has an invalid value of "')
                      .concat(x(r), '"');
                  }
                  case "INVALID_PIXEL_ID": {
                    var i = e.pixelID;
                    return "Invalid PixelID: ".concat(i, ".");
                  }
                  case "DUPLICATE_PIXEL_ID": {
                    var l = e.pixelID;
                    return "Duplicate Pixel ID: ".concat(l, ".");
                  }
                  case "SET_METADATA_ON_UNINITIALIZED_PIXEL_ID": {
                    var s = e.metadataValue,
                      u = e.pixelID;
                    return "Trying to set argument "
                      .concat(s, " for uninitialized Pixel ID ")
                      .concat(u, ".");
                  }
                  case "CONFLICTING_VERSIONS":
                    return "Multiple pixels with conflicting versions were detected on this page.";
                  case "MULTIPLE_PIXELS":
                    return "Multiple pixels were detected on this page.";
                  case "UNSUPPORTED_METADATA_ARGUMENT": {
                    var c = e.metadata;
                    return "Unsupported metadata argument: ".concat(c, ".");
                  }
                  case "REQUIRED_PARAM_MISSING": {
                    var d = e.param,
                      m = e.eventName;
                    return "Required parameter '"
                      .concat(d, "' is missing for event '")
                      .concat(m, "'.");
                  }
                  case "INVALID_PARAM": {
                    var p = e.param,
                      _ = e.eventName;
                    return "Parameter '"
                      .concat(p, "' is invalid for event '")
                      .concat(_, "'.");
                  }
                  case "NO_EVENT_NAME":
                    return 'Missing event name. Track events must be logged with an event name fbq("track", eventName)';
                  case "NO_EVENT_ID": {
                    var f = e.pixelID;
                    return "got null or empty eventID from 4th parameter for Pixel ID: ".concat(
                      f,
                      "."
                    );
                  }
                  case "INVALID_EVENT_ID_FORMAT": {
                    var g = e.pixelID,
                      h = e.eventName;
                    return "Incorrect eventID type. The eventID parameter needs to be a string for Pixel ID: "
                      .concat(g, " for event '")
                      .concat(h);
                  }
                  case "NONSTANDARD_EVENT": {
                    var y = e.eventName;
                    return (
                      "You are sending a non-standard event '".concat(
                        y,
                        "'. "
                      ) +
                      "The preferred way to send these events is using trackCustom. See 'https://developers.facebook.com/docs/ads-for-websites/pixel-events/#events' for more information."
                    );
                  }
                  case "NEGATIVE_EVENT_PARAM": {
                    var C = e.param,
                      b = e.eventName;
                    return "Parameter '"
                      .concat(C, "' is negative for event '")
                      .concat(b, "'.");
                  }
                  case "PII_INVALID_TYPE": {
                    var v = e.key_type,
                      S = e.key_val;
                    return "An invalid "
                      .concat(v, " was specified for '")
                      .concat(
                        S,
                        "'. This data will not be sent with any events for this Pixel."
                      );
                  }
                  case "PII_UNHASHED_PII": {
                    var R = e.key;
                    return "The value for the '".concat(
                      R,
                      "' key appeared to be PII. This data will not be sent with any events for this Pixel."
                    );
                  }
                  case "INVALID_CONSENT_ACTION": {
                    var L = e.action;
                    return "\"fbq('".concat(
                      L,
                      "', ...);\" is not a valid fbq('consent', ...) action. Valid actions are 'revoke' and 'grant'."
                    );
                  }
                  case "INVALID_JSON_LD": {
                    var E = e.jsonLd;
                    return "Unable to parse JSON-LD tag. Malformed JSON found: '".concat(
                      E,
                      "'."
                    );
                  }
                  case "SITE_CODELESS_OPT_OUT": {
                    var k = e.pixelID;
                    return "Unable to open Codeless events interface for pixel as the site has opted out. Pixel ID: ".concat(
                      k,
                      "."
                    );
                  }
                  case "PIXEL_NOT_INITIALIZED": {
                    var I = e.pixelID;
                    return "Pixel ".concat(I, " not found");
                  }
                  case "UNWANTED_CUSTOM_DATA":
                    return "Removed parameters from custom data due to potential violations. Go to Events Manager to learn more.";
                  case "UNWANTED_URL_DATA":
                    return "Removed URL query parameters due to potential violations.";
                  case "UNWANTED_EVENT_NAME":
                    return "Blocked Event due to potential violations.";
                  case "UNVERIFIED_EVENT":
                    return "You are attempting to send an unverified event. The event was suppressed. Go to Events Manager to learn more.";
                  case "RESTRICTED_EVENT":
                    return "You are attempting to send a restricted event. The event was suppressed. Go to Events Manager to learn more.";
                  case "INVALID_PARAM_FORMAT": {
                    var T = e.invalidParamName;
                    return "Invalid parameter format for ".concat(
                      T,
                      ". Please refer https://developers.facebook.com/docs/meta-pixel/reference/ for valid parameter specifications."
                    );
                  }
                  case "UNABLE_LOAD_FBQ": {
                    var D = e.error;
                    return "Unable to load FBQ: The Facebook Pixel library could not be loaded. ".concat(
                      D
                    );
                  }
                  default:
                    return (
                      O(
                        new Error(
                          "INVALID_USER_ERROR - "
                            .concat(e.type, " - ")
                            .concat(JSON.stringify(e))
                        )
                      ),
                      "Invalid User Error."
                    );
                }
              }
              var x = function (t) {
                  if (typeof t == "string") return "'".concat(t, "'");
                  if (typeof t == "undefined") return "undefined";
                  if (t === null) return "null";
                  if (
                    !l(t) &&
                    t.constructor != null &&
                    t.constructor.name != null
                  )
                    return t.constructor.name;
                  try {
                    return JSON.stringify(t) || "undefined";
                  } catch (e) {
                    return "undefined";
                  }
                },
                $ = function (t) {
                  return u(t, x).join(", ");
                };
              function P(e) {
                var t = e.toString(),
                  n = null,
                  r = null;
                return (
                  s(e, Error) &&
                    ((n = e.fileName), (r = e.stackTrace || e.stack)),
                  { str: t, fileName: n, stack: r }
                );
              }
              function N() {
                var t = e.fbq.instance.pluginConfig.get(
                  null,
                  "dataProcessingOptions"
                );
                return !!(t != null && t.dataPrivacyOptions.includes("LDU"));
              }
              function M() {
                return e.fbq && e.fbq._releaseSegment
                  ? e.fbq._releaseSegment
                  : "unknown";
              }
              function w() {
                var r = Math.random(),
                  o = M();
                return (
                  (f && r < 0.01) ||
                  o === "canary" ||
                  n(e.location.href, t.referrer) ||
                  e.fbq.alwaysLogErrors
                );
              }
              function A(t, n, r, o, a, i) {
                try {
                  if (N() || (e.fbq && e.fbq.disableErrorLogging) || !w())
                    return;
                  var l = new c(null);
                  o != null && o !== ""
                    ? l.append("p", o)
                    : l.append("p", "pixel"),
                    a != null && a !== "" && l.append("pn", a),
                    l.append("sl", r.toString()),
                    l.append(
                      "v",
                      e.fbq && e.fbq.version ? e.fbq.version : "unknown"
                    ),
                    l.append("e", t.str),
                    t.fileName != null &&
                      t.fileName !== "" &&
                      l.append("f", t.fileName),
                    t.stack != null && t.stack !== "" && l.append("s", t.stack),
                    l.append("ue", n ? "1" : "0"),
                    l.append("rs", M()),
                    i != null && i !== "" && l.append("ed", i);
                  var s = l.toPayload();
                  d(s, {
                    url: m.CONFIG.CDN_BASE_URL + "/log/error",
                    ignoreRequestLengthCheck: !0,
                  });
                } catch (e) {}
              }
              function F(t) {
                var n = JSON.stringify(t);
                if (!i(T, n)) T[n] = !0;
                else return;
                var r = D(t);
                E(r);
                var o = "pixelID" in t && t.pixelID != null ? t.pixelID : null;
                I(
                  {
                    action: "FB_LOG",
                    logMessage: r,
                    logType: k,
                    error: t,
                    pixelId: o,
                    url: e.location.href,
                  },
                  "*"
                ),
                  A({ str: r, fileName: null, stack: null }, !0, 0);
              }
              function O(e, t, n) {
                if (e instanceof TypeError) {
                  B(e);
                  return;
                }
                A(P(e), !1, 0, t, n), p && E(e.toString());
              }
              function B(e, t, n, r) {
                A(P(e), !1, 1, t, n, r), p && E(e.toString());
              }
              function W(e, t, n) {
                A(P(e), !1, 2, t, n), p && E(e.toString());
              }
              function q(e, t, n) {
                A({ str: e, fileName: null, stack: null }, !1, 2, t, n),
                  p && E(e);
              }
              var U = "pixel",
                V = {
                  META_PIXEL_PRODUCT_NAME: U,
                  consoleWarn: S,
                  disableAllLogging: L,
                  disableSampling: g,
                  enableVerboseDebugLogging: _,
                  logError: O,
                  logUserError: F,
                  logWarning: B,
                  logInfoString: q,
                  logInfo: W,
                  enableBufferedLoggedWarnings: y,
                  bufferedLoggedWarnings: v,
                };
              o.exports = V;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsMakeSafe", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                t = e.logError;
              function n(e) {
                return function () {
                  try {
                    for (
                      var n = arguments.length, r = new Array(n), o = 0;
                      o < n;
                      o++
                    )
                      r[o] = arguments[o];
                    e.apply(this, r);
                  } catch (e) {
                    t(e);
                  }
                };
              }
              o.exports = n;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsMessageParamsTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = a.getFbeventsModules("SignalsParamList"),
                  r = t.objectWithFields({
                    customData: t.allowNull(t.object()),
                    customParams: function (t) {
                      return t instanceof n ? t : void 0;
                    },
                    eventName: t.string(),
                    id: t.string(),
                    piiTranslator: function (t) {
                      return typeof t == "function" ? t : void 0;
                    },
                    documentLink: t.allowNull(t.string()),
                    referrerLink: t.allowNull(t.string()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsMetaQEConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    meta_qe: t.objectWithFields({
                      in_treatment: t.boolean(),
                      in_control: t.boolean(),
                    }),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsMethods", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("gateCheck"),
                t = { gateCheck: e };
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsMicrodataConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    waitTimeMs: t.allowNull(
                      t.withValidation({
                        def: t.number(),
                        validators: [
                          function (e) {
                            return e > 0 && e < 1e4;
                          },
                        ],
                      })
                    ),
                    enablePageHash: t.allowNull(t.boolean()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsMicrodataCoverageConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    knownFields: t.arrayOf(t.lowercaseString()),
                    ignorePatterns: t.arrayOf(t.string()),
                    maxUnknownFields: t.number(),
                  }),
                  r = t.objectWithFields({
                    version: t.string(),
                    jsonLd: t.allowNull(n),
                    openGraph: t.allowNull(n),
                    schemaOrg: t.allowNull(n),
                    unknownFieldSamplingRate: t.allowNull(t.number()),
                    samplingRate: t.allowNull(t.number()),
                  });
                o.exports = {
                  SignalsFBEventsMicrodataCoverageSourceConfigTypedef: n,
                  SignalsFBEventsMicrodataCoverageConfigTypedef: r,
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsMicrodataExtractionConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.enforce,
                  r = t.objectWithFields({
                    schemaOrgPropertyNames: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                    jsonLdPropertyNames: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                    openGraphPropertyNames: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                    dublinCorePropertyNames: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                    twitterCardPropertyNames: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                    rdfaPropertyNames: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                  }),
                  i = t.objectWithFields({
                    schemaOrgPropertyNames: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                    jsonLdTypeNames: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                    openGraphTypeNames: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                    openGraphTypeHints: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                    dublinCoreTypeHints: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                    twitterCardTypeNames: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                    twitterCardTypeHints: t.allowNull(
                      t.arrayOf(t.lowercaseString())
                    ),
                    rdfaTypeNames: t.allowNull(t.arrayOf(t.lowercaseString())),
                    fields: t.allowNull(
                      t.mapOf(function (e) {
                        return n(e, r);
                      })
                    ),
                    objects: t.allowNull(
                      t.mapOf(function (e) {
                        return n(e, i);
                      })
                    ),
                  }),
                  l = t.objectWithFields({
                    objects: t.allowNull(
                      t.mapOf(function (e) {
                        return n(e, i);
                      })
                    ),
                    version: t.string(),
                  });
                o.exports = {
                  SignalsFBEventsMicrodataFieldConfigTypedef: r,
                  SignalsFBEventsMicrodataObjectConfigTypedef: i,
                  SignalsFBEventsMicrodataGlobalConfigTypedef: l,
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsMicrodataFieldTransmissionConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules(
                    "SignalsFBEventsMicrodataExtractionConfigTypedef"
                  ),
                  t = e.SignalsFBEventsMicrodataGlobalConfigTypedef,
                  n = a.getFbeventsModules("SignalsFBEventsTyped"),
                  r = n.Typed,
                  i = n.enforce,
                  l = r.objectWithFields({
                    schema: r.allowNull(function (e) {
                      return i(e, t);
                    }),
                  });
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsMobileAppBridge", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsTelemetry"),
                n = a.getFbeventsModules("SignalsFBEventsUtils"),
                r = n.each,
                i = n.hasOwn,
                l = "fbmq-0.1",
                s = {
                  AddPaymentInfo: "fb_mobile_add_payment_info",
                  AddToCart: "fb_mobile_add_to_cart",
                  AddToWishlist: "fb_mobile_add_to_wishlist",
                  CompleteRegistration: "fb_mobile_complete_registration",
                  InitiateCheckout: "fb_mobile_initiated_checkout",
                  Other: "other",
                  Purchase: "fb_mobile_purchase",
                  Search: "fb_mobile_search",
                  ViewContent: "fb_mobile_content_view",
                },
                u = {
                  content_ids: "fb_content_id",
                  content_type: "fb_content_type",
                  currency: "fb_currency",
                  num_items: "fb_num_items",
                  search_string: "fb_search_string",
                  value: "_valueToSum",
                  contents: "fb_content",
                },
                c = {};
              function d(e) {
                return "fbmq_" + e[1];
              }
              function m(t) {
                if (i(c, t[0]) && i(c[t[0]], t[1])) return !0;
                var n = e[d(t)],
                  r =
                    n && n.getProtocol.call && n.getProtocol() === l ? n : null;
                return (
                  r !== null &&
                    ((c[t[0]] = c[t[0]] || {}), (c[t[0]][t[1]] = r)),
                  r !== null
                );
              }
              function p(e) {
                var t = [],
                  n = c[e.id] || {};
                for (var r in n) i(n, r) && t.push(n[r]);
                return t;
              }
              function _(e) {
                return p(e).length > 0;
              }
              function f(e) {
                return i(s, e) ? s[e] : e;
              }
              function g(e) {
                return i(u, e) ? u[e] : e;
              }
              function h(e) {
                if (typeof e == "string") return e;
                if (typeof e == "number") return isNaN(e) ? void 0 : e;
                try {
                  return JSON.stringify(e);
                } catch (e) {}
                if (e.toString && e.toString.call) return e.toString();
              }
              function y(e) {
                var t = {};
                if (e != null && G(e) === "object") {
                  for (var n in e)
                    if (i(e, n)) {
                      var r = h(e[n]);
                      r != null && (t[g(n)] = r);
                    }
                }
                return t;
              }
              var C = 0;
              function b() {
                var e = C;
                (C = 0), t.logMobileNativeForwarding(e);
              }
              function v(e, t, n) {
                r(p(e), function (r) {
                  return r.sendEvent(e.id, f(t), JSON.stringify(y(n)));
                }),
                  C++,
                  setTimeout(b, 0);
              }
              o.exports = {
                pixelHasActiveBridge: _,
                registerBridge: m,
                sendEvent: v,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsModuleEncodings", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsTyped"),
                n = t.coerce,
                r = a.getFbeventsModules(
                  "SignalsFBEventsModuleEncodingsTypedef"
                ),
                i = a.getFbeventsModules("SignalsFBEventsTyped"),
                l = i.Typed,
                s = a.getFbeventsModules("SignalsFBEventsUtils"),
                u = s.keys,
                c = (function () {
                  function t() {
                    $(this, t);
                  }
                  return N(t, [
                    {
                      key: "setModuleEncodings",
                      value: function (t) {
                        var e = n(t, r);
                        e != null && (this.moduleEncodings = e);
                      },
                    },
                    {
                      key: "addEncodings",
                      value: function (r) {
                        if (
                          !(
                            e.fbq == null ||
                            e.fbq.__fbeventsResolvedModules == null
                          ) &&
                          this.moduleEncodings != null
                        ) {
                          var t = n(
                            e.fbq.__fbeventsResolvedModules,
                            l.object()
                          );
                          if (t != null) {
                            var o = [],
                              a = this.moduleEncodings.map;
                            if (a != null) {
                              var i = U(u(t)),
                                s;
                              try {
                                for (i.s(); !(s = i.n()).done; ) {
                                  var c = s.value;
                                  c in a && o.push(a[c]);
                                }
                              } catch (e) {
                                i.e(e);
                              } finally {
                                i.f();
                              }
                            }
                            o.length > 0 &&
                              (this.moduleEncodings.hash != null &&
                                r.append("hme", this.moduleEncodings.hash),
                              r.append("ex_m", o.join(",")));
                          }
                        }
                      },
                    },
                  ]);
                })();
              o.exports = new c();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsModuleEncodingsTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    map: t.allowNull(t.object()),
                    hash: t.allowNull(t.string()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsNetworkConfig", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              var e = {
                ENDPOINT: "https://www.facebook.com/tr/",
                INSTAGRAM_TRIGGER_ATTRIBUTION: "https://www.instagram.com/tr/",
                GPS_ENDPOINT:
                  "https://www.facebook.com/privacy_sandbox/pixel/register/trigger/",
                TOPICS_API_ENDPOINT:
                  "https://www.facebook.com/privacy_sandbox/topics/registration/",
              };
              o.exports = e;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsNormalizers", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules(
                  "normalizeSignalsFBEventsStringType"
                ),
                t = e.normalize,
                n = e.normalizeState,
                r = e.normalizeCountry;
              o.exports = {
                email: a.getFbeventsModules(
                  "normalizeSignalsFBEventsEmailType"
                ),
                enum: a.getFbeventsModules("normalizeSignalsFBEventsEnumType"),
                postal_code: a.getFbeventsModules(
                  "normalizeSignalsFBEventsPostalCodeType"
                ),
                phone_number: a.getFbeventsModules(
                  "normalizeSignalsFBEventsPhoneNumberType"
                ),
                dob: a.getFbeventsModules("normalizeSignalsFBEventsDOBType"),
                normalize_state: n,
                normalize_country: r,
                string: t,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsOpenBridgeConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    endpoints: t.arrayOf(
                      t.objectWithFields({
                        targetDomain: t.allowNull(t.string()),
                        endpoint: t.allowNull(t.string()),
                        usePathCookie: t.allowNull(t.boolean()),
                        fallbackDomain: t.allowNull(t.string()),
                        enrichmentDisabled: t.allowNull(t.boolean()),
                        alwaysRetry: t.allowNull(t.boolean()),
                      })
                    ),
                    eventsFilter: t.allowNull(
                      t.objectWithFields({
                        filteringMode: t.allowNull(t.string()),
                        eventNames: t.allowNull(t.arrayOf(t.string())),
                      })
                    ),
                    additionalUserData: t.allowNull(
                      t.objectWithFields({
                        sendFBLoginID: t.allowNull(t.boolean()),
                        useSGWUserData: t.allowNull(t.boolean()),
                      })
                    ),
                    blockedWebsites: t.allowNull(t.arrayOf(t.string())),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsOptIn", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                t = e.each,
                n = e.filter,
                r = e.hasOwn,
                i = e.keys,
                l = e.some;
              function s(e) {
                t(i(e), function (t) {
                  if (
                    l(e[t], function (t) {
                      return r(e, t);
                    })
                  )
                    throw new Error(
                      "Circular subOpts are not allowed. " +
                        t +
                        " depends on another subOpt"
                    );
                });
              }
              var u = (function () {
                function e() {
                  var t =
                    arguments.length > 0 && arguments[0] !== void 0
                      ? arguments[0]
                      : {};
                  $(this, e),
                    S(this, "_opts", {}),
                    (this._subOpts = t),
                    s(this._subOpts);
                }
                return N(e, [
                  {
                    key: "_getOpts",
                    value: function (t) {
                      return [].concat(
                        I(r(this._subOpts, t) ? this._subOpts[t] : []),
                        [t]
                      );
                    },
                  },
                  {
                    key: "_setOpt",
                    value: function (t, n, r) {
                      var e = this._opts[n] || (this._opts[n] = {});
                      e[t] = r;
                    },
                  },
                  {
                    key: "optIn",
                    value: function (n, r) {
                      var e = this,
                        o =
                          arguments.length > 2 && arguments[2] !== void 0
                            ? arguments[2]
                            : !1;
                      return (
                        t(this._getOpts(r), function (t) {
                          var a = o == !0 && e.isOptedOut(n, r);
                          a || e._setOpt(n, t, !0);
                        }),
                        this
                      );
                    },
                  },
                  {
                    key: "optOut",
                    value: function (n, r) {
                      var e = this;
                      return (
                        t(this._getOpts(r), function (t) {
                          return e._setOpt(n, t, !1);
                        }),
                        this
                      );
                    },
                  },
                  {
                    key: "isOptedIn",
                    value: function (t, n) {
                      return this._opts[n] != null && this._opts[n][t] === !0;
                    },
                  },
                  {
                    key: "isOptedOut",
                    value: function (t, n) {
                      return this._opts[n] != null && this._opts[n][t] === !1;
                    },
                  },
                  {
                    key: "listPixelIds",
                    value: function (t) {
                      var e = this._opts[t];
                      return e != null
                        ? n(i(e), function (t) {
                            return e[t] === !0;
                          })
                        : [];
                    },
                  },
                ]);
              })();
              o.exports = u;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPageStatusEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsTyped"),
                n = t.Typed,
                r = t.coerce;
              function i(e) {
                var t = r(e, n.string());
                return t === "active" || t === "inactive" ? [t] : null;
              }
              var l = new e(i);
              o.exports = l;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPageStatusMonitor", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var n = a.getFbeventsModules("SignalsFBEventsPageStatusEvent"),
                r = !1;
              function i() {
                r ||
                  (typeof e != "undefined" &&
                    ((r = !0),
                    e.addEventListener("pagehide", function () {
                      n.trigger("inactive");
                    }),
                    typeof t != "undefined" &&
                      t.visibilityState &&
                      t.addEventListener("visibilitychange", function () {
                        t.visibilityState === "hidden"
                          ? n.trigger("inactive")
                          : t.visibilityState === "visible" &&
                            n.trigger("active");
                      })));
              }
              function l(e) {
                return n.listen(e);
              }
              function s(e) {
                return n.listenOnce(e);
              }
              o.exports = {
                initPageStatusMonitor: i,
                subscribeToPageStatus: l,
                subscribeToPageStatusOnce: s,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsParallelFireConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({ target: t.string() });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsPIIAutomatchedEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  n = a.getFbeventsModules("SignalsFBEventsTyped"),
                  r = n.coerce;
                function i(e) {
                  var n = r(e, t);
                  return n != null ? [n] : null;
                }
                var l = new e(i);
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsPIIConflictingEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  n = a.getFbeventsModules("SignalsFBEventsTyped"),
                  r = n.coerce;
                function i(e) {
                  var n = r(e, t);
                  return n != null ? [n] : null;
                }
                var l = new e(i);
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsPIIInvalidatedEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  n = a.getFbeventsModules("SignalsFBEventsTyped"),
                  r = n.coerce;
                function i(e) {
                  var n = r(e, t);
                  return n != null ? [n] : null;
                }
                o.exports = new e(i);
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsPixelCookie", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                t = e.logWarning,
                n = e.META_PIXEL_PRODUCT_NAME,
                r = a.getFbeventsModules("SignalsFBEventsUtils"),
                i = r.getCurrentTime,
                l = "fb",
                s = 4,
                u = 5,
                c = ["AQ", "Ag", "Aw", "BA", "BQ", "Bg"],
                d = 2,
                m = 8,
                p = "__DOT__",
                _ = new RegExp(p, "g"),
                f = /\./g,
                g = "cookie",
                h = (function () {
                  function e(t) {
                    $(this, e),
                      typeof t == "string"
                        ? this.maybeUpdatePayload(t)
                        : ((this.subdomainIndex = t.subdomainIndex),
                          (this.creationTime = t.creationTime),
                          (this.payload = t.payload),
                          (this.appendix = t.appendix));
                  }
                  return N(
                    e,
                    [
                      {
                        key: "pack",
                        value: function () {
                          var e =
                              this.payload != null
                                ? this.payload.replace(f, p)
                                : "",
                            t = [
                              l,
                              this.subdomainIndex,
                              this.creationTime,
                              e,
                              this.appendix,
                            ].filter(function (e) {
                              return e != null;
                            });
                          return t.join(".");
                        },
                      },
                      {
                        key: "maybeUpdatePayload",
                        value: function (t) {
                          (this.payload === null || this.payload !== t) &&
                            ((this.payload = t), (this.creationTime = i()));
                        },
                      },
                    ],
                    [
                      {
                        key: "unpack",
                        value: function (o) {
                          try {
                            var r = o.split(".");
                            if (r.length !== s && r.length !== u) return null;
                            var a = R(r, 5),
                              i = a[0],
                              p = a[1],
                              f = a[2],
                              h = a[3],
                              y = a[4];
                            if (y != null) {
                              if (y.length !== d && y.length !== m)
                                throw new Error("Illegal appendix length");
                              if (y.length === d && !c.includes(y))
                                throw new Error("Illegal appendix");
                            }
                            if (i !== l)
                              if (i.includes(l))
                                t(
                                  new Error(
                                    "Unexpected version number '".concat(
                                      r[0],
                                      "'"
                                    )
                                  ),
                                  n,
                                  g
                                );
                              else
                                throw new Error(
                                  "Unexpected version number '".concat(
                                    r[0],
                                    "'"
                                  )
                                );
                            var C = parseInt(p, 10);
                            if (isNaN(C))
                              throw new Error(
                                "Illegal subdomain index '".concat(r[1], "'")
                              );
                            var b = parseInt(f, 10);
                            if (isNaN(b))
                              throw new Error(
                                "Illegal creation time '".concat(r[2], "'")
                              );
                            if (h == null || h === "")
                              throw new Error("Empty cookie payload");
                            var v = h.replace(_, ".");
                            return new e({
                              creationTime: b,
                              payload: v,
                              subdomainIndex: C,
                              appendix: y,
                            });
                          } catch (e) {
                            return t(e, n, g), null;
                          }
                        },
                      },
                    ]
                  );
                })();
              o.exports = h;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPixelPIISchema", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              o.exports = {
                default: {
                  type: "string",
                  typeParams: { lowercase: !0, strip: "whitespace_only" },
                },
                ph: { type: "phone_number" },
                em: { type: "email" },
                fn: {
                  type: "string",
                  typeParams: {
                    lowercase: !0,
                    strip: "whitespace_and_punctuation",
                  },
                },
                ln: {
                  type: "string",
                  typeParams: {
                    lowercase: !0,
                    strip: "whitespace_and_punctuation",
                  },
                },
                zp: { type: "postal_code" },
                ct: {
                  type: "string",
                  typeParams: {
                    lowercase: !0,
                    strip: "all_non_latin_alpha_numeric",
                    test: "^[a-z]+",
                  },
                },
                st: { type: "normalize_state" },
                country: { type: "normalize_country" },
                db: { type: "dob" },
                dob: { type: "date" },
                doby: { type: "string", typeParams: { test: "^[0-9]{4,4}$" } },
                ge: {
                  type: "enum",
                  typeParams: { lowercase: !0, options: ["f", "m"] },
                },
                dobm: {
                  type: "string",
                  typeParams: {
                    test: "^(0?[1-9]|1[012])$|^jan|^feb|^mar|^apr|^may|^jun|^jul|^aug|^sep|^oct|^nov|^dec",
                  },
                },
                dobd: {
                  type: "string",
                  typeParams: { test: "^(([0]?[1-9])|([1-2][0-9])|(3[01]))$" },
                },
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPixelQueueState", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                t = e.logWarning,
                n = a.getFbeventsModules("PixelQueue"),
                r = a.getFbeventsModules("SignalsEventPayload"),
                i = a.getFbeventsModules("signalsFBEventsSendGET"),
                l = a.getFbeventsModules("signalsFBEventsSendFetch"),
                s = a.getFbeventsModules("SignalsFBEventsComparedManagers"),
                u = 0xb3734563ab77,
                c = String(u),
                d = "z0",
                m = "z1",
                p = "z2",
                _ = null,
                f = null,
                g = null;
              function h(e) {
                _ == null && (_ = new n(e));
              }
              function y(e) {
                if (e == null) return null;
                if (Array.isArray(e)) return e;
                if (typeof e.length != "number") return null;
                var n = [];
                try {
                  for (var r = 0; r < e.length; r++) n.push(e[r]);
                } catch (e) {
                  return t(e, "pixel", "qualityChecker"), null;
                }
                return n;
              }
              function C(e) {
                var t = U(e),
                  n;
                try {
                  for (t.s(); !(n = t.n()).done; ) {
                    var r = n.value;
                    b(r);
                  }
                } catch (e) {
                  t.e(e);
                } finally {
                  t.f();
                }
              }
              function b(e) {
                var n = y(e);
                if (n != null) {
                  if (_ == null) {
                    try {
                      if (n.length > 1 && n[0] === "init") {
                        var r = n[1];
                        ((typeof r == "number" && r === u) ||
                          (typeof r == "string" && r === c)) &&
                          h("fbevents");
                      }
                    } catch (e) {
                      t(e, "pixel", "qualityChecker");
                    }
                    return;
                  }
                  try {
                    S(n);
                  } catch (e) {
                    t(e, "pixel", "qualityChecker");
                  }
                }
              }
              function S(e) {
                if (_ != null) {
                  var t = _;
                  if (e[0] === "track" && !(e.length < 3)) {
                    var n = e[1],
                      r = e[2],
                      o = e[3];
                    if (
                      typeof n == "string" &&
                      !(r == null || G(r) !== "object")
                    ) {
                      var a = { eventName: n, params: v({}, r), eventData: o };
                      t.enqueue(a);
                    }
                  }
                }
              }
              function R(e, t, n, r) {
                var o;
                if (e === c) {
                  (f = t), (g = n);
                  var a =
                    (o = r == null ? void 0 : r.enabled) !== null &&
                    o !== void 0
                      ? o
                      : !1;
                  L(a);
                }
              }
              function L(e) {
                if (_ != null) {
                  var n = _;
                  try {
                    e
                      ? n.setHandler(k())
                      : (n.disableStorage(), n.setHandler(E()));
                  } catch (e) {
                    t(e, "pixel", "qualityChecker");
                  }
                }
              }
              function E() {
                return function (e) {
                  for (var t; (t = e.dequeueItem()); )
                    (function (t) {
                      e.markItemAsCompleted(t);
                    })(t);
                };
              }
              function k() {
                var e = s.getComparedURL(),
                  t = s.getComparedReferrer();
                return function (n) {
                  for (var r; (r = n.dequeueItem()); )
                    (function (r) {
                      I(n, r, e, t), T(n, r, e, t), D(n, r, e, t);
                    })(r);
                };
              }
              function I(e, t, n, r) {
                var o,
                  a = t.item,
                  i = a.eventName,
                  s = a.eventData,
                  u = x(
                    i,
                    (o = s == null ? void 0 : s.eventID) !== null &&
                      o !== void 0
                      ? o
                      : "",
                    n,
                    r
                  );
                u.append("qttag", d),
                  l(u)
                    .then(function (n) {
                      e.markItemAsCompleted(t);
                    })
                    .catch(function (n) {
                      e.markItemAsFailed(t);
                    });
              }
              function T(e, t, n, r) {
                var o,
                  a = t.item,
                  l = a.eventName,
                  s = a.eventData,
                  u = x(
                    l,
                    (o = s == null ? void 0 : s.eventID) !== null &&
                      o !== void 0
                      ? o
                      : "",
                    n,
                    r
                  );
                u.append("qttag", m), i(u);
              }
              function D(e, t, n, r) {
                var o,
                  a = t.item,
                  l = a.eventName,
                  s = a.eventData,
                  u = x(
                    l,
                    (o = s == null ? void 0 : s.eventID) !== null &&
                      o !== void 0
                      ? o
                      : "",
                    n,
                    r
                  );
                u.append("qttag", p), i(u, { highFetchPriority: !0 });
              }
              function x(e, t, n, o) {
                var a = new r();
                return (
                  a.append("id", c),
                  a.append("ev", e),
                  a.append("eid", t),
                  a.append("dl", n),
                  a.append("rl", o),
                  a.append("a", "fbq_js"),
                  a.append("ts", String(new Date().valueOf())),
                  a.append("v", f != null ? f : "0.0.404"),
                  g != null && a.append("r", g),
                  a
                );
              }
              o.exports = {
                tryInitQueue: C,
                tryEnqueueCommand: b,
                trySetQueueHandler: R,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPixelTypedef", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                t = e.Typed,
                n = t.objectWithFields({
                  eventCount: t.number(),
                  id: t.fbid(),
                  userData: t.mapOf(t.string()),
                  userDataFormFields: t.mapOf(t.string()),
                });
              o.exports = n;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPlugin", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              var e = N(function e(t) {
                $(this, e),
                  S(this, "__fbEventsPlugin", 1),
                  (this.plugin = t),
                  (this.__fbEventsPlugin = 1);
              });
              o.exports = e;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPluginLoadedEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent");
              function t(e) {
                var t = e != null && typeof e == "string" ? e : null;
                return t != null ? [t] : null;
              }
              o.exports = new e(t);
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPluginManager", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                t = a.getFbeventsModules("SignalsFBEventsEvents"),
                n = t.pluginLoaded,
                r = a.getFbeventsModules("SignalsFBEventsJSLoader"),
                i = a.getFbeventsModules("SignalsFBEventsLogging"),
                l = i.logWarning,
                s = a.getFbeventsModules("SignalsFBEventsUtils"),
                u = s.hasOwn,
                c = a.getFbeventsModules("SignalsFBEventsPlugin");
              function d(e) {
                return "fbevents.plugins.".concat(e);
              }
              function m(e, t) {
                if (e === "fbevents") return new c(function () {});
                if (t instanceof c) return t;
                if (t == null || G(t) !== "object")
                  return (
                    l(new Error("Invalid pluginAPI registered ".concat(e))),
                    new c(function () {})
                  );
                var n = t.__fbEventsPlugin,
                  r = t.plugin;
                return n !== 1 || typeof r != "function"
                  ? (l(new Error("Invalid plugin registered ".concat(e))),
                    new c(function () {}))
                  : new c(r);
              }
              var p = (function () {
                function t(e, n) {
                  $(this, t),
                    S(this, "_loadedPlugins", {}),
                    (this._instance = e),
                    (this._lock = n);
                }
                return N(t, [
                  {
                    key: "registerPlugin",
                    value: function (r, o) {
                      u(this._loadedPlugins, r) ||
                        ((this._loadedPlugins[r] = m(r, o)),
                        this._loadedPlugins[r].plugin(a, this._instance, e),
                        n.trigger(r),
                        this._lock.releasePlugin(r));
                    },
                  },
                  {
                    key: "loadPlugin",
                    value: function (t) {
                      if (/^[a-zA-Z]\w+$/.test(t) === !1)
                        throw new Error("Invalid plugin name: ".concat(t));
                      var e = d(t);
                      if (this._loadedPlugins[e]) return !0;
                      if (a.fbIsModuleLoaded(e))
                        return (
                          this.registerPlugin(e, a.getFbeventsModules(e)), !0
                        );
                      var n = ""
                        .concat(r.CONFIG.CDN_BASE_URL, "signals/plugins/")
                        .concat(t, ".js?v=")
                        .concat(a.version);
                      return this._loadedPlugins[e]
                        ? !1
                        : (this._lock.lockPlugin(e), r.loadJSFile(n), !0);
                    },
                  },
                ]);
              })();
              o.exports = p;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsProcessCCRulesEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsParamList");
                function n(e, n) {
                  var r = e instanceof t ? e : null,
                    o = G(n) === "object" ? v({}, n) : null;
                  return r != null ? [r, o] : null;
                }
                var r = new e(n);
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsProcessEmailAddress",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  t = e.looksLikeHashed,
                  n = a.getFbeventsModules("SignalsFBEventsLogging"),
                  r = n.logError,
                  i = a.getFbeventsModules("SignalsFBEventsUtils"),
                  l = i.each,
                  s = i.keys,
                  u = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  c = u.trim,
                  d = ["em", "email"];
                function m(e) {
                  try {
                    if (e == null || G(e) !== "object") return e;
                    l(s(e), function (n) {
                      var r = e[n];
                      if (
                        !t(r) &&
                        !(
                          (typeof d.includes == "function" && !d.includes(n)) ||
                          r == null ||
                          typeof r != "string"
                        )
                      ) {
                        var o = c(r);
                        o.length !== 0 &&
                          (o[o.length - 1] === "," &&
                            (o = o.slice(0, o.length - 1)),
                          (e[n] = o));
                      }
                    });
                  } catch (e) {
                    (e.message = "[NormalizeEmailAddress]: " + e.message), r(e);
                  }
                  return e;
                }
                o.exports = m;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsProhibitedPixelConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    lockWebpage: t.allowNull(t.boolean()),
                    blockReason: t.allowNull(t.string()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsProhibitedSourcesTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    prohibitedSources: t.arrayOf(
                      t.objectWithFields({ domain: t.allowNull(t.string()) })
                    ),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsProtectedDataModeConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    standardParams: t.mapOf(t.boolean()),
                    disableAM: t.allowNull(t.boolean()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsQE", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                t = a.getFbeventsModules("SignalsFBEventsExperimentsTypedef"),
                n = a.getFbeventsModules(
                  "SignalsFBEventsLegacyExperimentGroupsTypedef"
                ),
                r = a.getFbeventsModules("SignalsFBEventsTypeVersioning"),
                i = a.getFbeventsModules("SignalsFBEventsTyped"),
                l = i.coerce,
                s = a.getFbeventsModules("SignalsFBEventsUtils"),
                u = s.reduce,
                c = function () {
                  return Math.random();
                };
              function d(e) {
                for (
                  var t = u(
                      e,
                      function (e, t, n) {
                        if (n === 0) return e.push([0, t.allocation]), e;
                        var r = R(e[n - 1], 2),
                          o = r[0],
                          a = r[1];
                        return e.push([a, a + t.allocation]), e;
                      },
                      []
                    ),
                    n = c(),
                    r = 0;
                  r < e.length;
                  r++
                ) {
                  var o = e[r],
                    a = o.passRate,
                    i = o.code,
                    l = o.name,
                    s = R(t[r], 2),
                    d = s[0],
                    m = s[1];
                  if (n >= d && n < m) {
                    var p = c() < a;
                    return { code: i, isInExperimentGroup: p, name: l };
                  }
                }
                return null;
              }
              var m = (function () {
                function o() {
                  $(this, o),
                    S(this, "_result", null),
                    S(this, "_hasRolled", !1),
                    S(this, "_isExposed", !1),
                    S(this, "CONTROL", "CONTROL"),
                    S(this, "TEST", "TEST"),
                    S(this, "UNASSIGNED", "UNASSIGNED");
                }
                return N(o, [
                  {
                    key: "setExperiments",
                    value: function (o) {
                      var e = l(o, r.waterfall([n, t]));
                      e != null &&
                        ((this._experiments = e),
                        (this._hasRolled = !1),
                        (this._result = null),
                        (this._isExposed = !1));
                    },
                  },
                  {
                    key: "get",
                    value: function (t) {
                      if (!this._hasRolled) {
                        var e = this._experiments;
                        if (e == null) return null;
                        var n = d(e);
                        n != null && (this._result = n), (this._hasRolled = !0);
                      }
                      return t == null || t === ""
                        ? this._result
                        : this._result != null && this._result.name === t
                        ? this._result
                        : null;
                    },
                  },
                  {
                    key: "getCode",
                    value: function () {
                      var e = this.get();
                      if (e == null) return "";
                      var t = 0;
                      return (
                        e.isInExperimentGroup && (t |= 1),
                        this._isExposed && (t |= 2),
                        e.code + t.toString()
                      );
                    },
                  },
                  {
                    key: "getAssignmentFor",
                    value: function (t) {
                      var e = this.get();
                      return e != null && e.name === t
                        ? ((this._isExposed = !0),
                          e.isInExperimentGroup ? this.TEST : this.CONTROL)
                        : this.UNASSIGNED;
                    },
                  },
                  {
                    key: "isInTest",
                    value: function (n) {
                      if (e.eval("release_" + n)) return !0;
                      var t = this.get();
                      return t != null && t.name === n
                        ? ((this._isExposed = !0), t.isInExperimentGroup)
                        : !1;
                    },
                  },
                  {
                    key: "clearExposure",
                    value: function () {
                      this._isExposed = !1;
                    },
                  },
                ]);
              })();
              o.exports = new m();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsQEV2", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                t = a.getFbeventsModules("SignalsFBEventsExperimentsV2Typedef"),
                n = a.getFbeventsModules("SignalsFBEventsTyped"),
                r = n.coerce,
                i = function () {
                  return Math.random();
                },
                l = "meta_qe";
              function s(e) {
                for (var t = i(), n = 0, r = 0, o = 0; o < e.length; o++) {
                  var a = e[o],
                    l = a.passRate,
                    s = a.code,
                    u = a.name,
                    c = a.allocation;
                  if (((r = n + c), t >= n && t < r)) {
                    var d = i() < l;
                    return { isExposed: !1, isInTest: d, code: s, name: u };
                  }
                  n = r;
                }
                return null;
              }
              var u = (function () {
                function n() {
                  $(this, n),
                    S(this, "_experiments", []),
                    S(
                      this,
                      "_pageLoadLevelEvaluationExperimentResults",
                      new Map()
                    ),
                    S(
                      this,
                      "_eventLevelEvaluationExperimentResults",
                      new Map()
                    ),
                    S(this, "_metaQEExposed", !1),
                    S(this, "PAGE_LOAD_LEVEL", "PAGE_LOAD_LEVEL"),
                    S(this, "EVENT_LEVEL", "EVENT_LEVEL");
                }
                return N(n, [
                  {
                    key: "_getMetaQEConfig",
                    value: function (n) {
                      return e.get(n, "metaQE");
                    },
                  },
                  {
                    key: "isInMetaQETreatment",
                    value: function (t) {
                      var e = this._getMetaQEConfig(t);
                      return e != null
                        ? ((this._metaQEExposed = !0), e.meta_qe.in_treatment)
                        : !1;
                    },
                  },
                  {
                    key: "isInMetaQEControl",
                    value: function (t) {
                      var e = this._getMetaQEConfig(t);
                      return e != null
                        ? ((this._metaQEExposed = !0), e.meta_qe.in_control)
                        : !1;
                    },
                  },
                  {
                    key: "setExperiments",
                    value: function (n) {
                      var e = r(n, t);
                      e != null && (this._experiments = e);
                    },
                  },
                  {
                    key: "_reset",
                    value: function () {
                      this._pageLoadLevelEvaluationExperimentResults.clear(),
                        this._eventLevelEvaluationExperimentResults.clear(),
                        (this._metaQEExposed = !1);
                    },
                  },
                  {
                    key: "clearExposure",
                    value: function (t) {
                      this._eventLevelEvaluationExperimentResults.has(t) &&
                        this._eventLevelEvaluationExperimentResults.delete(t);
                    },
                  },
                  {
                    key: "isInTest",
                    value: function (t, n) {
                      var e = this._getExperimentByName(t);
                      if (e == null) return !1;
                      var r = this._getExperimentResultForUniverse(
                        e.universe,
                        e.evaluationType,
                        n
                      );
                      return r == null || r.name !== t
                        ? !1
                        : ((r.isExposed = !0), r.isInTest);
                    },
                  },
                  {
                    key: "isInTestPageLoadLevelExperiment",
                    value: function (t) {
                      var e = this._getExperimentByName(t);
                      if (e == null || e.evaluationType != this.PAGE_LOAD_LEVEL)
                        return !1;
                      var n = this._getPageLoadLevelExperimentResult(
                        e.universe
                      );
                      return n == null || n.name !== t
                        ? !1
                        : ((n.isExposed = !0), n.isInTest);
                    },
                  },
                  {
                    key: "getExperimentResultParams",
                    value: function (t, n) {
                      for (
                        var e = [], r = 0;
                        r < this._experiments.length;
                        r++
                      ) {
                        var o = this._experiments[r],
                          a = this._getExperimentResultForUniverse(
                            o.universe,
                            o.evaluationType,
                            t
                          );
                        if (a != null) {
                          var i = this._getParamByResult(a);
                          e.includes(i) || e.push(i);
                        }
                      }
                      var l = this.getMetaQEParam(n);
                      return l != null && !e.includes(l) && e.push(l), e;
                    },
                  },
                  {
                    key: "getMetaQEParam",
                    value: function (t) {
                      var e = this._getMetaQEConfig(t);
                      if (
                        e == null ||
                        (!e.meta_qe.in_treatment && !e.meta_qe.in_control)
                      )
                        return null;
                      var n = this._getExperimentByName(l);
                      if (n == null) return null;
                      var r = 0;
                      return (
                        e.meta_qe.in_treatment && (r |= 1),
                        this._metaQEExposed && (r |= 2),
                        n.code + r.toString()
                      );
                    },
                  },
                  {
                    key: "_getParamByResult",
                    value: function (t) {
                      var e = 0;
                      return (
                        t.isInTest && (e |= 1),
                        t.isExposed && (e |= 2),
                        t.code + e.toString()
                      );
                    },
                  },
                  {
                    key: "_getExperimentResultForUniverse",
                    value: function (t, n, r) {
                      return n === this.PAGE_LOAD_LEVEL
                        ? this._getPageLoadLevelExperimentResult(t)
                        : this._getEventLevelExperimentResult(t, r);
                    },
                  },
                  {
                    key: "_getPageLoadLevelExperimentResult",
                    value: function (t) {
                      if (this._pageLoadLevelEvaluationExperimentResults.has(t))
                        return this._pageLoadLevelEvaluationExperimentResults.get(
                          t
                        );
                      var e = this._getExperimentsByUniverse(t),
                        n = s(e);
                      return (
                        this._pageLoadLevelEvaluationExperimentResults.set(
                          t,
                          n
                        ),
                        n
                      );
                    },
                  },
                  {
                    key: "_getEventLevelExperimentResult",
                    value: function (t, n) {
                      if (this._eventLevelEvaluationExperimentResults.has(n)) {
                        var e =
                          this._eventLevelEvaluationExperimentResults.get(n);
                        if (e && e.has(t)) return e.get(t);
                      }
                      var r = this._getExperimentsByUniverse(t),
                        o = s(r);
                      this._eventLevelEvaluationExperimentResults.has(n) ||
                        this._eventLevelEvaluationExperimentResults.set(
                          n,
                          new Map()
                        );
                      var a =
                        this._eventLevelEvaluationExperimentResults.get(n);
                      return a && a.set(t, o), o;
                    },
                  },
                  {
                    key: "_getExperimentByName",
                    value: function (t) {
                      for (var e = 0; e < this._experiments.length; e++) {
                        var n = this._experiments[e];
                        if (n.name === t) return n;
                      }
                      return null;
                    },
                  },
                  {
                    key: "_getExperimentsByUniverse",
                    value: function (t) {
                      for (
                        var e = [], n = 0;
                        n < this._experiments.length;
                        n++
                      ) {
                        var r = this._experiments[n];
                        r.universe === t && e.push(r);
                      }
                      return e;
                    },
                  },
                ]);
              })();
              o.exports = new u();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsQualityCheckerConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({ enabled: t.boolean() });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsRawCookieOps", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                n = e.logWarning;
              function r(e) {
                var r = [];
                try {
                  for (
                    var o = t.cookie.split(";"),
                      a = "^\\s*".concat(e, "=\\s*(.*?)\\s*$"),
                      i = new RegExp(a),
                      l = 0;
                    l < o.length;
                    l++
                  ) {
                    var s = o[l].match(i);
                    s && r.push(s[1]);
                  }
                  return r &&
                    Object.prototype.hasOwnProperty.call(r, 0) &&
                    typeof r[0] == "string"
                    ? r[0]
                    : "";
                } catch (e) {
                  return n("Fail to read from cookie: " + e.message), "";
                }
              }
              function i(e) {
                t.cookie = e;
              }
              function l(e) {
                var t = e.indexOf("=");
                if (t < 0) return null;
                var n = e.substring(0, t),
                  r = e.indexOf(";", t),
                  o = r >= 0 ? e.substring(t + 1, r) : e.substring(t + 1);
                return { name: n, value: o };
              }
              o.exports = {
                parseCookieString: l,
                readCookieRaw: r,
                doRawCookieWrite: i,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsRegexParamFilterConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    require_exact_match: t.boolean(),
                    potential_matches: t.allowNull(t.arrayOf(t.string())),
                  }),
                  r = t.objectWithFields({
                    regexParamFilter: t.allowNull(
                      t.mapOf(t.allowNull(t.arrayOf(t.allowNull(n))))
                    ),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsResolveLegacyArguments",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              a = o.exports;
            return (
              (function () {
                "use strict";
                var e = "report";
                function t(e) {
                  var t = R(e, 1),
                    n = t[0];
                  return e.length === 1 && Array.isArray(n)
                    ? { args: n, isLegacySyntax: !0 }
                    : { args: e, isLegacySyntax: !1 };
                }
                function n(t) {
                  var n = R(t, 2),
                    r = n[0],
                    o = n[1];
                  if (typeof r == "string" && r.slice(0, e.length) === e) {
                    var a = r.slice(e.length);
                    return a === "CustomEvent"
                      ? (o != null &&
                          G(o) === "object" &&
                          typeof o.event == "string" &&
                          (a = o.event),
                        ["trackCustom", a].concat(t.slice(1)))
                      : ["track", a].concat(t.slice(1));
                  }
                  return t;
                }
                function r(e) {
                  var r = t(e),
                    o = r.args,
                    a = r.isLegacySyntax,
                    i = n(o);
                  return { args: i, isLegacySyntax: a };
                }
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsResolveLink", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsGetValidUrl"),
                n = a.getFbeventsModules("SignalsFBEventsUtils"),
                r = n.keys;
              function i(n, o, a) {
                var i = e.top !== e;
                if (!i) {
                  var l;
                  return ((l = n == null ? void 0 : n.length) !== null &&
                  l !== void 0
                    ? l
                    : 0) > 0
                    ? n
                    : o;
                }
                if (!o || o.length === 0) return n;
                if (a != null) {
                  var s = t(o);
                  if (!s) return n;
                  var u = s.origin,
                    c = r(a).some(function (e) {
                      return e != null && u.includes(e);
                    });
                  if (c) return n;
                }
                return o;
              }
              o.exports = i;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsRestrictedDomainsConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    restrictedDomains: t.allowNull(
                      t.arrayOf(t.allowNull(t.string()))
                    ),
                    blacklistedIframeReferrers: t.allowNull(
                      t.mapOf(t.boolean())
                    ),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("signalsFBEventsSendBeacon", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                n = a.getFbeventsModules("SignalsFBEventsLogging"),
                r = n.logWarning;
              function i(n, o) {
                try {
                  if (!e.navigator || !e.navigator.sendBeacon) return !1;
                  var a = o || {},
                    i = a.url,
                    l = i === void 0 ? t.ENDPOINT : i;
                  return (
                    n.set("rqm", "SB"),
                    e.navigator.sendBeacon(l, n.toFormData())
                  );
                } catch (e) {
                  return (
                    e instanceof Error &&
                      r(new Error("[SendBeacon]:" + e.message)),
                    !1
                  );
                }
              }
              o.exports = i;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsSendCloudbridgeEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsTyped"),
                  n = t.Typed,
                  r = a.getFbeventsModules(
                    "SignalsFBEventsMessageParamsTypedef"
                  ),
                  i = new e(n.tuple([r]));
                o.exports = i;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("signalsFBEventsSendEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsEvents"),
                t = e.setEventId,
                n = a.getFbeventsModules("SignalsParamList"),
                r = a.getFbeventsModules("SignalsFBEventsProcessCCRulesEvent"),
                i = a.getFbeventsModules(
                  "SignalsFBEventsLateValidateCustomParametersEvent"
                ),
                l = a.getFbeventsModules("SignalsFBEventsUtils"),
                s = l.each,
                u = l.keys,
                c = a.getFbeventsModules("SignalsFBEventsSetFilteredEventName"),
                d = a.getFbeventsModules("SignalsFBEventsAsyncParamUtils"),
                m = d.appendAsyncParamsAndSendEvent,
                p = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                _ = a.getFbeventsModules("signalsFBEventsFillParamList");
              function f(e, o) {
                (e.customData = v({}, e.customData)),
                  (e.timestamp = new Date().valueOf());
                var a = null;
                if (
                  (e.customParams != null &&
                    (a = p.eval("multi_eid_fix")
                      ? e.customParams.getEventId()
                      : e.customParams.get("eid")),
                  a == null || a === "")
                ) {
                  e.customParams = e.customParams || new n();
                  var l = e.customParams;
                  e.id != null && t.trigger(String(e.id), l, e.eventName);
                }
                var d = r.trigger(_(e), e.customData);
                d != null &&
                  s(d, function (t) {
                    t != null &&
                      s(u(t), function (r) {
                        (e.customParams = e.customParams || new n()),
                          e.customParams.append(r, t[r]);
                      });
                  });
                var f = i.trigger(
                  String(e.id),
                  e.customData || {},
                  e.eventName,
                  e.customParams || new n()
                );
                f &&
                  s(f, function (t) {
                    t &&
                      s(u(t), function (r) {
                        (e.customParams = e.customParams || new n()),
                          e.customParams.append(r, t[r]);
                      });
                  });
                var g = c.trigger(_(e));
                g != null &&
                  s(g, function (t) {
                    t != null &&
                      s(u(t), function (r) {
                        (e.customParams = e.customParams || new n()),
                          e.customParams.append(r, t[r]);
                      });
                  }),
                  o.asyncParamPromisesAllSettled
                    ? m(o, e)
                    : o.eventQueue.push(e);
              }
              o.exports = { sendEvent: f };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsSendEventEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsParamList"),
                n = a.getFbeventsModules("SignalsFBEventsTyped"),
                r = n.Typed,
                i = r.objectWithFields({
                  customData: r.allowNull(r.object()),
                  customParams: function (n) {
                    return n instanceof t ? n : void 0;
                  },
                  eventName: r.string(),
                  id: r.string(),
                  piiTranslator: function (t) {
                    return typeof t == "function" ? t : void 0;
                  },
                  documentLink: r.allowNull(r.string()),
                  referrerLink: r.allowNull(r.string()),
                }),
                l = new e(r.tuple([i]));
              o.exports = l;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsSendEventImpl", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsSendEventEvent"),
                t = a.getFbeventsModules("SignalsFBEventsSendCloudbridgeEvent"),
                n = a.getFbeventsModules(
                  "SignalsFBEventsFilterProtectedModeEvent"
                ),
                r = a.getFbeventsModules(
                  "SignalsFBEventsGetAutomaticParametersEvent"
                ),
                i = a.getFbeventsModules("SignalsFBEventsUtils"),
                l = i.some,
                s = a.getFbeventsModules("signalsFBEventsFireEvent"),
                u = a.getFbeventsModules("SignalsFBEventsUtils"),
                c = u.each,
                d = u.hasOwn,
                m = u.keys,
                p = a.getFbeventsModules("SignalsParamList"),
                _ = a.getFbeventsModules("signalsFBEventsFeatureGate"),
                f = a.getFbeventsModules("SignalsPixelCookieUtils"),
                g = f.writeNewCookie,
                h = f.CLICKTHROUGH_COOKIE_PARAM,
                y = a.getFbeventsModules("SignalsFBEventsComparedManagers"),
                C = "_fbleid",
                b = 10080 * 60 * 1e3,
                v = a.getFbeventsModules("generateEventId");
              function S(e, t) {
                if (
                  e.id != null &&
                  _("offsite_clo_beta_event_id_coverage", e.id) &&
                  e.eventName === "Lead" &&
                  e.customParams != null
                ) {
                  var n = e.customParams.get(h),
                    r =
                      e.customParams != null ? e.customParams.get("eid") : null;
                  if (n != null && n.trim() != "") {
                    var o =
                      r != null ? r : v((t && t.VERSION) || "undefined", "LCP");
                    r == null &&
                      e.customParams != null &&
                      e.customParams.append("eid", o),
                      g(C, o, b);
                  }
                }
              }
              function R(e) {
                var t = r.trigger(String(e.id), e.eventName);
                t != null &&
                  c(t, function (t) {
                    t != null &&
                      c(m(t), function (n) {
                        (e.customParams = e.customParams || new p()),
                          e.customParams.append(n, t[n]);
                      });
                  });
              }
              function L(e) {
                var t = e.customParams;
                if (t != null) {
                  var n = e.documentLink;
                  n !== y.getComparedURL() && t.append("dlc", "1");
                  var r = e.referrerLink;
                  r !== y.getComparedReferrer() && t.append("rlc", "1");
                }
              }
              function E(r, o) {
                var a = e.trigger(r);
                if (
                  !l(a, function (e) {
                    return e;
                  })
                ) {
                  S(r, o), R(r), n.trigger(r), L(r);
                  var i = t.trigger(r);
                  if (
                    !l(i, function (e) {
                      return e;
                    })
                  ) {
                    var u =
                      d(r, "customData") &&
                      typeof r.customData != "undefined" &&
                      r.customData !== null;
                    u || (r.customData = {}), s(r);
                  }
                }
              }
              o.exports = E;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsSendFetch", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                n = 2048,
                r = 8e3;
              function i(t) {
                var n =
                  typeof e != "undefined" &&
                  typeof e.DOMException != "undefined";
                if (n && t instanceof e.DOMException) {
                  var r = t.name;
                  return r === "AbortError"
                    ? "abort"
                    : r === "SecurityError"
                    ? "security"
                    : "unknown";
                }
                if (t instanceof TypeError) return "network";
                if (t instanceof Error) {
                  var o = t.name;
                  if (o === "AbortError") return "abort";
                  if (o === "SecurityError") return "security";
                  if (o === "TypeError") return "network";
                }
                return "unknown";
              }
              function l() {
                return typeof e != "undefined" && "AbortController" in e
                  ? new e.AbortController()
                  : { signal: void 0, abort: function () {} };
              }
              function s(e, t) {
                return u.apply(this, arguments);
              }
              function u() {
                return (
                  (u = C(
                    g().m(function o(a, s) {
                      var u, c, d, m, p, _, f, h, y, C, b, S, R, L;
                      return g().w(
                        function (o) {
                          for (;;)
                            switch ((o.p = o.n)) {
                              case 0:
                                return (
                                  (u = s != null ? s : {}),
                                  (c = u.url),
                                  (d = c === void 0 ? t.ENDPOINT : c),
                                  a.set("rqm", "fetch"),
                                  (m = a.toQueryString()),
                                  (p = d + "?" + m),
                                  (_ = p.length > n),
                                  (f = l()),
                                  (h = setTimeout(function () {
                                    return f.abort();
                                  }, r)),
                                  (y = "no-cors"),
                                  (C = "include"),
                                  (b = v(
                                    {
                                      method: _ ? "POST" : "GET",
                                      mode: y,
                                      credentials: C,
                                      cache: "no-store",
                                      keepalive: !0,
                                      signal: f.signal,
                                      fetchPriority: "high",
                                    },
                                    _
                                      ? {
                                          headers: {
                                            "Content-Type":
                                              "application/x-www-form-urlencoded",
                                          },
                                          body: a.toQueryString(),
                                        }
                                      : {}
                                  )),
                                  (o.p = 1),
                                  (S = _ ? d : p),
                                  (o.n = 2),
                                  e.fetch(S, b)
                                );
                              case 2:
                                return o.a(2, { ok: !0, reason: "delivered" });
                              case 3:
                                return (
                                  (o.p = 3),
                                  (L = o.v),
                                  (R = i(L)),
                                  o.a(2, { ok: !1, reason: R, error: L })
                                );
                              case 4:
                                return (o.p = 4), clearTimeout(h), o.f(4);
                              case 5:
                                return o.a(2);
                            }
                        },
                        o,
                        null,
                        [[1, 3, 4, 5]]
                      );
                    })
                  )),
                  u.apply(this, arguments)
                );
              }
              o.exports = s;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsSendFormPOST", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var n = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                r = a.getFbeventsModules("SignalsFBEventsUtils"),
                i = r.listenOnce,
                l = a.getFbeventsModules("SignalsFBEventsLogging"),
                s = l.logError,
                u = l.logWarning,
                c = a.getFbeventsModules("SignalsFBEventsGuardrail");
              function d(r, o) {
                try {
                  var a = "fb" + Math.random().toString().replace(".", ""),
                    l = t.createElement("form");
                  (l.method = "post"),
                    (l.action = o != null ? o : n.ENDPOINT),
                    (l.target = a),
                    (l.acceptCharset = "utf-8"),
                    (l.style.display = "none");
                  var d = !!(e.attachEvent && !e.addEventListener),
                    m = t.createElement("iframe");
                  d && (m.name = a),
                    (m.src = "about:blank"),
                    (m.id = a),
                    (m.name = a),
                    l.appendChild(m);
                  var p = c.eval("fix_fbevent_uri_error");
                  return (
                    i(m, "load", function () {
                      r.set("rqm", "formPOST"),
                        r.forEach(function (e, n) {
                          var r = t.createElement("input");
                          if (p)
                            try {
                              r.name = decodeURIComponent(e);
                            } catch (t) {
                              (r.name = e), u(t, "pixel", "SendFormPOST");
                            }
                          else r.name = decodeURIComponent(e);
                          (r.value = n), l.appendChild(r);
                        }),
                        i(m, "load", function () {
                          l.parentNode && l.parentNode.removeChild(l);
                        }),
                        l.submit();
                    }),
                    t.body != null && t.body.appendChild(l),
                    !0
                  );
                } catch (e) {
                  return (
                    e instanceof Error && s(new Error("[POST]:" + e.message)),
                    !0
                  );
                }
              }
              o.exports = d;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsSendGET", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                n = a.getFbeventsModules(
                  "SignalsFBEventsShouldRestrictReferrerEvent"
                ),
                r = a.getFbeventsModules("SignalsFBEventsQE"),
                i = a.getFbeventsModules("SignalsFBEventsExperimentNames"),
                l = i.ANDROID_IAB_MAX_GET_LENGTH_32K,
                s = a.getFbeventsModules("SignalsFBEventsUtils"),
                u = s.some,
                c = 2048,
                d = 32 * 1024;
              function m() {
                if (e.navigator == null) return !1;
                var t = e.navigator.userAgent;
                return t == null
                  ? !1
                  : t.indexOf("Android") >= 0 &&
                      (t.indexOf("FB_IAB") >= 0 || t.indexOf("Instagram") >= 0);
              }
              function p() {
                return m() && r.isInTest(l) ? d : c;
              }
              function _(e, r) {
                try {
                  var o = r || {},
                    a = o.ignoreRequestLengthCheck,
                    i = a === void 0 ? !1 : a,
                    l = o.url,
                    s = l === void 0 ? t.ENDPOINT : l,
                    c = o.attributionReporting,
                    d = c === void 0 ? !1 : c,
                    m = o.highFetchPriority,
                    _ = m === void 0 ? !1 : m,
                    f = o.expv2;
                  e.set("rqm", i ? "FGET" : "GET"),
                    f != null && f.length > 0 && e.setAsDict("expv2", f);
                  var g = e.toQueryString(),
                    h = s + "?" + g;
                  if (i || h.length < p()) {
                    var y = new Image();
                    r != null &&
                      r.errorHandler != null &&
                      (y.onerror = r.errorHandler);
                    var C = n.trigger(e);
                    return (
                      u(C, function (e) {
                        return e;
                      }) && (y.referrerPolicy = "origin"),
                      d && y.setAttribute("attributionsrc", ""),
                      _ && (y.fetchPriority = "high"),
                      (y.src = h),
                      !0
                    );
                  }
                  return !1;
                } catch (e) {
                  return !1;
                }
              }
              o.exports = _;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsSetCCRules", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsTyped"),
                n = t.coerce,
                r = t.Typed,
                i = a.getFbeventsModules("signalsFBEventsCoercePixelID"),
                l = r.arrayOf(
                  r.objectWithFields({ id: r.number(), rule: r.string() })
                );
              function s() {
                for (
                  var e = arguments.length, t = new Array(e), r = 0;
                  r < e;
                  r++
                )
                  t[r] = arguments[r];
                var o = t[0];
                if (o == null || G(o) !== "object") return null;
                var a = o.pixelID,
                  s = o.rules,
                  u = i(a);
                if (u == null) return null;
                var c = n(s, l);
                return [{ rules: c, pixelID: u }];
              }
              var u = new e(s);
              o.exports = u;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsSetESTRules", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsTyped"),
                n = t.coerce,
                r = t.Typed,
                i = a.getFbeventsModules("signalsFBEventsCoercePixelID"),
                l = r.arrayOf(
                  r.objectWithFields({
                    condition: r.objectOrString(),
                    derived_event_name: r.string(),
                    rule_status: r.allowNull(r.string()),
                    transformations: r.allowNull(r.array()),
                    rule_id: r.allowNull(r.string()),
                  })
                );
              function s() {
                for (
                  var e = arguments.length, t = new Array(e), r = 0;
                  r < e;
                  r++
                )
                  t[r] = arguments[r];
                var o = t[0];
                if (o == null || G(o) !== "object") return null;
                var a = o.pixelID,
                  s = o.rules,
                  u = i(a);
                if (u == null) return null;
                var c = n(s, l);
                return [{ rules: c, pixelID: u }];
              }
              var u = new e(s);
              o.exports = u;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsSetEventIDEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsParamList"),
                n = a.getFbeventsModules("SignalsFBEventsTyped"),
                r = n.coerce,
                i = a.getFbeventsModules("signalsFBEventsCoercePixelID");
              function l(e, n, o) {
                var a = i(e),
                  l = n instanceof t ? n : null,
                  s = r(o, String);
                return a != null && l != null && s != null ? [a, l, s] : null;
              }
              var s = new e(l);
              o.exports = s;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsSetFilteredEventName",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsParamList");
                function n(e) {
                  var n = e instanceof t ? e : null;
                  return n != null ? [n] : null;
                }
                var r = new e(n);
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsSetIWLExtractorsEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsUtils"),
                  n = t.filter,
                  r = t.map,
                  i = a.getFbeventsModules(
                    "signalsFBEventsCoerceParameterExtractors"
                  ),
                  l = a.getFbeventsModules("signalsFBEventsCoercePixelID");
                function s() {
                  for (
                    var e = arguments.length, t = new Array(e), o = 0;
                    o < e;
                    o++
                  )
                    t[o] = arguments[o];
                  var a = t[0];
                  if (a == null || G(a) !== "object") return null;
                  var s = a.pixelID,
                    u = a.extractors,
                    c = l(s),
                    d = Array.isArray(u) ? r(u, i) : null,
                    m = d != null ? n(d, Boolean) : null;
                  return m != null &&
                    d != null &&
                    m.length === d.length &&
                    c != null
                    ? [{ extractors: m, pixelID: c }]
                    : null;
                }
                var u = new e(s);
                o.exports = u;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsSetIWLParameterRulesEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsTyped"),
                  n = t.coerce,
                  r = t.Typed,
                  i = a.getFbeventsModules("signalsFBEventsCoercePixelID"),
                  l = r.arrayOf(
                    r.objectWithFields({
                      condition: r.objectOrString(),
                      derived_event_name: r.string(),
                      rule_id: r.allowNull(r.string()),
                      extractors: r.allowNull(r.array()),
                    })
                  );
                function s() {
                  for (
                    var e = arguments.length, t = new Array(e), r = 0;
                    r < e;
                    r++
                  )
                    t[r] = arguments[r];
                  var o = t[0];
                  if (o == null || G(o) !== "object") return null;
                  var a = o.pixelID,
                    s = o.rules,
                    u = i(a);
                  if (u == null) return null;
                  var c = n(s, l);
                  return [{ rules: c, pixelID: u }];
                }
                var u = new e(s);
                o.exports = u;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsShared", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              (function () {
                "use strict";
                var n = {
                    3: function (t, n, r) {
                      var e = r(2640);
                      t.exports = e;
                    },
                    182: function (t, n, r) {
                      var e = r(2073),
                        o = r(4003),
                        a = TypeError;
                      t.exports = function (t) {
                        if (e(t)) return t;
                        throw a(o(t) + " is not a function");
                      };
                    },
                    235: function (t, n, r) {
                      var e = r(9036),
                        o = r(6759),
                        a = r(7803),
                        i = r(8890),
                        l = e("".charAt),
                        s = e("".charCodeAt),
                        u = e("".slice),
                        c = function (t) {
                          return function (e, n) {
                            var r,
                              c,
                              d = a(i(e)),
                              m = o(n),
                              p = d.length;
                            return m < 0 || m >= p
                              ? t
                                ? ""
                                : void 0
                              : (r = s(d, m)) < 55296 ||
                                r > 56319 ||
                                m + 1 === p ||
                                (c = s(d, m + 1)) < 56320 ||
                                c > 57343
                              ? t
                                ? l(d, m)
                                : r
                              : t
                              ? u(d, m, m + 2)
                              : c - 56320 + ((r - 55296) << 10) + 65536;
                          };
                        };
                      t.exports = { codeAt: c(!1), charAt: c(!0) };
                    },
                    244: function (t, n, r) {
                      var e = r(9036),
                        o = e({}.toString),
                        a = e("".slice);
                      t.exports = function (e) {
                        return a(o(e), 8, -1);
                      };
                    },
                    266: function (t, n, r) {
                      var e = r(182),
                        o = r(5809),
                        a = r(6731),
                        i = r(954),
                        l = TypeError,
                        s = function (n) {
                          return function (t, r, s, u) {
                            e(r);
                            var c = o(t),
                              d = a(c),
                              m = i(c),
                              p = n ? m - 1 : 0,
                              _ = n ? -1 : 1;
                            if (s < 2)
                              for (;;) {
                                if (p in d) {
                                  (u = d[p]), (p += _);
                                  break;
                                }
                                if (((p += _), n ? p < 0 : m <= p))
                                  throw l(
                                    "Reduce of empty array with no initial value"
                                  );
                              }
                            for (; n ? p >= 0 : m > p; p += _)
                              p in d && (u = r(u, d[p], p, c));
                            return u;
                          };
                        };
                      t.exports = { left: s(!1), right: s(!0) };
                    },
                    347: function (t) {
                      t.exports = [
                        "constructor",
                        "hasOwnProperty",
                        "isPrototypeOf",
                        "propertyIsEnumerable",
                        "toLocaleString",
                        "toString",
                        "valueOf",
                      ];
                    },
                    492: function (t, n, r) {
                      var e = r(8471);
                      t.exports = function (t, n, r, o) {
                        return o && o.enumerable ? (t[n] = r) : e(t, n, r), t;
                      };
                    },
                    538: function (t, n, r) {
                      var e = r(7131);
                      t.exports = function (t, n) {
                        var r = [][t];
                        return (
                          !!r &&
                          e(function () {
                            r.call(
                              null,
                              n ||
                                function () {
                                  return 1;
                                },
                              1
                            );
                          })
                        );
                      };
                    },
                    651: function (t, n, r) {
                      var e = r(3557),
                        o = r(7980),
                        a = e("keys");
                      t.exports = function (e) {
                        return a[e] || (a[e] = o(e));
                      };
                    },
                    789: function (t) {
                      t.exports = function (e, t) {
                        return { value: e, done: t };
                      };
                    },
                    802: function (t, n, r) {
                      r(1284);
                      var e = r(8843);
                      t.exports = e("Array", "filter");
                    },
                    892: function (t, n, r) {
                      var e = r(6215);
                      t.exports = e;
                    },
                    909: function (t, n, r) {
                      var e = r(5391),
                        o = Object.defineProperty;
                      t.exports = function (t, n) {
                        try {
                          o(e, t, { value: n, configurable: !0, writable: !0 });
                        } catch (r) {
                          e[t] = n;
                        }
                        return n;
                      };
                    },
                    954: function (t, n, r) {
                      var e = r(2954);
                      t.exports = function (t) {
                        return e(t.length);
                      };
                    },
                    1001: function (t, n, r) {
                      var e = r(892);
                      t.exports = e;
                    },
                    1004: function (t, n, r) {
                      var e = r(7235);
                      t.exports =
                        e &&
                        !(typeof Symbol != "function" || Symbol.sham) &&
                        G(
                          typeof Symbol == "function"
                            ? Symbol.iterator
                            : "@@iterator"
                        ) == "symbol";
                    },
                    1049: function (t) {
                      var e = Math.ceil,
                        n = Math.floor;
                      t.exports =
                        Math.trunc ||
                        function (t) {
                          var r = +t;
                          return (r > 0 ? n : e)(r);
                        };
                    },
                    1059: function (t, n, r) {
                      r(7765);
                      var e = r(8843);
                      t.exports = e("Array", "find");
                    },
                    1113: function (t) {
                      t.exports = {};
                    },
                    1225: function (t, n, r) {
                      var e = r(7131),
                        o = r(6615),
                        a = r(6312),
                        i = o("species");
                      t.exports = function (t) {
                        return (
                          a >= 51 ||
                          !e(function () {
                            var e = [];
                            return (
                              ((e.constructor = {})[i] = function () {
                                return { foo: 1 };
                              }),
                              e[t](Boolean).foo !== 1
                            );
                          })
                        );
                      };
                    },
                    1284: function (t, n, r) {
                      var e = r(1938),
                        o = r(2217).filter;
                      e(
                        {
                          target: "Array",
                          proto: !0,
                          forced: !r(1225)("filter"),
                        },
                        {
                          filter: function (t) {
                            return o(
                              this,
                              t,
                              arguments.length > 1 ? arguments[1] : void 0
                            );
                          },
                        }
                      );
                    },
                    1306: function (t, n, r) {
                      var e = r(1938),
                        o = r(2217).map;
                      e(
                        { target: "Array", proto: !0, forced: !r(1225)("map") },
                        {
                          map: function (t) {
                            return o(
                              this,
                              t,
                              arguments.length > 1 ? arguments[1] : void 0
                            );
                          },
                        }
                      );
                    },
                    1731: function (t, n, r) {
                      var e = r(7452);
                      t.exports = e;
                    },
                    1938: function (t, n, r) {
                      var e = r(5391),
                        o = r(1981),
                        a = r(9e3),
                        i = r(2073),
                        l = r(5687).f,
                        s = r(3488),
                        u = r(7675),
                        c = r(2116),
                        d = r(8471),
                        m = r(4373),
                        p = function (t) {
                          var e = function (r, a, i) {
                            if (this instanceof e) {
                              switch (arguments.length) {
                                case 0:
                                  return new t();
                                case 1:
                                  return new t(r);
                                case 2:
                                  return new t(r, a);
                              }
                              return new t(r, a, i);
                            }
                            return o(t, this, arguments);
                          };
                          return (e.prototype = t.prototype), e;
                        };
                      t.exports = function (t, n) {
                        var r,
                          o,
                          _,
                          f,
                          g,
                          h,
                          y,
                          C,
                          b,
                          v = t.target,
                          S = t.global,
                          R = t.stat,
                          L = t.proto,
                          E = S ? e : R ? e[v] : (e[v] || {}).prototype,
                          k = S ? u : u[v] || d(u, v, {})[v],
                          I = k.prototype;
                        for (f in n)
                          (o =
                            !(r = s(
                              S ? f : v + (R ? "." : "#") + f,
                              t.forced
                            )) &&
                            E &&
                            m(E, f)),
                            (h = k[f]),
                            o &&
                              (y = t.dontCallGetSet
                                ? (b = l(E, f)) && b.value
                                : E[f]),
                            (g = o && y ? y : n[f]),
                            (o && G(h) == G(g)) ||
                              ((C =
                                t.bind && o
                                  ? c(g, e)
                                  : t.wrap && o
                                  ? p(g)
                                  : L && i(g)
                                  ? a(g)
                                  : g),
                              (t.sham || (g && g.sham) || (h && h.sham)) &&
                                d(C, "sham", !0),
                              d(k, f, C),
                              L &&
                                (m(u, (_ = v + "Prototype")) || d(u, _, {}),
                                d(u[_], f, g),
                                t.real && I && (r || !I[f]) && d(I, f, g)));
                      };
                    },
                    1972: function (t, n, r) {
                      var e = r(244);
                      t.exports =
                        Array.isArray ||
                        function (t) {
                          return e(t) === "Array";
                        };
                    },
                    1981: function (t, n, r) {
                      var e = r(5164),
                        o = Function.prototype,
                        a = o.apply,
                        i = o.call;
                      t.exports =
                        ((typeof Reflect == "undefined"
                          ? "undefined"
                          : G(Reflect)) == "object" &&
                          Reflect.apply) ||
                        (e
                          ? i.bind(a)
                          : function () {
                              return i.apply(a, arguments);
                            });
                    },
                    2073: function (t, n, r) {
                      var e = r(7023),
                        o = e.all;
                      t.exports = e.IS_HTMLDDA
                        ? function (e) {
                            return typeof e == "function" || e === o;
                          }
                        : function (e) {
                            return typeof e == "function";
                          };
                    },
                    2116: function (t, n, r) {
                      var e = r(9e3),
                        o = r(182),
                        a = r(5164),
                        i = e(e.bind);
                      t.exports = function (e, t) {
                        return (
                          o(e),
                          t === void 0
                            ? e
                            : a
                            ? i(e, t)
                            : function () {
                                return e.apply(t, arguments);
                              }
                        );
                      };
                    },
                    2217: function (t, n, r) {
                      var e = r(2116),
                        o = r(9036),
                        a = r(6731),
                        i = r(5809),
                        l = r(954),
                        s = r(6601),
                        u = o([].push),
                        c = function (n) {
                          var t = n === 1,
                            r = n === 2,
                            o = n === 3,
                            c = n === 4,
                            d = n === 6,
                            m = n === 7,
                            p = n === 5 || d;
                          return function (_, f, g, h) {
                            for (
                              var y,
                                C,
                                b = i(_),
                                v = a(b),
                                S = e(f, g),
                                R = l(v),
                                L = 0,
                                E = h || s,
                                k = t ? E(_, R) : r || m ? E(_, 0) : void 0;
                              R > L;
                              L++
                            )
                              if (
                                (p || L in v) &&
                                ((C = S((y = v[L]), L, b)), n)
                              )
                                if (t) k[L] = C;
                                else if (C)
                                  switch (n) {
                                    case 3:
                                      return !0;
                                    case 5:
                                      return y;
                                    case 6:
                                      return L;
                                    case 2:
                                      u(k, y);
                                  }
                                else
                                  switch (n) {
                                    case 4:
                                      return !1;
                                    case 7:
                                      u(k, y);
                                  }
                            return d ? -1 : o || c ? c : k;
                          };
                        };
                      t.exports = {
                        forEach: c(0),
                        map: c(1),
                        filter: c(2),
                        some: c(3),
                        every: c(4),
                        find: c(5),
                        findIndex: c(6),
                        filterReject: c(7),
                      };
                    },
                    2373: function (t, n, r) {
                      var e,
                        o,
                        a,
                        i = r(7131),
                        l = r(2073),
                        s = r(5774),
                        u = r(3628),
                        c = r(3439),
                        d = r(492),
                        m = r(6615),
                        p = r(3599),
                        _ = m("iterator"),
                        f = !1;
                      [].keys &&
                        ("next" in (a = [].keys())
                          ? (o = c(c(a))) !== Object.prototype && (e = o)
                          : (f = !0)),
                        !s(e) ||
                        i(function () {
                          var t = {};
                          return e[_].call(t) !== t;
                        })
                          ? (e = {})
                          : p && (e = u(e)),
                        l(e[_]) ||
                          d(e, _, function () {
                            return this;
                          }),
                        (t.exports = {
                          IteratorPrototype: e,
                          BUGGY_SAFARI_ITERATORS: f,
                        });
                    },
                    2506: function (t, n, r) {
                      var e = r(5560),
                        o = r(7131);
                      t.exports =
                        e &&
                        o(function () {
                          return (
                            Object.defineProperty(function () {}, "prototype", {
                              value: 42,
                              writable: !1,
                            }).prototype !== 42
                          );
                        });
                    },
                    2633: function (t, n, r) {
                      var e = r(5560),
                        o = r(7131),
                        a = r(6171);
                      t.exports =
                        !e &&
                        !o(function () {
                          return (
                            Object.defineProperty(a("div"), "a", {
                              get: function () {
                                return 7;
                              },
                            }).a !== 7
                          );
                        });
                    },
                    2640: function (t, n, r) {
                      var e = r(3109);
                      t.exports = e;
                    },
                    2780: function (t, n, r) {
                      var e,
                        o = r(1938),
                        a = r(9e3),
                        i = r(5687).f,
                        l = r(2954),
                        s = r(7803),
                        u = r(5923),
                        c = r(8890),
                        d = r(7288),
                        m = r(3599),
                        p = a("".startsWith),
                        _ = a("".slice),
                        f = Math.min,
                        g = d("startsWith");
                      o(
                        {
                          target: "String",
                          proto: !0,
                          forced:
                            !!(
                              m ||
                              g ||
                              ((e = i(String.prototype, "startsWith")),
                              !e || e.writable)
                            ) && !g,
                        },
                        {
                          startsWith: function (t) {
                            var e = s(c(this));
                            u(t);
                            var n = l(
                                f(
                                  arguments.length > 1 ? arguments[1] : void 0,
                                  e.length
                                )
                              ),
                              r = s(t);
                            return p ? p(e, r, n) : _(e, n, n + r.length) === r;
                          },
                        }
                      );
                    },
                    2843: function (t, n, r) {
                      var e = r(8347),
                        o = r(7959);
                      t.exports = function (t, n, r, a) {
                        try {
                          return a ? n(e(r)[0], r[1]) : n(r);
                        } catch (e) {
                          o(t, "throw", e);
                        }
                      };
                    },
                    2954: function (t, n, r) {
                      var e = r(6759),
                        o = Math.min;
                      t.exports = function (t) {
                        return t > 0 ? o(e(t), 9007199254740991) : 0;
                      };
                    },
                    3057: function (t, n, r) {
                      var e = r(5164),
                        o = Function.prototype.call;
                      t.exports = e
                        ? o.bind(o)
                        : function () {
                            return o.apply(o, arguments);
                          };
                    },
                    3109: function (t, n, r) {
                      r(7019);
                      var e = r(8843);
                      t.exports = e("Array", "includes");
                    },
                    3381: function (t, n, r) {
                      var e = r(9036);
                      t.exports = e({}.isPrototypeOf);
                    },
                    3439: function (t, n, r) {
                      var e = r(4373),
                        o = r(2073),
                        a = r(5809),
                        i = r(651),
                        l = r(7007),
                        s = i("IE_PROTO"),
                        u = Object,
                        c = u.prototype;
                      t.exports = l
                        ? u.getPrototypeOf
                        : function (t) {
                            var n = a(t);
                            if (e(n, s)) return n[s];
                            var r = n.constructor;
                            return o(r) && n instanceof r
                              ? r.prototype
                              : n instanceof u
                              ? c
                              : null;
                          };
                    },
                    3488: function (t, n, r) {
                      var e = r(7131),
                        o = r(2073),
                        a = /#|\.prototype\./,
                        i = function (n, r) {
                          var t = s[l(n)];
                          return t === c || (t !== u && (o(r) ? e(r) : !!r));
                        },
                        l = (i.normalize = function (e) {
                          return String(e).replace(a, ".").toLowerCase();
                        }),
                        s = (i.data = {}),
                        u = (i.NATIVE = "N"),
                        c = (i.POLYFILL = "P");
                      t.exports = i;
                    },
                    3514: function (t, n, r) {
                      var e = r(182),
                        o = r(6153);
                      t.exports = function (t, n) {
                        var r = t[n];
                        return o(r) ? void 0 : e(r);
                      };
                    },
                    3550: function (t, n, r) {
                      var e = r(3);
                      t.exports = e;
                    },
                    3557: function (t, n, r) {
                      var e = r(3599),
                        o = r(4993);
                      (t.exports = function (e, t) {
                        return o[e] || (o[e] = t !== void 0 ? t : {});
                      })("versions", []).push({
                        version: "3.32.2",
                        mode: e ? "pure" : "global",
                        copyright:
                          "\xA9 2014-2023 Denis Pushkarev (zloirock.ru)",
                        license:
                          "https://github.com/zloirock/core-js/blob/v3.32.2/LICENSE",
                        source: "https://github.com/zloirock/core-js",
                      });
                    },
                    3599: function (t) {
                      t.exports = !0;
                    },
                    3628: function (n, r, o) {
                      var e,
                        a = o(8347),
                        i = o(9157),
                        l = o(347),
                        s = o(6145),
                        u = o(9417),
                        c = o(6171),
                        d = o(651),
                        m = "prototype",
                        p = "script",
                        _ = d("IE_PROTO"),
                        f = function () {},
                        g = function (t) {
                          return "<" + p + ">" + t + "</" + p + ">";
                        },
                        h = function (t) {
                          t.write(g("")), t.close();
                          var e = t.parentWindow.Object;
                          return (t = null), e;
                        },
                        y = function () {
                          try {
                            e = new ActiveXObject("htmlfile");
                          } catch (e) {}
                          var n, r, o;
                          y =
                            typeof t != "undefined"
                              ? t.domain && e
                                ? h(e)
                                : ((r = c("iframe")),
                                  (o = "java" + p + ":"),
                                  (r.style.display = "none"),
                                  u.appendChild(r),
                                  (r.src = String(o)),
                                  (n = r.contentWindow.document).open(),
                                  n.write(g("document.F=Object")),
                                  n.close(),
                                  n.F)
                              : h(e);
                          for (var a = l.length; a--; ) delete y[m][l[a]];
                          return y();
                        };
                      (s[_] = !0),
                        (n.exports =
                          Object.create ||
                          function (e, t) {
                            var n;
                            return (
                              e !== null
                                ? ((f[m] = a(e)),
                                  (n = new f()),
                                  (f[m] = null),
                                  (n[_] = e))
                                : (n = y()),
                              t === void 0 ? n : i.f(n, t)
                            );
                          });
                    },
                    3768: function (t) {
                      t.exports = function (e, t) {
                        return {
                          enumerable: !(1 & e),
                          configurable: !(2 & e),
                          writable: !(4 & e),
                          value: t,
                        };
                      };
                    },
                    3859: function (t, n, r) {
                      var e = r(802);
                      t.exports = e;
                    },
                    3969: function (t, n, r) {
                      var e = r(7827),
                        o = r(2073),
                        a = r(3381),
                        i = r(1004),
                        l = Object;
                      t.exports = i
                        ? function (e) {
                            return G(e) == "symbol";
                          }
                        : function (t) {
                            var n = e("Symbol");
                            return o(n) && a(n.prototype, l(t));
                          };
                    },
                    4003: function (t) {
                      var e = String;
                      t.exports = function (t) {
                        try {
                          return e(t);
                        } catch (e) {
                          return "Object";
                        }
                      };
                    },
                    4084: function (t) {
                      t.exports =
                        (typeof navigator != "undefined" &&
                          String(navigator.userAgent)) ||
                        "";
                    },
                    4090: function (t, n, r) {
                      r(8132);
                      var e = r(8843);
                      t.exports = e("Array", "reduce");
                    },
                    4373: function (t, n, r) {
                      var e = r(9036),
                        o = r(5809),
                        a = e({}.hasOwnProperty);
                      t.exports =
                        Object.hasOwn ||
                        function (e, t) {
                          return a(o(e), t);
                        };
                    },
                    4512: function (t, n, r) {
                      var e = r(9036),
                        o = r(4373),
                        a = r(9441),
                        i = r(4581).indexOf,
                        l = r(6145),
                        s = e([].push);
                      t.exports = function (e, t) {
                        var n,
                          r = a(e),
                          u = 0,
                          c = [];
                        for (n in r) !o(l, n) && o(r, n) && s(c, n);
                        for (; t.length > u; )
                          o(r, (n = t[u++])) && (~i(c, n) || s(c, n));
                        return c;
                      };
                    },
                    4581: function (t, n, r) {
                      var e = r(9441),
                        o = r(8630),
                        a = r(954),
                        i = function (n) {
                          return function (t, r, i) {
                            var l,
                              s = e(t),
                              u = a(s),
                              c = o(i, u);
                            if (n && r != r) {
                              for (; u > c; ) if ((l = s[c++]) != l) return !0;
                            } else
                              for (; u > c; c++)
                                if ((n || c in s) && s[c] === r)
                                  return n || c || 0;
                            return !n && -1;
                          };
                        };
                      t.exports = { includes: i(!0), indexOf: i(!1) };
                    },
                    4619: function (t, n, r) {
                      var e = r(7006),
                        o = r(8347),
                        a = r(8934);
                      t.exports =
                        Object.setPrototypeOf ||
                        ("__proto__" in {}
                          ? (function () {
                              var t,
                                n = !1,
                                r = {};
                              try {
                                (t = e(Object.prototype, "__proto__", "set"))(
                                  r,
                                  []
                                ),
                                  (n = r instanceof Array);
                              } catch (e) {}
                              return function (e, r) {
                                return (
                                  o(e), a(r), n ? t(e, r) : (e.__proto__ = r), e
                                );
                              };
                            })()
                          : void 0);
                    },
                    4734: function (t, n, r) {
                      var e = r(1059);
                      t.exports = e;
                    },
                    4817: function (t, n, r) {
                      var e = r(6002);
                      t.exports = e;
                    },
                    4909: function (t, n, r) {
                      var e = r(5423);
                      t.exports = function t(n, r) {
                        return (
                          !(!n || !r) &&
                          (n === r ||
                            (!e(n) &&
                              (e(r)
                                ? t(n, r.parentNode)
                                : "contains" in n
                                ? n.contains(r)
                                : !!n.compareDocumentPosition &&
                                  !!(16 & n.compareDocumentPosition(r)))))
                        );
                      };
                    },
                    4970: function (t, n, r) {
                      var e = r(5560),
                        o = r(4373),
                        a = Function.prototype,
                        i = e && Object.getOwnPropertyDescriptor,
                        l = o(a, "name"),
                        s = l && function () {}.name === "something",
                        u = l && (!e || (e && i(a, "name").configurable));
                      t.exports = { EXISTS: l, PROPER: s, CONFIGURABLE: u };
                    },
                    4993: function (t, n, r) {
                      var e = r(5391),
                        o = r(909),
                        a = "__core-js_shared__",
                        i = e[a] || o(a, {});
                      t.exports = i;
                    },
                    5023: function (t, n, r) {
                      var e = r(9830);
                      t.exports = e;
                    },
                    5045: function (t, n, r) {
                      var e = r(3057),
                        o = r(5774),
                        a = r(3969),
                        i = r(3514),
                        l = r(6034),
                        s = r(6615),
                        u = TypeError,
                        c = s("toPrimitive");
                      t.exports = function (t, n) {
                        if (!o(t) || a(t)) return t;
                        var r,
                          s = i(t, c);
                        if (s) {
                          if (
                            (n === void 0 && (n = "default"),
                            (r = e(s, t, n)),
                            !o(r) || a(r))
                          )
                            return r;
                          throw u("Can't convert object to primitive value");
                        }
                        return n === void 0 && (n = "number"), l(t, n);
                      };
                    },
                    5051: function (t, n, r) {
                      var e = r(7104),
                        o = r(6381).f,
                        a = r(8471),
                        i = r(4373),
                        l = r(5759),
                        s = r(6615)("toStringTag");
                      t.exports = function (t, n, r, u) {
                        if (t) {
                          var c = r ? t : t.prototype;
                          i(c, s) || o(c, s, { configurable: !0, value: n }),
                            u && !e && a(c, "toString", l);
                        }
                      };
                    },
                    5109: function (t, n, r) {
                      var e = r(7004);
                      t.exports = e;
                    },
                    5141: function (t, n, r) {
                      var e = r(5045),
                        o = r(3969);
                      t.exports = function (t) {
                        var n = e(t, "string");
                        return o(n) ? n : n + "";
                      };
                    },
                    5164: function (t, n, r) {
                      var e = r(7131);
                      t.exports = !e(function () {
                        var e = function () {}.bind();
                        return (
                          typeof e != "function" ||
                          Object.prototype.hasOwnProperty.call(e, "prototype")
                        );
                      });
                    },
                    5391: function (n, r, o) {
                      var t = function (t) {
                        return t && t.Math === Math && t;
                      };
                      n.exports =
                        t(
                          (typeof globalThis == "undefined"
                            ? "undefined"
                            : G(globalThis)) == "object" && globalThis
                        ) ||
                        t(G(e) == "object" && e) ||
                        t(
                          (typeof self == "undefined"
                            ? "undefined"
                            : G(self)) == "object" && self
                        ) ||
                        t(G(o.g) == "object" && o.g) ||
                        (function () {
                          return this;
                        })() ||
                        this ||
                        Function("return this")();
                    },
                    5423: function (t, n, r) {
                      var e = r(5504);
                      t.exports = function (t) {
                        return e(t) && t.nodeType == 3;
                      };
                    },
                    5504: function (r) {
                      r.exports = function (n) {
                        var r = (n ? n.ownerDocument || n : t).defaultView || e;
                        return !(
                          !n ||
                          !(typeof r.Node == "function"
                            ? n instanceof r.Node
                            : G(n) == "object" &&
                              typeof n.nodeType == "number" &&
                              typeof n.nodeName == "string")
                        );
                      };
                    },
                    5556: function (t, n, r) {
                      var e = r(4512),
                        o = r(347);
                      t.exports =
                        Object.keys ||
                        function (t) {
                          return e(t, o);
                        };
                    },
                    5560: function (t, n, r) {
                      var e = r(7131);
                      t.exports = !e(function () {
                        return (
                          Object.defineProperty({}, 1, {
                            get: function () {
                              return 7;
                            },
                          })[1] !== 7
                        );
                      });
                    },
                    5663: function (t, n, r) {
                      var e = r(7104),
                        o = r(2073),
                        a = r(244),
                        i = r(6615)("toStringTag"),
                        l = Object,
                        s =
                          a(
                            (function () {
                              return arguments;
                            })()
                          ) === "Arguments";
                      t.exports = e
                        ? a
                        : function (e) {
                            var t, n, r;
                            return e === void 0
                              ? "Undefined"
                              : e === null
                              ? "Null"
                              : typeof (n = (function (e, t) {
                                  try {
                                    return e[t];
                                  } catch (e) {}
                                })((t = l(e)), i)) == "string"
                              ? n
                              : s
                              ? a(t)
                              : (r = a(t)) === "Object" && o(t.callee)
                              ? "Arguments"
                              : r;
                          };
                    },
                    5669: function (t, n, r) {
                      var e = r(6615),
                        o = r(1113),
                        a = e("iterator"),
                        i = Array.prototype;
                      t.exports = function (e) {
                        return e !== void 0 && (o.Array === e || i[a] === e);
                      };
                    },
                    5687: function (t, n, r) {
                      var e = r(5560),
                        o = r(3057),
                        a = r(6337),
                        i = r(3768),
                        l = r(9441),
                        s = r(5141),
                        u = r(4373),
                        c = r(2633),
                        d = Object.getOwnPropertyDescriptor;
                      n.f = e
                        ? d
                        : function (e, t) {
                            if (((e = l(e)), (t = s(t)), c))
                              try {
                                return d(e, t);
                              } catch (e) {}
                            if (u(e, t)) return i(!o(a.f, e, t), e[t]);
                          };
                    },
                    5759: function (t, n, r) {
                      var e = r(7104),
                        o = r(5663);
                      t.exports = e
                        ? {}.toString
                        : function () {
                            return "[object " + o(this) + "]";
                          };
                    },
                    5774: function (t, n, r) {
                      var e = r(2073),
                        o = r(7023),
                        a = o.all;
                      t.exports = o.IS_HTMLDDA
                        ? function (t) {
                            return G(t) == "object"
                              ? t !== null
                              : e(t) || t === a;
                          }
                        : function (t) {
                            return G(t) == "object" ? t !== null : e(t);
                          };
                    },
                    5809: function (t, n, r) {
                      var e = r(8890),
                        o = Object;
                      t.exports = function (t) {
                        return o(e(t));
                      };
                    },
                    5837: function (t, n, r) {
                      var e = r(4734);
                      t.exports = e;
                    },
                    5856: function (t, n, r) {
                      var e = r(5774),
                        o = r(244),
                        a = r(6615)("match");
                      t.exports = function (t) {
                        var n;
                        return (
                          e(t) &&
                          ((n = t[a]) !== void 0 ? !!n : o(t) === "RegExp")
                        );
                      };
                    },
                    5923: function (t, n, r) {
                      var e = r(5856),
                        o = TypeError;
                      t.exports = function (t) {
                        if (e(t))
                          throw o(
                            "The method doesn't accept regular expressions"
                          );
                        return t;
                      };
                    },
                    6002: function (t, n, r) {
                      var e = r(1731);
                      t.exports = e;
                    },
                    6034: function (t, n, r) {
                      var e = r(3057),
                        o = r(2073),
                        a = r(5774),
                        i = TypeError;
                      t.exports = function (t, n) {
                        var r, l;
                        if (
                          (n === "string" &&
                            o((r = t.toString)) &&
                            !a((l = e(r, t)))) ||
                          (o((r = t.valueOf)) && !a((l = e(r, t)))) ||
                          (n !== "string" &&
                            o((r = t.toString)) &&
                            !a((l = e(r, t))))
                        )
                          return l;
                        throw i("Can't convert object to primitive value");
                      };
                    },
                    6065: function (t) {
                      t.exports = function () {};
                    },
                    6145: function (t) {
                      t.exports = {};
                    },
                    6153: function (t) {
                      t.exports = function (e) {
                        return e == null;
                      };
                    },
                    6171: function (t, n, r) {
                      var e = r(5391),
                        o = r(5774),
                        a = e.document,
                        i = o(a) && o(a.createElement);
                      t.exports = function (e) {
                        return i ? a.createElement(e) : {};
                      };
                    },
                    6188: function (t, n, r) {
                      var e = r(1938),
                        o = r(3057),
                        a = r(3599),
                        i = r(4970),
                        l = r(2073),
                        s = r(7102),
                        u = r(3439),
                        c = r(4619),
                        d = r(5051),
                        m = r(8471),
                        p = r(492),
                        _ = r(6615),
                        f = r(1113),
                        g = r(2373),
                        h = i.PROPER,
                        y = i.CONFIGURABLE,
                        C = g.IteratorPrototype,
                        b = g.BUGGY_SAFARI_ITERATORS,
                        v = _("iterator"),
                        S = "keys",
                        R = "values",
                        L = "entries",
                        E = function () {
                          return this;
                        };
                      t.exports = function (t, n, r, i, _, g, k) {
                        s(r, n, i);
                        var I,
                          T,
                          D,
                          x = function (t) {
                            if (t === _ && w) return w;
                            if (!b && t && t in N) return N[t];
                            switch (t) {
                              case S:
                              case R:
                              case L:
                                return function () {
                                  return new r(this, t);
                                };
                            }
                            return function () {
                              return new r(this);
                            };
                          },
                          $ = n + " Iterator",
                          P = !1,
                          N = t.prototype,
                          M = N[v] || N["@@iterator"] || (_ && N[_]),
                          w = (!b && M) || x(_),
                          A = (n === "Array" && N.entries) || M;
                        if (
                          (A &&
                            (I = u(A.call(new t()))) !== Object.prototype &&
                            I.next &&
                            (a ||
                              u(I) === C ||
                              (c ? c(I, C) : l(I[v]) || p(I, v, E)),
                            d(I, $, !0, !0),
                            a && (f[$] = E)),
                          h &&
                            _ === R &&
                            M &&
                            M.name !== R &&
                            (!a && y
                              ? m(N, "name", R)
                              : ((P = !0),
                                (w = function () {
                                  return o(M, this);
                                }))),
                          _)
                        )
                          if (
                            ((T = {
                              values: x(R),
                              keys: g ? w : x(S),
                              entries: x(L),
                            }),
                            k)
                          )
                            for (D in T) (b || P || !(D in N)) && p(N, D, T[D]);
                          else e({ target: n, proto: !0, forced: b || P }, T);
                        return (
                          (a && !k) || N[v] === w || p(N, v, w, { name: _ }),
                          (f[n] = w),
                          T
                        );
                      };
                    },
                    6206: function (t, n, r) {
                      var e = r(1938),
                        o = r(6864);
                      e(
                        {
                          target: "Array",
                          stat: !0,
                          forced: !r(8224)(function (e) {
                            Array.from(e);
                          }),
                        },
                        { from: o }
                      );
                    },
                    6215: function (t, n, r) {
                      var e = r(4090);
                      t.exports = e;
                    },
                    6312: function (t, n, r) {
                      var e,
                        o,
                        a = r(5391),
                        i = r(4084),
                        l = a.process,
                        s = a.Deno,
                        u = (l && l.versions) || (s && s.version),
                        c = u && u.v8;
                      c &&
                        (o =
                          (e = c.split("."))[0] > 0 && e[0] < 4
                            ? 1
                            : +(e[0] + e[1])),
                        !o &&
                          i &&
                          (!(e = i.match(/Edge\/(\d+)/)) || e[1] >= 74) &&
                          (e = i.match(/Chrome\/(\d+)/)) &&
                          (o = +e[1]),
                        (t.exports = o);
                    },
                    6337: function (t, n) {
                      var e = {}.propertyIsEnumerable,
                        r = Object.getOwnPropertyDescriptor,
                        o = r && !e.call({ 1: 2 }, 1);
                      n.f = o
                        ? function (e) {
                            var t = r(this, e);
                            return !!t && t.enumerable;
                          }
                        : e;
                    },
                    6381: function (t, n, r) {
                      var e = r(5560),
                        o = r(2633),
                        a = r(2506),
                        i = r(8347),
                        l = r(5141),
                        s = TypeError,
                        u = Object.defineProperty,
                        c = Object.getOwnPropertyDescriptor,
                        d = "enumerable",
                        m = "configurable",
                        p = "writable";
                      n.f = e
                        ? a
                          ? function (e, t, n) {
                              if (
                                (i(e),
                                (t = l(t)),
                                i(n),
                                typeof e == "function" &&
                                  t === "prototype" &&
                                  "value" in n &&
                                  p in n &&
                                  !n[p])
                              ) {
                                var r = c(e, t);
                                r &&
                                  r[p] &&
                                  ((e[t] = n.value),
                                  (n = {
                                    configurable: m in n ? n[m] : r[m],
                                    enumerable: d in n ? n[d] : r[d],
                                    writable: !1,
                                  }));
                              }
                              return u(e, t, n);
                            }
                          : u
                        : function (e, t, n) {
                            if ((i(e), (t = l(t)), i(n), o))
                              try {
                                return u(e, t, n);
                              } catch (e) {}
                            if ("get" in n || "set" in n)
                              throw s("Accessors not supported");
                            return "value" in n && (e[t] = n.value), e;
                          };
                    },
                    6399: function (t, n, r) {
                      var e = r(5663),
                        o = r(3514),
                        a = r(6153),
                        i = r(1113),
                        l = r(6615)("iterator");
                      t.exports = function (t) {
                        if (!a(t))
                          return o(t, l) || o(t, "@@iterator") || i[e(t)];
                      };
                    },
                    6408: function (t) {
                      t.exports = function (e) {
                        if (e != null) return e;
                        throw new Error("Got unexpected null or undefined");
                      };
                    },
                    6553: function (t, n, r) {
                      var e = r(9036),
                        o = r(7131),
                        a = r(2073),
                        i = r(5663),
                        l = r(7827),
                        s = r(6678),
                        u = function () {},
                        c = [],
                        d = l("Reflect", "construct"),
                        m = /^\s*(?:class|function)\b/,
                        p = e(m.exec),
                        _ = !m.exec(u),
                        f = function (t) {
                          if (!a(t)) return !1;
                          try {
                            return d(u, c, t), !0;
                          } catch (e) {
                            return !1;
                          }
                        },
                        g = function (t) {
                          if (!a(t)) return !1;
                          switch (i(t)) {
                            case "AsyncFunction":
                            case "GeneratorFunction":
                            case "AsyncGeneratorFunction":
                              return !1;
                          }
                          try {
                            return _ || !!p(m, s(t));
                          } catch (e) {
                            return !0;
                          }
                        };
                      (g.sham = !0),
                        (t.exports =
                          !d ||
                          o(function () {
                            var e;
                            return (
                              f(f.call) ||
                              !f(Object) ||
                              !f(function () {
                                e = !0;
                              }) ||
                              e
                            );
                          })
                            ? g
                            : f);
                    },
                    6601: function (t, n, r) {
                      var e = r(9077);
                      t.exports = function (t, n) {
                        return new (e(t))(n === 0 ? 0 : n);
                      };
                    },
                    6615: function (t, n, r) {
                      var e = r(5391),
                        o = r(3557),
                        a = r(4373),
                        i = r(7980),
                        l = r(7235),
                        s = r(1004),
                        u = e.Symbol,
                        c = o("wks"),
                        d = s ? u.for || u : (u && u.withoutSetter) || i;
                      t.exports = function (e) {
                        return (
                          a(c, e) ||
                            (c[e] = l && a(u, e) ? u[e] : d("Symbol." + e)),
                          c[e]
                        );
                      };
                    },
                    6678: function (t, n, r) {
                      var e = r(9036),
                        o = r(2073),
                        a = r(4993),
                        i = e(Function.toString);
                      o(a.inspectSource) ||
                        (a.inspectSource = function (e) {
                          return i(e);
                        }),
                        (t.exports = a.inspectSource);
                    },
                    6731: function (t, n, r) {
                      var e = r(9036),
                        o = r(7131),
                        a = r(244),
                        i = Object,
                        l = e("".split);
                      t.exports = o(function () {
                        return !i("z").propertyIsEnumerable(0);
                      })
                        ? function (e) {
                            return a(e) === "String" ? l(e, "") : i(e);
                          }
                        : i;
                    },
                    6759: function (t, n, r) {
                      var e = r(1049);
                      t.exports = function (t) {
                        var n = +t;
                        return n != n || n === 0 ? 0 : e(n);
                      };
                    },
                    6864: function (t, n, r) {
                      var e = r(2116),
                        o = r(3057),
                        a = r(5809),
                        i = r(2843),
                        l = r(5669),
                        s = r(6553),
                        u = r(954),
                        c = r(8724),
                        d = r(7013),
                        m = r(6399),
                        p = Array;
                      t.exports = function (t) {
                        var n = a(t),
                          r = s(this),
                          _ = arguments.length,
                          f = _ > 1 ? arguments[1] : void 0,
                          g = f !== void 0;
                        g && (f = e(f, _ > 2 ? arguments[2] : void 0));
                        var h,
                          y,
                          C,
                          b,
                          v,
                          S,
                          R = m(n),
                          L = 0;
                        if (!R || (this === p && l(R)))
                          for (h = u(n), y = r ? new this(h) : p(h); h > L; L++)
                            (S = g ? f(n[L], L) : n[L]), c(y, L, S);
                        else
                          for (
                            v = (b = d(n, R)).next, y = r ? new this() : [];
                            !(C = o(v, b)).done;
                            L++
                          )
                            (S = g ? i(b, f, [C.value, L], !0) : C.value),
                              c(y, L, S);
                        return (y.length = L), y;
                      };
                    },
                    7004: function (t, n, r) {
                      var e = r(3859);
                      t.exports = e;
                    },
                    7006: function (t, n, r) {
                      var e = r(9036),
                        o = r(182);
                      t.exports = function (t, n, r) {
                        try {
                          return e(o(Object.getOwnPropertyDescriptor(t, n)[r]));
                        } catch (e) {}
                      };
                    },
                    7007: function (t, n, r) {
                      var e = r(7131);
                      t.exports = !e(function () {
                        function e() {}
                        return (
                          (e.prototype.constructor = null),
                          Object.getPrototypeOf(new e()) !== e.prototype
                        );
                      });
                    },
                    7013: function (t, n, r) {
                      var e = r(3057),
                        o = r(182),
                        a = r(8347),
                        i = r(4003),
                        l = r(6399),
                        s = TypeError;
                      t.exports = function (t, n) {
                        var r = arguments.length < 2 ? l(t) : n;
                        if (o(r)) return a(e(r, t));
                        throw s(i(t) + " is not iterable");
                      };
                    },
                    7019: function (t, n, r) {
                      var e = r(1938),
                        o = r(4581).includes,
                        a = r(7131),
                        i = r(6065);
                      e(
                        {
                          target: "Array",
                          proto: !0,
                          forced: a(function () {
                            return !Array(1).includes();
                          }),
                        },
                        {
                          includes: function (t) {
                            return o(
                              this,
                              t,
                              arguments.length > 1 ? arguments[1] : void 0
                            );
                          },
                        }
                      ),
                        i("includes");
                    },
                    7023: function (n) {
                      var e = G(t) == "object" && t.all,
                        r = e === void 0 && e !== void 0;
                      n.exports = { all: e, IS_HTMLDDA: r };
                    },
                    7078: function (t, n, r) {
                      var e = r(7481);
                      t.exports = e;
                    },
                    7102: function (t, n, r) {
                      var e = r(2373).IteratorPrototype,
                        o = r(3628),
                        a = r(3768),
                        i = r(5051),
                        l = r(1113),
                        s = function () {
                          return this;
                        };
                      t.exports = function (t, n, r, u) {
                        var c = n + " Iterator";
                        return (
                          (t.prototype = o(e, { next: a(+!u, r) })),
                          i(t, c, !1, !0),
                          (l[c] = s),
                          t
                        );
                      };
                    },
                    7104: function (t, n, r) {
                      var e = {};
                      (e[r(6615)("toStringTag")] = "z"),
                        (t.exports = String(e) === "[object z]");
                    },
                    7131: function (t) {
                      t.exports = function (e) {
                        try {
                          return !!e();
                        } catch (e) {
                          return !0;
                        }
                      };
                    },
                    7235: function (t, n, r) {
                      var e = r(6312),
                        o = r(7131),
                        a = r(5391).String;
                      t.exports =
                        !!Object.getOwnPropertySymbols &&
                        !o(function () {
                          var t = Symbol("symbol detection");
                          return (
                            !a(t) ||
                            !(Object(t) instanceof Symbol) ||
                            (!(typeof Symbol != "function" || Symbol.sham) &&
                              e &&
                              e < 41)
                          );
                        });
                    },
                    7244: function (t, n, r) {
                      var e = r(5391),
                        o = r(244);
                      t.exports = o(e.process) === "process";
                    },
                    7288: function (t, n, r) {
                      var e = r(6615)("match");
                      t.exports = function (t) {
                        var n = /./;
                        try {
                          "/./"[t](n);
                        } catch (r) {
                          try {
                            return (n[e] = !1), "/./"[t](n);
                          } catch (e) {}
                        }
                        return !1;
                      };
                    },
                    7452: function (t, n, r) {
                      r(1306);
                      var e = r(8843);
                      t.exports = e("Array", "map");
                    },
                    7481: function (t, n, r) {
                      var e = r(7888);
                      t.exports = e;
                    },
                    7632: function (t, n, r) {
                      var e = r(235).charAt,
                        o = r(7803),
                        a = r(9257),
                        i = r(6188),
                        l = r(789),
                        s = "String Iterator",
                        u = a.set,
                        c = a.getterFor(s);
                      i(
                        String,
                        "String",
                        function (e) {
                          u(this, { type: s, string: o(e), index: 0 });
                        },
                        function () {
                          var t,
                            n = c(this),
                            r = n.string,
                            o = n.index;
                          return o >= r.length
                            ? l(void 0, !0)
                            : ((t = e(r, o)), (n.index += t.length), l(t, !1));
                        }
                      );
                    },
                    7675: function (t) {
                      t.exports = {};
                    },
                    7765: function (t, n, r) {
                      var e = r(1938),
                        o = r(2217).find,
                        a = r(6065),
                        i = "find",
                        l = !0;
                      i in [] &&
                        Array(1)[i](function () {
                          l = !1;
                        }),
                        e(
                          { target: "Array", proto: !0, forced: l },
                          {
                            find: function (t) {
                              return o(
                                this,
                                t,
                                arguments.length > 1 ? arguments[1] : void 0
                              );
                            },
                          }
                        ),
                        a(i);
                    },
                    7779: function (t) {
                      function e(t, n) {
                        for (var r = t.length, o = 0; r--; ) {
                          var a = t[o++];
                          Array.isArray(a) ? e(a, n) : n.push(a);
                        }
                      }
                      t.exports = function (t) {
                        var n = [];
                        return e(t, n), n;
                      };
                    },
                    7803: function (t, n, r) {
                      var e = r(5663),
                        o = String;
                      t.exports = function (t) {
                        if (e(t) === "Symbol")
                          throw TypeError(
                            "Cannot convert a Symbol value to a string"
                          );
                        return o(t);
                      };
                    },
                    7827: function (t, n, r) {
                      var e = r(7675),
                        o = r(5391),
                        a = r(2073),
                        i = function (t) {
                          return a(t) ? t : void 0;
                        };
                      t.exports = function (t, n) {
                        return arguments.length < 2
                          ? i(e[t]) || i(o[t])
                          : (e[t] && e[t][n]) || (o[t] && o[t][n]);
                      };
                    },
                    7888: function (t, n, r) {
                      r(7632), r(6206);
                      var e = r(7675);
                      t.exports = e.Array.from;
                    },
                    7959: function (t, n, r) {
                      var e = r(3057),
                        o = r(8347),
                        a = r(3514);
                      t.exports = function (t, n, r) {
                        var i, l;
                        o(t);
                        try {
                          if (!(i = a(t, "return"))) {
                            if (n === "throw") throw r;
                            return r;
                          }
                          i = e(i, t);
                        } catch (e) {
                          (l = !0), (i = e);
                        }
                        if (n === "throw") throw r;
                        if (l) throw i;
                        return o(i), r;
                      };
                    },
                    7980: function (t, n, r) {
                      var e = r(9036),
                        o = 0,
                        a = Math.random(),
                        i = e((1).toString);
                      t.exports = function (e) {
                        return (
                          "Symbol(" +
                          (e === void 0 ? "" : e) +
                          ")_" +
                          i(++o + a, 36)
                        );
                      };
                    },
                    7981: function (t, n, r) {
                      var e = r(9012);
                      t.exports = e;
                    },
                    8132: function (t, n, r) {
                      var e = r(1938),
                        o = r(266).left,
                        a = r(538),
                        i = r(6312);
                      e(
                        {
                          target: "Array",
                          proto: !0,
                          forced:
                            (!r(7244) && i > 79 && i < 83) || !a("reduce"),
                        },
                        {
                          reduce: function (t) {
                            var e = arguments.length;
                            return o(this, t, e, e > 1 ? arguments[1] : void 0);
                          },
                        }
                      );
                    },
                    8224: function (t, n, r) {
                      var e = r(6615)("iterator"),
                        o = !1;
                      try {
                        var a = 0,
                          i = {
                            next: function () {
                              return { done: !!a++ };
                            },
                            return: function () {
                              o = !0;
                            },
                          };
                        (i[e] = function () {
                          return this;
                        }),
                          Array.from(i, function () {
                            throw 2;
                          });
                      } catch (e) {}
                      t.exports = function (t, n) {
                        try {
                          if (!n && !o) return !1;
                        } catch (e) {
                          return !1;
                        }
                        var r = !1;
                        try {
                          var a = {};
                          (a[e] = function () {
                            return {
                              next: function () {
                                return { done: (r = !0) };
                              },
                            };
                          }),
                            t(a);
                        } catch (e) {}
                        return r;
                      };
                    },
                    8327: function (t, n, r) {
                      var e = r(7078);
                      t.exports = e;
                    },
                    8347: function (t, n, r) {
                      var e = r(5774),
                        o = String,
                        a = TypeError;
                      t.exports = function (t) {
                        if (e(t)) return t;
                        throw a(o(t) + " is not an object");
                      };
                    },
                    8471: function (t, n, r) {
                      var e = r(5560),
                        o = r(6381),
                        a = r(3768);
                      t.exports = e
                        ? function (e, t, n) {
                            return o.f(e, t, a(1, n));
                          }
                        : function (e, t, n) {
                            return (e[t] = n), e;
                          };
                    },
                    8630: function (t, n, r) {
                      var e = r(6759),
                        o = Math.max,
                        a = Math.min;
                      t.exports = function (t, n) {
                        var r = e(t);
                        return r < 0 ? o(r + n, 0) : a(r, n);
                      };
                    },
                    8698: function (t, n, r) {
                      var e = r(5391),
                        o = r(2073),
                        a = e.WeakMap;
                      t.exports = o(a) && /native code/.test(String(a));
                    },
                    8724: function (t, n, r) {
                      var e = r(5141),
                        o = r(6381),
                        a = r(3768);
                      t.exports = function (t, n, r) {
                        var i = e(n);
                        i in t ? o.f(t, i, a(0, r)) : (t[i] = r);
                      };
                    },
                    8760: function (t, n, r) {
                      var e = r(5837);
                      t.exports = e;
                    },
                    8843: function (t, n, r) {
                      var e = r(7827);
                      t.exports = e;
                    },
                    8890: function (t, n, r) {
                      var e = r(6153),
                        o = TypeError;
                      t.exports = function (t) {
                        if (e(t)) throw o("Can't call method on " + t);
                        return t;
                      };
                    },
                    8934: function (t, n, r) {
                      var e = r(2073),
                        o = String,
                        a = TypeError;
                      t.exports = function (t) {
                        if (G(t) == "object" || e(t)) return t;
                        throw a("Can't set " + o(t) + " as a prototype");
                      };
                    },
                    9e3: function (t, n, r) {
                      var e = r(244),
                        o = r(9036);
                      t.exports = function (t) {
                        if (e(t) === "Function") return o(t);
                      };
                    },
                    9012: function (t, n, r) {
                      r(2780);
                      var e = r(8843);
                      t.exports = e("String", "startsWith");
                    },
                    9036: function (t, n, r) {
                      var e = r(5164),
                        o = Function.prototype,
                        a = o.call,
                        i = e && o.bind.bind(a, a);
                      t.exports = e
                        ? i
                        : function (e) {
                            return function () {
                              return a.apply(e, arguments);
                            };
                          };
                    },
                    9077: function (t, n, r) {
                      var e = r(1972),
                        o = r(6553),
                        a = r(5774),
                        i = r(6615)("species"),
                        l = Array;
                      t.exports = function (t) {
                        var n;
                        return (
                          e(t) &&
                            ((n = t.constructor),
                            ((o(n) && (n === l || e(n.prototype))) ||
                              (a(n) && (n = n[i]) === null)) &&
                              (n = void 0)),
                          n === void 0 ? l : n
                        );
                      };
                    },
                    9157: function (t, n, r) {
                      var e = r(5560),
                        o = r(2506),
                        a = r(6381),
                        i = r(8347),
                        l = r(9441),
                        s = r(5556);
                      n.f =
                        e && !o
                          ? Object.defineProperties
                          : function (e, t) {
                              i(e);
                              for (
                                var n, r = l(t), o = s(t), u = o.length, c = 0;
                                u > c;

                              )
                                a.f(e, (n = o[c++]), r[n]);
                              return e;
                            };
                    },
                    9257: function (t, n, r) {
                      var e,
                        o,
                        a,
                        i = r(8698),
                        l = r(5391),
                        s = r(5774),
                        u = r(8471),
                        c = r(4373),
                        d = r(4993),
                        m = r(651),
                        p = r(6145),
                        _ = "Object already initialized",
                        f = l.TypeError,
                        g = l.WeakMap;
                      if (i || d.state) {
                        var h = d.state || (d.state = new g());
                        (h.get = h.get),
                          (h.has = h.has),
                          (h.set = h.set),
                          (e = function (t, n) {
                            if (h.has(t)) throw f(_);
                            return (n.facade = t), h.set(t, n), n;
                          }),
                          (o = function (t) {
                            return h.get(t) || {};
                          }),
                          (a = function (t) {
                            return h.has(t);
                          });
                      } else {
                        var y = m("state");
                        (p[y] = !0),
                          (e = function (t, n) {
                            if (c(t, y)) throw f(_);
                            return (n.facade = t), u(t, y, n), n;
                          }),
                          (o = function (t) {
                            return c(t, y) ? t[y] : {};
                          }),
                          (a = function (t) {
                            return c(t, y);
                          });
                      }
                      t.exports = {
                        set: e,
                        get: o,
                        has: a,
                        enforce: function (n) {
                          return a(n) ? o(n) : e(n, {});
                        },
                        getterFor: function (t) {
                          return function (e) {
                            var n;
                            if (!s(e) || (n = o(e)).type !== t)
                              throw f(
                                "Incompatible receiver, " + t + " required"
                              );
                            return n;
                          };
                        },
                      };
                    },
                    9417: function (t, n, r) {
                      var e = r(7827);
                      t.exports = e("document", "documentElement");
                    },
                    9441: function (t, n, r) {
                      var e = r(6731),
                        o = r(8890);
                      t.exports = function (t) {
                        return e(o(t));
                      };
                    },
                    9830: function (t, n, r) {
                      var e = r(7981);
                      t.exports = e;
                    },
                  },
                  r = {};
                function a(e) {
                  var t = r[e];
                  if (t !== void 0) return t.exports;
                  var o = (r[e] = { exports: {} });
                  return n[e].call(o.exports, o, o.exports, a), o.exports;
                }
                (a.n = function (e) {
                  var t =
                    e && e.__esModule
                      ? function () {
                          return e.default;
                        }
                      : function () {
                          return e;
                        };
                  return a.d(t, { a: t }), t;
                }),
                  (a.d = function (e, t) {
                    for (var n in t)
                      a.o(t, n) &&
                        !a.o(e, n) &&
                        Object.defineProperty(e, n, {
                          enumerable: !0,
                          get: t[n],
                        });
                  }),
                  (a.g = (function () {
                    if (
                      (typeof globalThis == "undefined"
                        ? "undefined"
                        : G(globalThis)) == "object"
                    )
                      return globalThis;
                    try {
                      return this || new Function("return this")();
                    } catch (t) {
                      if (G(e) == "object") return e;
                    }
                  })()),
                  (a.o = function (e, t) {
                    return Object.prototype.hasOwnProperty.call(e, t);
                  }),
                  (a.r = function (e) {
                    typeof Symbol != "undefined" &&
                      (typeof Symbol != "function" || Symbol.toStringTag) &&
                      Object.defineProperty(
                        e,
                        typeof Symbol == "function"
                          ? Symbol.toStringTag
                          : "@@toStringTag",
                        { value: "Module" }
                      ),
                      Object.defineProperty(e, "__esModule", { value: !0 });
                  });
                var i = {};
                a.r(i),
                  a.d(i, {
                    MicrodataExtractionMethods: function () {
                      return sa;
                    },
                    SignalsESTCustomData: function () {
                      return On;
                    },
                    SignalsESTRuleEngine: function () {
                      return bn;
                    },
                    getJsonLDForExtractors: function () {
                      return Me;
                    },
                    getParameterExtractorFromGraphPayload: function () {
                      return we;
                    },
                    inferredEventsSharedUtils: function () {
                      return la;
                    },
                    signalsConvertNodeToHTMLElement: function () {
                      return I;
                    },
                    signalsExtractButtonFeatures: function () {
                      return Bn;
                    },
                    signalsExtractForm: function () {
                      return Un;
                    },
                    signalsExtractPageFeatures: function () {
                      return Wn;
                    },
                    signalsGetButtonActionType: function () {
                      return Kn;
                    },
                    signalsGetButtonImageUrl: function () {
                      return Qe;
                    },
                    signalsGetTextFromElement: function () {
                      return u;
                    },
                    signalsGetTextOrValueFromElement: function () {
                      return Ue;
                    },
                    signalsGetTruncatedButtonText: function () {
                      return Vn;
                    },
                    signalsGetValueFromHTMLElement: function () {
                      return d;
                    },
                    signalsGetWrappingButton: function () {
                      return Xn;
                    },
                    signalsIsIWLElement: function () {
                      return Hn;
                    },
                    signalsIsSaneButton: function () {
                      return ot;
                    },
                    unicodeSafeTruncate: function () {
                      return Be;
                    },
                  });
                var l = {};
                a.r(l),
                  a.d(l, {
                    BUTTON_SELECTORS: function () {
                      return He;
                    },
                    BUTTON_SELECTOR_FORM_BLACKLIST: function () {
                      return ze;
                    },
                    BUTTON_SELECTOR_SEPARATOR: function () {
                      return Ve;
                    },
                    EXPLICIT_BUTTON_SELECTORS: function () {
                      return Ke;
                    },
                    EXTENDED_BUTTON_SELECTORS: function () {
                      return je;
                    },
                    LINK_TARGET_SELECTORS: function () {
                      return Ge;
                    },
                  });
                var s = {};
                function u(e) {
                  if (e == null) return null;
                  if (e.innerText != null && e.innerText.length !== 0)
                    return e.innerText;
                  var t = e.text;
                  return t != null && typeof t == "string" && t.length !== 0
                    ? t
                    : e.textContent != null && e.textContent.length > 0
                    ? e.textContent
                    : null;
                }
                a.r(s),
                  a.d(s, {
                    cleanDescription: function () {
                      return Co;
                    },
                    decodeHtmlEntities: function () {
                      return ho;
                    },
                    deduplicateProductContents: function () {
                      return ra;
                    },
                    extractJsonLd: function () {
                      return No;
                    },
                    extractMetaTagData: function () {
                      return Yo;
                    },
                    extractOpenGraph: function () {
                      return Ko;
                    },
                    extractRDFa: function () {
                      return ia;
                    },
                    extractSchemaOrg: function () {
                      return Do;
                    },
                    jsonRepair: function () {
                      return aa;
                    },
                    mergeProductMetadata: function () {
                      return So;
                    },
                    normalizeWhitespace: function () {
                      return yo;
                    },
                    stripHtmlTags: function () {
                      return go;
                    },
                    stripJsonComments: function () {
                      return oa;
                    },
                  });
                var c = 500;
                function d(e) {
                  var t = e.tagName.toLowerCase(),
                    n = void 0;
                  switch (t) {
                    case "meta":
                      n = e.getAttribute("content");
                      break;
                    case "audio":
                    case "embed":
                    case "iframe":
                    case "img":
                    case "source":
                    case "track":
                    case "video":
                      n = e.getAttribute("src");
                      break;
                    case "a":
                    case "area":
                    case "link":
                      n = e.getAttribute("href");
                      break;
                    case "object":
                      n = e.getAttribute("data");
                      break;
                    case "data":
                    case "meter":
                      n = e.getAttribute("value");
                      break;
                    case "time":
                      n = e.getAttribute("datetime");
                      break;
                    default:
                      n = u(e) || "";
                  }
                  return (
                    t === "span" &&
                      (n == null || (typeof n == "string" && n === "")) &&
                      (n = e.getAttribute("content")),
                    typeof n == "string" ? n.substr(0, c) : ""
                  );
                }
                var m = [
                    "Order",
                    "AggregateOffer",
                    "CreativeWork",
                    "Event",
                    "MenuItem",
                    "Product",
                    "Service",
                    "Trip",
                    "ActionAccessSpecification",
                    "ConsumeAction",
                    "MediaSubscription",
                    "Organization",
                    "Person",
                  ],
                  p = a(4909),
                  _ = a.n(p),
                  f = a(6408),
                  g = a.n(f),
                  h = a(5109),
                  y = a.n(h),
                  C = a(8327),
                  b = a.n(C),
                  v = a(3550),
                  S = a.n(v),
                  R = a(4817),
                  L = a.n(R),
                  E = function (n) {
                    for (
                      var e = L()(m, function (e) {
                          return '[vocab$="'
                            .concat("http://schema.org/", '"][typeof$="')
                            .concat(e, '"]');
                        }).join(", "),
                        r = [],
                        o = b()(t.querySelectorAll(e)),
                        a = [];
                      o.length > 0;

                    ) {
                      var i = o.pop();
                      if (!S()(r, i)) {
                        var l = { "@context": "http://schema.org" };
                        a.push({ htmlElement: i, jsonLD: l });
                        for (
                          var s = [{ element: i, workingNode: l }];
                          s.length;

                        ) {
                          var u = s.pop(),
                            c = u.element,
                            p = u.workingNode,
                            f = g()(c.getAttribute("typeof"));
                          p["@type"] = f;
                          for (
                            var h = b()(
                              c.querySelectorAll("[property]")
                            ).reverse();
                            h.length;

                          ) {
                            var C = h.pop();
                            if (!S()(r, C)) {
                              r.push(C);
                              var v = g()(C.getAttribute("property"));
                              if (C.hasAttribute("typeof")) {
                                var R = {};
                                (p[v] = R),
                                  s.push({ element: c, workingNode: p }),
                                  s.push({ element: C, workingNode: R });
                                break;
                              }
                              p[v] = d(C);
                            }
                          }
                        }
                      }
                    }
                    return y()(a, function (e) {
                      return _()(e.htmlElement, n);
                    });
                  };
                function k(e) {
                  return (
                    (k =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator"
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    k(e)
                  );
                }
                function I(e) {
                  return (
                    (typeof HTMLElement == "undefined"
                      ? "undefined"
                      : k(HTMLElement)) === "object"
                      ? e instanceof HTMLElement ||
                        (e != null &&
                          e.nodeType === 1 &&
                          typeof e.nodeName == "string")
                      : e != null &&
                        k(e) === "object" &&
                        e !== null &&
                        e.nodeType === 1 &&
                        typeof e.nodeName == "string"
                  )
                    ? e
                    : null;
                }
                var T = /^\s*:scope/gi,
                  D = function (t, n) {
                    if (n[n.length - 1] === ">") return [];
                    var e = n[0] === ">";
                    if ((D.CAN_USE_SCOPE || !n.match(T)) && !e)
                      try {
                        return t.querySelectorAll(n);
                      } catch (e) {
                        return [];
                      }
                    var r = n;
                    e && (r = ":scope ".concat(n));
                    var o = !1;
                    t.id ||
                      ((t.id = "__fb_scoped_query_selector_" + Date.now()),
                      (o = !0));
                    try {
                      var a = t.querySelectorAll(r.replace(T, "#" + t.id));
                      return o && (t.id = ""), a;
                    } catch (e) {
                      return o && (t.id = ""), [];
                    }
                  };
                D.CAN_USE_SCOPE = !0;
                var x = t.createElement("div");
                try {
                  x.querySelectorAll(":scope *");
                } catch (e) {
                  D.CAN_USE_SCOPE = !1;
                }
                var $ = D,
                  P = a(7779),
                  N = a.n(P),
                  M = a(1001),
                  w = a.n(M),
                  A = a(5023),
                  F = a.n(A);
                function O(e) {
                  return (
                    (function (e) {
                      if (Array.isArray(e)) return q(e);
                    })(e) ||
                    (function (e) {
                      if (
                        (typeof Symbol != "undefined" &&
                          e[
                            typeof Symbol == "function"
                              ? Symbol.iterator
                              : "@@iterator"
                          ] != null) ||
                        e["@@iterator"] != null
                      )
                        return Array.from(e);
                    })(e) ||
                    W(e) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                      );
                    })()
                  );
                }
                function B(e, t) {
                  return (
                    (function (e) {
                      if (Array.isArray(e)) return e;
                    })(e) ||
                    (function (e, t) {
                      var n =
                        e == null
                          ? null
                          : (typeof Symbol != "undefined" &&
                              e[
                                typeof Symbol == "function"
                                  ? Symbol.iterator
                                  : "@@iterator"
                              ]) ||
                            e["@@iterator"];
                      if (n != null) {
                        var r,
                          o,
                          a,
                          i,
                          l = [],
                          s = !0,
                          u = !1;
                        try {
                          if (((a = (n = n.call(e)).next), t === 0)) {
                            if (Object(n) !== n) return;
                            s = !1;
                          } else
                            for (
                              ;
                              !(s = (r = a.call(n)).done) &&
                              (l.push(r.value), l.length !== t);
                              s = !0
                            );
                        } catch (e) {
                          (u = !0), (o = e);
                        } finally {
                          try {
                            if (
                              !s &&
                              n.return != null &&
                              ((i = n.return()), Object(i) !== i)
                            )
                              return;
                          } finally {
                            if (u) throw o;
                          }
                        }
                        return l;
                      }
                    })(e, t) ||
                    W(e, t) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                      );
                    })()
                  );
                }
                function W(e, t) {
                  if (e) {
                    if (typeof e == "string") return q(e, t);
                    var n = {}.toString.call(e).slice(8, -1);
                    return (
                      n === "Object" &&
                        e.constructor &&
                        (n = e.constructor.name),
                      n === "Map" || n === "Set"
                        ? Array.from(e)
                        : n === "Arguments" ||
                          /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
                        ? q(e, t)
                        : void 0
                    );
                  }
                }
                function q(e, t) {
                  (t == null || t > e.length) && (t = e.length);
                  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                  return r;
                }
                var U = "children(",
                  V = "closest(";
                function H(e, t) {
                  return z(
                    e,
                    y()(
                      L()(
                        t.split(/((?:closest|children)\([^)]+\))/),
                        function (e) {
                          return e.trim();
                        }
                      ),
                      Boolean
                    )
                  );
                }
                function z(e, t) {
                  var n = function (t, n) {
                      return n.substring(t.length, n.length - 1).trim();
                    },
                    r = L()(t, function (e) {
                      return F()(e, V)
                        ? { selector: n(V, e), type: "closest" }
                        : F()(e, U)
                        ? { selector: n(U, e), type: "children" }
                        : { selector: e, type: "standard" };
                    }),
                    o = w()(
                      r,
                      function (e, t) {
                        if (t.type !== "standard") return [].concat(O(e), [t]);
                        var n = e[e.length - 1];
                        return n && n.type === "standard"
                          ? ((n.selector += " " + t.selector), e)
                          : [].concat(O(e), [t]);
                      },
                      []
                    );
                  return w()(
                    o,
                    function (e, t) {
                      return y()(
                        N()(
                          L()(e, function (e) {
                            return j(e, t);
                          })
                        ),
                        Boolean
                      );
                    },
                    [e]
                  );
                }
                var j = function (t, n) {
                  var e = n.selector;
                  switch (n.type) {
                    case "children":
                      if (t == null) return [];
                      var r = e.split(",");
                      if (r.length < 2)
                        throw new Error("Invalid selector format: ".concat(e));
                      var o = B(r, 2),
                        a = o[0],
                        i = o[1],
                        l = b()(
                          y()(b()(t.childNodes), function (e) {
                            return I(e) != null && e.matches(i);
                          })
                        ),
                        s = parseInt(a, 0);
                      return s < 0 || s >= l.length ? [] : [l[s]];
                    case "closest":
                      return t.parentNode ? [t.parentNode.closest(e)] : [];
                    default:
                      return b()($(t, e));
                  }
                };
                if (
                  (Element.prototype.matches ||
                    (Element.prototype.matches =
                      Element.prototype.msMatchesSelector ||
                      Element.prototype.webkitMatchesSelector),
                  !Element.prototype.closest)
                ) {
                  var K = t.documentElement;
                  Element.prototype.closest = function (e) {
                    var t = this;
                    if (!K.contains(t)) return null;
                    do {
                      if (t.matches(e)) return t;
                      t = t.parentElement || t.parentNode;
                    } while (t !== null && t.nodeType === 1);
                    return null;
                  };
                }
                var Q = [
                  "og",
                  "product",
                  "music",
                  "video",
                  "article",
                  "book",
                  "profile",
                  "website",
                  "twitter",
                ];
                function X(e) {
                  return (
                    (X =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator"
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    X(e)
                  );
                }
                function Y(e, t) {
                  var n = Object.keys(e);
                  if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t &&
                      (r = r.filter(function (t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                      })),
                      n.push.apply(n, r);
                  }
                  return n;
                }
                function J(e) {
                  for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t] != null ? arguments[t] : {};
                    t % 2
                      ? Y(Object(n), !0).forEach(function (t) {
                          Z(e, t, n[t]);
                        })
                      : Object.getOwnPropertyDescriptors
                      ? Object.defineProperties(
                          e,
                          Object.getOwnPropertyDescriptors(n)
                        )
                      : Y(Object(n)).forEach(function (t) {
                          Object.defineProperty(
                            e,
                            t,
                            Object.getOwnPropertyDescriptor(n, t)
                          );
                        });
                  }
                  return e;
                }
                function Z(e, t, n) {
                  return (
                    (t = (function (e) {
                      var t = (function (e, t) {
                        if (X(e) != "object" || !e) return e;
                        var n =
                          e[
                            typeof Symbol == "function"
                              ? Symbol.toPrimitive
                              : "@@toPrimitive"
                          ];
                        if (n !== void 0) {
                          var r = n.call(e, t || "default");
                          if (X(r) != "object") return r;
                          throw new TypeError(
                            "@@toPrimitive must return a primitive value."
                          );
                        }
                        return (t === "string" ? String : Number)(e);
                      })(e, "string");
                      return X(t) == "symbol" ? t : t + "";
                    })(t)) in e
                      ? Object.defineProperty(e, t, {
                          value: n,
                          enumerable: !0,
                          configurable: !0,
                          writable: !0,
                        })
                      : (e[t] = n),
                    e
                  );
                }
                var ee = function () {
                    var e = w()(
                      y()(
                        L()(
                          b()(t.querySelectorAll("meta[property]")),
                          function (e) {
                            var t = e.getAttribute("property"),
                              n = e.getAttribute("content");
                            return typeof t == "string" &&
                              t.indexOf(":") !== -1 &&
                              typeof n == "string" &&
                              S()(Q, t.split(":")[0])
                              ? { key: t, value: n.substr(0, c) }
                              : null;
                          }
                        ),
                        Boolean
                      ),
                      function (e, t) {
                        return J(
                          J({}, e),
                          {},
                          Z({}, t.key, e[t.key] || t.value)
                        );
                      },
                      {}
                    );
                    return e["og:type"] !== "product.item"
                      ? null
                      : {
                          "@context": "http://schema.org",
                          "@type": "Product",
                          offers: {
                            price: e["product:price:amount"],
                            priceCurrency: e["product:price:currency"],
                          },
                          productID: e["product:retailer_item_id"],
                        };
                  },
                  te = a(8760),
                  ne = a.n(te);
                function re(e) {
                  return (
                    (re =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator"
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    re(e)
                  );
                }
                function oe(e, t) {
                  var n = Object.keys(e);
                  if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t &&
                      (r = r.filter(function (t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                      })),
                      n.push.apply(n, r);
                  }
                  return n;
                }
                function ae(e) {
                  for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t] != null ? arguments[t] : {};
                    t % 2
                      ? oe(Object(n), !0).forEach(function (t) {
                          ie(e, t, n[t]);
                        })
                      : Object.getOwnPropertyDescriptors
                      ? Object.defineProperties(
                          e,
                          Object.getOwnPropertyDescriptors(n)
                        )
                      : oe(Object(n)).forEach(function (t) {
                          Object.defineProperty(
                            e,
                            t,
                            Object.getOwnPropertyDescriptor(n, t)
                          );
                        });
                  }
                  return e;
                }
                function ie(e, t, n) {
                  return (
                    (t = se(t)) in e
                      ? Object.defineProperty(e, t, {
                          value: n,
                          enumerable: !0,
                          configurable: !0,
                          writable: !0,
                        })
                      : (e[t] = n),
                    e
                  );
                }
                function le(e, t) {
                  for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    (r.enumerable = r.enumerable || !1),
                      (r.configurable = !0),
                      "value" in r && (r.writable = !0),
                      Object.defineProperty(e, se(r.key), r);
                  }
                }
                function se(e) {
                  var t = (function (e, t) {
                    if (re(e) != "object" || !e) return e;
                    var n =
                      e[
                        typeof Symbol == "function"
                          ? Symbol.toPrimitive
                          : "@@toPrimitive"
                      ];
                    if (n !== void 0) {
                      var r = n.call(e, t || "default");
                      if (re(r) != "object") return r;
                      throw new TypeError(
                        "@@toPrimitive must return a primitive value."
                      );
                    }
                    return (t === "string" ? String : Number)(e);
                  })(e, "string");
                  return re(t) == "symbol" ? t : t + "";
                }
                var ue = (function () {
                    return (
                      (e = function e(n) {
                        (function (e, t) {
                          if (!(e instanceof t))
                            throw new TypeError(
                              "Cannot call a class as a function"
                            );
                        })(this, e),
                          (this._anchorElement = t.createElement("a")),
                          (this._anchorElement.href = n);
                      }),
                      (n = [
                        {
                          key: "hash",
                          get: function () {
                            return this._anchorElement.hash;
                          },
                        },
                        {
                          key: "host",
                          get: function () {
                            return this._anchorElement.host;
                          },
                        },
                        {
                          key: "hostname",
                          get: function () {
                            return this._anchorElement.hostname;
                          },
                        },
                        {
                          key: "pathname",
                          get: function () {
                            return this._anchorElement.pathname.replace(
                              /(^\/?)/,
                              "/"
                            );
                          },
                        },
                        {
                          key: "port",
                          get: function () {
                            return this._anchorElement.port;
                          },
                        },
                        {
                          key: "protocol",
                          get: function () {
                            return this._anchorElement.protocol;
                          },
                        },
                        {
                          key: "searchParams",
                          get: function () {
                            var e = this;
                            return {
                              get: function (n) {
                                if (e._parsedQuery != null)
                                  return e._parsedQuery[n] || null;
                                var t = e._anchorElement.search;
                                if (t === "" || t == null)
                                  return (e._parsedQuery = {}), null;
                                var r = t[0] === "?" ? t.substring(1) : t;
                                return (
                                  (e._parsedQuery = w()(
                                    r.split("&"),
                                    function (e, t) {
                                      var n = t.split("=");
                                      return n == null || n.length !== 2
                                        ? e
                                        : ae(
                                            ae({}, e),
                                            {},
                                            ie(
                                              {},
                                              decodeURIComponent(n[0]),
                                              decodeURIComponent(n[1])
                                            )
                                          );
                                    },
                                    {}
                                  )),
                                  e._parsedQuery[n] || null
                                );
                              },
                            };
                          },
                        },
                        {
                          key: "toString",
                          value: function () {
                            return this._anchorElement.href;
                          },
                        },
                        {
                          key: "toJSON",
                          value: function () {
                            return this._anchorElement.href;
                          },
                        },
                      ]) && le(e.prototype, n),
                      r && le(e, r),
                      Object.defineProperty(e, "prototype", { writable: !1 }),
                      e
                    );
                    var e, n, r;
                  })(),
                  ce = "PATH",
                  de = "QUERY_STRING";
                function me(e) {
                  return (
                    (function (e) {
                      if (Array.isArray(e)) return _e(e);
                    })(e) ||
                    (function (e) {
                      if (
                        (typeof Symbol != "undefined" &&
                          e[
                            typeof Symbol == "function"
                              ? Symbol.iterator
                              : "@@iterator"
                          ] != null) ||
                        e["@@iterator"] != null
                      )
                        return Array.from(e);
                    })(e) ||
                    pe(e) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                      );
                    })()
                  );
                }
                function pe(e, t) {
                  if (e) {
                    if (typeof e == "string") return _e(e, t);
                    var n = {}.toString.call(e).slice(8, -1);
                    return (
                      n === "Object" &&
                        e.constructor &&
                        (n = e.constructor.name),
                      n === "Map" || n === "Set"
                        ? Array.from(e)
                        : n === "Arguments" ||
                          /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
                        ? _e(e, t)
                        : void 0
                    );
                  }
                }
                function _e(e, t) {
                  (t == null || t > e.length) && (t = e.length);
                  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                  return r;
                }
                function fe(e, t) {
                  var n = g()(I(e)).className,
                    r = g()(I(t)).className,
                    o = n.split(" "),
                    a = r.split(" ");
                  return o
                    .filter(function (e) {
                      return a.includes(e);
                    })
                    .toString();
                }
                var ge = 0,
                  he = 1,
                  ye = 2;
                function Ce(e, t) {
                  if (
                    (e && !t) ||
                    (!e && t) ||
                    e === void 0 ||
                    t === void 0 ||
                    e.nodeType !== t.nodeType ||
                    e.nodeName !== t.nodeName
                  )
                    return ge;
                  var n = I(e),
                    r = I(t);
                  if ((n && !r) || (!n && r)) return ge;
                  if (n && r) {
                    if (n.tagName !== r.tagName) return ge;
                    if (n.className === r.className) return he;
                  }
                  return ye;
                }
                function be(e, t, n, r) {
                  var o = Ce(e, r.node);
                  return o === ge
                    ? o
                    : n > 0 && t !== r.index
                    ? ge
                    : o === 1
                    ? he
                    : r.relativeClass.length === 0
                    ? ge
                    : (fe(e, r.node), r.relativeClass, he);
                }
                function ve(e, t, n, r) {
                  if (r === n.length - 1) {
                    if (!be(e, t, r, n[r])) return null;
                    var o = I(e);
                    if (o) return [o];
                  }
                  if (!e || !be(e, t, r, n[r])) return null;
                  for (var a = [], i = e.firstChild, l = 0; i; ) {
                    var s = ve(i, l, n, r + 1);
                    s && a.push.apply(a, me(s)), (i = i.nextSibling), (l += 1);
                  }
                  return a;
                }
                function Se(e, t) {
                  var n,
                    r = [],
                    o = (function (e, t) {
                      var n =
                        (typeof Symbol != "undefined" &&
                          e[
                            typeof Symbol == "function"
                              ? Symbol.iterator
                              : "@@iterator"
                          ]) ||
                        e["@@iterator"];
                      if (!n) {
                        if (
                          Array.isArray(e) ||
                          (n = pe(e)) ||
                          (t && e && typeof e.length == "number")
                        ) {
                          n && (e = n);
                          var r = 0,
                            o = function () {};
                          return {
                            s: o,
                            n: function () {
                              return r >= e.length
                                ? { done: !0 }
                                : { done: !1, value: e[r++] };
                            },
                            e: function (t) {
                              throw t;
                            },
                            f: o,
                          };
                        }
                        throw new TypeError(
                          "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                        );
                      }
                      var a,
                        i = !0,
                        l = !1;
                      return {
                        s: function () {
                          n = n.call(e);
                        },
                        n: function () {
                          var e = n.next();
                          return (i = e.done), e;
                        },
                        e: function (t) {
                          (l = !0), (a = t);
                        },
                        f: function () {
                          try {
                            i || n.return == null || n.return();
                          } finally {
                            if (l) throw a;
                          }
                        },
                      };
                    })(e);
                  try {
                    for (o.s(); !(n = o.n()).done; ) {
                      var a = ve(n.value, 0, t, 0);
                      a && r.push.apply(r, me(a));
                    }
                  } catch (e) {
                    o.e(e);
                  } finally {
                    o.f();
                  }
                  return r;
                }
                function Re(e, t) {
                  var n = (function (e, t) {
                    for (
                      var n = function (t) {
                          var e = t.parentNode;
                          if (!e) return -1;
                          for (var n = e.firstChild, r = 0; n && n !== t; )
                            (n = n.nextSibling), (r += 1);
                          return n === t ? r : -1;
                        },
                        r = e,
                        o = t,
                        a = [],
                        i = [];
                      !r.isSameNode(o);

                    ) {
                      var l = Ce(r, o);
                      if (l === ge) return null;
                      var s = "";
                      if (
                        (l === ye && (s = fe(r, o)).length === 0) ||
                        (a.push({ node: r, relativeClass: s, index: n(r) }),
                        i.push(o),
                        (r = r.parentNode),
                        (o = o.parentNode),
                        !r || !o)
                      )
                        return null;
                    }
                    return r && o && r.isSameNode(o) && a.length > 0
                      ? {
                          parentNode: r,
                          node1Tree: a.reverse(),
                          node2Tree: i.reverse(),
                        }
                      : null;
                  })(e, t);
                  if (!n) return null;
                  var r = (function (e, t, n) {
                    for (var r = [], o = e.firstChild; o; )
                      o.isSameNode(t.node) ||
                        o.isSameNode(n) ||
                        !Ce(t.node, o) ||
                        r.push(o),
                        (o = o.nextSibling);
                    return r;
                  })(n.parentNode, n.node1Tree[0], n.node2Tree[0]);
                  return r && r.length !== 0 ? Se(r, n.node1Tree) : null;
                }
                function Le(e) {
                  return (
                    (Le =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator"
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    Le(e)
                  );
                }
                function Ee(e, t) {
                  return (
                    (function (e) {
                      if (Array.isArray(e)) return e;
                    })(e) ||
                    (function (e, t) {
                      var n =
                        e == null
                          ? null
                          : (typeof Symbol != "undefined" &&
                              e[
                                typeof Symbol == "function"
                                  ? Symbol.iterator
                                  : "@@iterator"
                              ]) ||
                            e["@@iterator"];
                      if (n != null) {
                        var r,
                          o,
                          a,
                          i,
                          l = [],
                          s = !0,
                          u = !1;
                        try {
                          if (((a = (n = n.call(e)).next), t === 0)) {
                            if (Object(n) !== n) return;
                            s = !1;
                          } else
                            for (
                              ;
                              !(s = (r = a.call(n)).done) &&
                              (l.push(r.value), l.length !== t);
                              s = !0
                            );
                        } catch (e) {
                          (u = !0), (o = e);
                        } finally {
                          try {
                            if (
                              !s &&
                              n.return != null &&
                              ((i = n.return()), Object(i) !== i)
                            )
                              return;
                          } finally {
                            if (u) throw o;
                          }
                        }
                        return l;
                      }
                    })(e, t) ||
                    (function (e, t) {
                      if (e) {
                        if (typeof e == "string") return ke(e, t);
                        var n = {}.toString.call(e).slice(8, -1);
                        return (
                          n === "Object" &&
                            e.constructor &&
                            (n = e.constructor.name),
                          n === "Map" || n === "Set"
                            ? Array.from(e)
                            : n === "Arguments" ||
                              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
                            ? ke(e, t)
                            : void 0
                        );
                      }
                    })(e, t) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                      );
                    })()
                  );
                }
                function ke(e, t) {
                  (t == null || t > e.length) && (t = e.length);
                  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                  return r;
                }
                function Ie(e, t) {
                  var n = Object.keys(e);
                  if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t &&
                      (r = r.filter(function (t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                      })),
                      n.push.apply(n, r);
                  }
                  return n;
                }
                function Te(e) {
                  for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t] != null ? arguments[t] : {};
                    t % 2
                      ? Ie(Object(n), !0).forEach(function (t) {
                          De(e, t, n[t]);
                        })
                      : Object.getOwnPropertyDescriptors
                      ? Object.defineProperties(
                          e,
                          Object.getOwnPropertyDescriptors(n)
                        )
                      : Ie(Object(n)).forEach(function (t) {
                          Object.defineProperty(
                            e,
                            t,
                            Object.getOwnPropertyDescriptor(n, t)
                          );
                        });
                  }
                  return e;
                }
                function De(e, t, n) {
                  return (
                    (t = (function (e) {
                      var t = (function (e, t) {
                        if (Le(e) != "object" || !e) return e;
                        var n =
                          e[
                            typeof Symbol == "function"
                              ? Symbol.toPrimitive
                              : "@@toPrimitive"
                          ];
                        if (n !== void 0) {
                          var r = n.call(e, t || "default");
                          if (Le(r) != "object") return r;
                          throw new TypeError(
                            "@@toPrimitive must return a primitive value."
                          );
                        }
                        return (t === "string" ? String : Number)(e);
                      })(e, "string");
                      return Le(t) == "symbol" ? t : t + "";
                    })(t)) in e
                      ? Object.defineProperty(e, t, {
                          value: n,
                          enumerable: !0,
                          configurable: !0,
                          writable: !0,
                        })
                      : (e[t] = n),
                    e
                  );
                }
                var xe = w()(
                    [
                      "CONSTANT_VALUE",
                      "CSS",
                      "URI",
                      "SCHEMA_DOT_ORG",
                      "JSON_LD",
                      "RDFA",
                      "OPEN_GRAPH",
                      "GTM",
                      "META_TAG",
                      "GLOBAL_VARIABLE",
                    ],
                    function (e, t, n) {
                      return Te(Te({}, e), {}, De({}, t, n));
                    },
                    {}
                  ),
                  $e = {
                    "@context": "http://schema.org",
                    "@type": "Product",
                    additionalType: void 0,
                    offers: { price: void 0, priceCurrency: void 0 },
                    order_id: void 0,
                    productID: void 0,
                  },
                  Pe = function (t, n, r) {
                    var e, o, a, i;
                    if (r == null) return t;
                    var l = g()(t.offers);
                    return {
                      "@context": "http://schema.org",
                      "@type": "Product",
                      additionalType:
                        (e = t.additionalType) !== null && e !== void 0
                          ? e
                          : n === "content_type"
                          ? r
                          : void 0,
                      offers: {
                        price:
                          (o = l.price) !== null && o !== void 0
                            ? o
                            : n === "value"
                            ? r
                            : void 0,
                        priceCurrency:
                          (a = l.priceCurrency) !== null && a !== void 0
                            ? a
                            : n === "currency"
                            ? r
                            : void 0,
                      },
                      order_id:
                        t.order_id != null
                          ? t.order_id
                          : n === "order_id"
                          ? r
                          : void 0,
                      productID:
                        (i = t.productID) !== null && i !== void 0
                          ? i
                          : n === "content_ids"
                          ? r
                          : void 0,
                    };
                  };
                function Ne(n, r) {
                  var o = r.sort(function (e, t) {
                    return xe[e.extractorType] > xe[t.extractorType] ? 1 : -1;
                  });
                  return y()(
                    N()(
                      L()(o, function (r) {
                        switch (r.extractorType) {
                          case "SCHEMA_DOT_ORG":
                            return L()(
                              (function (e) {
                                for (
                                  var n = "schema.org/",
                                    r = L()(m, function (e) {
                                      return '[itemtype$="'
                                        .concat(n)
                                        .concat(e, '"]');
                                    }).join(", "),
                                    o = [],
                                    a = b()(t.querySelectorAll(r)),
                                    i = [];
                                  a.length > 0;

                                ) {
                                  var l = a.pop();
                                  if (!S()(o, l)) {
                                    var s = { "@context": "http://schema.org" };
                                    i.push({ htmlElement: l, jsonLD: s });
                                    for (
                                      var u = [{ element: l, workingNode: s }];
                                      u.length;

                                    ) {
                                      var c = u.pop(),
                                        p = c.element,
                                        f = c.workingNode,
                                        h = g()(p.getAttribute("itemtype"));
                                      f["@type"] = h.substr(h.indexOf(n) + 11);
                                      for (
                                        var C = b()(
                                          p.querySelectorAll("[itemprop]")
                                        ).reverse();
                                        C.length;

                                      ) {
                                        var v = C.pop();
                                        if (!S()(o, v)) {
                                          o.push(v);
                                          var R = g()(
                                            v.getAttribute("itemprop")
                                          );
                                          if (v.hasAttribute("itemscope")) {
                                            var E = {};
                                            (f[R] = E),
                                              u.push({
                                                element: p,
                                                workingNode: f,
                                              }),
                                              u.push({
                                                element: v,
                                                workingNode: E,
                                              });
                                            break;
                                          }
                                          f[R] = d(v);
                                        }
                                      }
                                    }
                                  }
                                }
                                return y()(i, function (t) {
                                  return _()(t.htmlElement, e);
                                });
                              })(n),
                              function (e) {
                                return { extractorID: r.id, jsonLD: e.jsonLD };
                              }
                            );
                          case "RDFA":
                            return L()(E(n), function (e) {
                              return { extractorID: r.id, jsonLD: e.jsonLD };
                            });
                          case "OPEN_GRAPH":
                            return { extractorID: r.id, jsonLD: ee() };
                          case "CSS":
                            var o = L()(
                              r.extractorConfig.parameterSelectors,
                              function (e) {
                                var t;
                                return (t = H(n, e.selector)) === null ||
                                  t === void 0
                                  ? void 0
                                  : t[0];
                              }
                            );
                            if (o == null) return null;
                            if (o.length === 2) {
                              var a = o[0],
                                i = o[1];
                              if (a != null && i != null) {
                                var l = Re(a, i);
                                l && o.push.apply(o, l);
                              }
                            }
                            var s =
                                r.extractorConfig.parameterSelectors[0]
                                  .parameterType,
                              u = L()(o, function (e) {
                                var t =
                                  (e == null ? void 0 : e.innerText) ||
                                  (e == null ? void 0 : e.textContent);
                                return [s, t];
                              }),
                              c = L()(
                                y()(u, function (e) {
                                  return Ee(e, 1)[0] !== "totalPrice";
                                }),
                                function (e) {
                                  var t = Ee(e, 2),
                                    n = t[0],
                                    r = t[1];
                                  return Pe($e, n, r);
                                }
                              );
                            if (
                              r.eventType === "InitiateCheckout" ||
                              r.eventType === "Purchase"
                            ) {
                              var p = ne()(u, function (e) {
                                return Ee(e, 1)[0] === "totalPrice";
                              });
                              p &&
                                (c = [
                                  {
                                    "@context": "http://schema.org",
                                    "@type": "ItemList",
                                    itemListElement: L()(c, function (e, t) {
                                      return {
                                        "@type": "ListItem",
                                        item: e,
                                        position: t + 1,
                                      };
                                    }),
                                    totalPrice: p[1] != null ? p[1] : void 0,
                                  },
                                ]);
                            }
                            return L()(c, function (e) {
                              return { extractorID: r.id, jsonLD: e };
                            });
                          case "CONSTANT_VALUE":
                            var f = r.extractorConfig,
                              h = f.parameterType,
                              C = f.value;
                            return { extractorID: r.id, jsonLD: Pe($e, h, C) };
                          case "URI":
                            var v = r.extractorConfig.parameterType,
                              R = (function (e, t, n) {
                                var r = new ue(e);
                                switch (t) {
                                  case ce:
                                    var o = y()(
                                        L()(
                                          r.pathname.split("/"),
                                          function (e) {
                                            return e.trim();
                                          }
                                        ),
                                        Boolean
                                      ),
                                      a = parseInt(n, 10);
                                    return a < o.length ? o[a] : null;
                                  case de:
                                    return r.searchParams.get(n);
                                }
                                return null;
                              })(
                                e.location.href,
                                r.extractorConfig.context,
                                r.extractorConfig.value
                              );
                            return { extractorID: r.id, jsonLD: Pe($e, v, R) };
                          default:
                            throw new Error(
                              "Extractor ".concat(
                                r.extractorType,
                                " not mapped"
                              )
                            );
                        }
                      })
                    ),
                    function (e) {
                      var t = e.jsonLD;
                      return !!t;
                    }
                  );
                }
                Ne.EXTRACTOR_PRECEDENCE = xe;
                var Me = Ne;
                function we(e) {
                  var t;
                  switch (e.extractor_type) {
                    case "CSS":
                      var n;
                      if (e.extractor_config == null)
                        throw new Error("extractor_config must be set");
                      var r = e.extractor_config;
                      if (r.parameter_type)
                        throw new Error("extractor_config must be set");
                      return {
                        domainURI: new ue(e.domain_uri),
                        eventType: e.event_type,
                        extractorConfig:
                          ((t = r),
                          {
                            parameterSelectors: L()(
                              t.parameter_selectors,
                              function (e) {
                                return {
                                  parameterType: e.parameter_type,
                                  selector: e.selector,
                                };
                              }
                            ),
                          }),
                        extractorType: "CSS",
                        id: g()(e.id),
                        ruleId:
                          (n = e.event_rule) === null || n === void 0
                            ? void 0
                            : n.id,
                      };
                    case "CONSTANT_VALUE":
                      var o;
                      if (e.extractor_config == null)
                        throw new Error("extractor_config must be set");
                      var a = e.extractor_config;
                      if (a.parameter_selectors)
                        throw new Error("extractor_config must be set");
                      return {
                        domainURI: new ue(e.domain_uri),
                        eventType: e.event_type,
                        extractorConfig: Ae(a),
                        extractorType: "CONSTANT_VALUE",
                        id: g()(e.id),
                        ruleId:
                          (o = e.event_rule) === null || o === void 0
                            ? void 0
                            : o.id,
                      };
                    case "URI":
                      var i;
                      if (e.extractor_config == null)
                        throw new Error("extractor_config must be set");
                      var l = e.extractor_config;
                      if (l.parameter_selectors)
                        throw new Error("extractor_config must be set");
                      return {
                        domainURI: new ue(e.domain_uri),
                        eventType: e.event_type,
                        extractorConfig: Fe(l),
                        extractorType: "URI",
                        id: g()(e.id),
                        ruleId:
                          (i = e.event_rule) === null || i === void 0
                            ? void 0
                            : i.id,
                      };
                    default:
                      var s;
                      return {
                        domainURI: new ue(e.domain_uri),
                        eventType: e.event_type,
                        extractorType: e.extractor_type,
                        id: g()(e.id),
                        ruleId:
                          (s = e.event_rule) === null || s === void 0
                            ? void 0
                            : s.id,
                      };
                  }
                }
                function Ae(e) {
                  return { parameterType: e.parameter_type, value: e.value };
                }
                function Fe(e) {
                  return {
                    context: e.context,
                    parameterType: e.parameter_type,
                    value: e.value,
                  };
                }
                var Oe = function (t, n, r) {
                    return typeof t != "string"
                      ? ""
                      : t.length < r && n === 0
                      ? t
                      : []
                          .concat(b()(t))
                          .slice(n, n + r)
                          .join("");
                  },
                  Be = function (t, n) {
                    return Oe(t, 0, n);
                  },
                  We = 120,
                  qe = [
                    "button",
                    "submit",
                    "input",
                    "li",
                    "option",
                    "progress",
                    "param",
                  ];
                function Ue(e) {
                  var t = u(e);
                  if (t != null && t.trim() !== "") return Be(t, We);
                  var n = e.type,
                    r = e.value;
                  if (n != null && S()(qe, n) && r != null && r !== "")
                    return Be(r, We);
                  var o = e.getAttribute("aria-label");
                  return Be(o != null && o !== "" ? o : "", We);
                }
                var Ve = ", ",
                  He = [
                    "input[type='button']",
                    "input[type='image']",
                    "input[type='submit']",
                    "button",
                    "[class*=btn]",
                    "[class*=Btn]",
                    "[class*=submit]",
                    "[class*=Submit]",
                    "[class*=button]",
                    "[class*=Button]",
                    "[role*=button]",
                    "[href^='tel:']",
                    "[href^='callto:']",
                    "[href^='mailto:']",
                    "[href^='sms:']",
                    "[href^='skype:']",
                    "[href^='whatsapp:']",
                    "[id*=btn]",
                    "[id*=Btn]",
                    "[id*=button]",
                    "[id*=Button]",
                    "a",
                  ].join(Ve),
                  Ge = ["[href^='http://']", "[href^='https://']"].join(Ve),
                  ze = [
                    "[href^='tel:']",
                    "[href^='callto:']",
                    "[href^='sms:']",
                    "[href^='skype:']",
                    "[href^='whatsapp:']",
                  ].join(Ve),
                  je = He,
                  Ke = [
                    "input[type='button']",
                    "input[type='submit']",
                    "button",
                    "a",
                  ].join(Ve);
                function Qe(t) {
                  var n,
                    r,
                    o = "";
                  if (t.tagName === "IMG") return t.getAttribute("src") || "";
                  var a =
                    (n =
                      (r = t.ownerDocument) === null || r === void 0
                        ? void 0
                        : r.defaultView) !== null && n !== void 0
                      ? n
                      : e;
                  if (a.getComputedStyle) {
                    var i = a
                      .getComputedStyle(t)
                      .getPropertyValue("background-image");
                    if (i != null && i !== "none" && i.length > 0) return i;
                  }
                  if (
                    t.tagName === "INPUT" &&
                    t.getAttribute("type") === "image"
                  ) {
                    var l = t.getAttribute("src");
                    if (l != null) return l;
                  }
                  var s = t.getElementsByTagName("img");
                  if (s.length !== 0) {
                    var u = s.item(0);
                    o = (u ? u.getAttribute("src") : null) || "";
                  }
                  return o;
                }
                var Xe = [
                    "sms:",
                    "mailto:",
                    "tel:",
                    "whatsapp:",
                    "https://wa.me/",
                    "skype:",
                    "callto:",
                  ],
                  Ye = /[\-!$><-==&_\/\?\.,0-9:; \]\[%~\"\{\}\)\(\+\@\^\`]/g,
                  Je = /((([a-z])(?=[A-Z]))|(([A-Z])(?=[A-Z][a-z])))/g,
                  Ze = /(^\S{1}(?!\S))|((\s)\S{1}(?!\S))/g,
                  et = /\s+/g;
                function tt(e) {
                  return !!(
                    (function (e) {
                      var t = Xe;
                      if (!e.hasAttribute("href")) return !1;
                      var n = e.getAttribute("href");
                      return (
                        n != null &&
                        !!ne()(t, function (e) {
                          return F()(n, e);
                        })
                      );
                    })(e) ||
                    ((t = Ue(e)),
                    t
                      .replace(Ye, " ")
                      .replace(Je, function (e) {
                        return e + " ";
                      })
                      .replace(Ze, function (e) {
                        return Be(e, e.length - 1) + " ";
                      })
                      .replace(et, " ")
                      .trim()
                      .toLowerCase()) ||
                    Qe(e) ||
                    e.querySelector("svg") != null ||
                    e.getAttribute("aria-label")
                  );
                  var t;
                }
                var nt = 600,
                  rt = 10;
                function ot(e) {
                  if (e == null || e === t.body || !tt(e)) return !1;
                  var n =
                    (typeof e.getBoundingClientRect == "function" &&
                      e.getBoundingClientRect().height) ||
                    e.offsetHeight;
                  return !isNaN(n) && n < nt && n > rt;
                }
                function at(e, t) {
                  for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    (r.enumerable = r.enumerable || !1),
                      (r.configurable = !0),
                      "value" in r && (r.writable = !0),
                      Object.defineProperty(e, it(r.key), r);
                  }
                }
                function it(e) {
                  var t = (function (e, t) {
                    if (lt(e) != "object" || !e) return e;
                    var n =
                      e[
                        typeof Symbol == "function"
                          ? Symbol.toPrimitive
                          : "@@toPrimitive"
                      ];
                    if (n !== void 0) {
                      var r = n.call(e, t || "default");
                      if (lt(r) != "object") return r;
                      throw new TypeError(
                        "@@toPrimitive must return a primitive value."
                      );
                    }
                    return (t === "string" ? String : Number)(e);
                  })(e, "string");
                  return lt(t) == "symbol" ? t : t + "";
                }
                function lt(e) {
                  return (
                    (lt =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator"
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    lt(e)
                  );
                }
                var st = Object.prototype.toString,
                  ut = !("addEventListener" in t);
                function ct(e) {
                  return Array.isArray
                    ? Array.isArray(e)
                    : st.call(e) === "[object Array]";
                }
                function dt(e) {
                  return e != null && lt(e) === "object" && ct(e) === !1;
                }
                function mt(e) {
                  return (
                    dt(e) === !0 &&
                    Object.prototype.toString.call(e) === "[object Object]"
                  );
                }
                var pt =
                    Number.isInteger ||
                    function (e) {
                      return (
                        typeof e == "number" &&
                        isFinite(e) &&
                        Math.floor(e) === e
                      );
                    },
                  _t = Object.prototype.hasOwnProperty,
                  ft = !{ toString: null }.propertyIsEnumerable("toString"),
                  gt = [
                    "toString",
                    "toLocaleString",
                    "valueOf",
                    "hasOwnProperty",
                    "isPrototypeOf",
                    "propertyIsEnumerable",
                    "constructor",
                  ],
                  ht = gt.length;
                function yt(e) {
                  if (
                    lt(e) !== "object" &&
                    (typeof e != "function" || e === null)
                  )
                    throw new TypeError("Object.keys called on non-object");
                  var t = [];
                  for (var n in e) _t.call(e, n) && t.push(n);
                  if (ft)
                    for (var r = 0; r < ht; r++)
                      _t.call(e, gt[r]) && t.push(gt[r]);
                  return t;
                }
                function Ct(e, t) {
                  if (e == null)
                    throw new TypeError(" array is null or not defined");
                  var n = Object(e),
                    r = n.length >>> 0;
                  if (typeof t != "function")
                    throw new TypeError(t + " is not a function");
                  for (var o = new Array(r), a = 0; a < r; ) {
                    var i = void 0;
                    a in n && ((i = t(n[a], a, n)), (o[a] = i)), a++;
                  }
                  return o;
                }
                function bt(e) {
                  if (typeof e != "function") throw new TypeError();
                  for (
                    var t = Object(this),
                      n = t.length >>> 0,
                      r = arguments.length >= 2 ? arguments[1] : void 0,
                      o = 0;
                    o < n;
                    o++
                  )
                    if (o in t && e.call(r, t[o], o, t)) return !0;
                  return !1;
                }
                function vt(e) {
                  if (this == null) throw new TypeError();
                  var t = Object(this),
                    n = t.length >>> 0;
                  if (typeof e != "function") throw new TypeError();
                  for (
                    var r = [],
                      o = arguments.length >= 2 ? arguments[1] : void 0,
                      a = 0;
                    a < n;
                    a++
                  )
                    if (a in t) {
                      var i = t[a];
                      e.call(o, i, a, t) && r.push(i);
                    }
                  return r;
                }
                function St(e, t) {
                  try {
                    return t(e);
                  } catch (e) {
                    if (e instanceof TypeError) {
                      if (Rt.test(e)) return null;
                      if (Lt.test(e)) return;
                    }
                    throw e;
                  }
                }
                var Rt = /^null | null$|^[^(]* null /i,
                  Lt = /^undefined | undefined$|^[^(]* undefined /i;
                St.default = St;
                var Et = {
                    FBSet: (function () {
                      return (
                        (e = function e(t) {
                          (function (e, t) {
                            if (!(e instanceof t))
                              throw new TypeError(
                                "Cannot call a class as a function"
                              );
                          })(this, e),
                            (this.items = t || []);
                        }),
                        (t = [
                          {
                            key: "has",
                            value: function (t) {
                              return bt.call(this.items, function (e) {
                                return e === t;
                              });
                            },
                          },
                          {
                            key: "add",
                            value: function (t) {
                              this.items.push(t);
                            },
                          },
                        ]) && at(e.prototype, t),
                        n && at(e, n),
                        Object.defineProperty(e, "prototype", { writable: !1 }),
                        e
                      );
                      var e, t, n;
                    })(),
                    castTo: function (t) {
                      return t;
                    },
                    each: function (t, n) {
                      Ct.call(this, t, n);
                    },
                    filter: function (t, n) {
                      return vt.call(t, n);
                    },
                    idx: St,
                    isArray: ct,
                    isEmptyObject: function (t) {
                      return yt(t).length === 0;
                    },
                    isInstanceOf: function (t, n) {
                      return n != null && t instanceof n;
                    },
                    isInteger: pt,
                    isNumber: function (t) {
                      return (
                        typeof t == "number" ||
                        (typeof t == "string" && /^\d+$/.test(t))
                      );
                    },
                    isObject: dt,
                    isPlainObject: function (t) {
                      if (mt(t) === !1) return !1;
                      var e = t.constructor;
                      if (typeof e != "function") return !1;
                      var n = e.prototype;
                      return (
                        mt(n) !== !1 &&
                        Object.prototype.hasOwnProperty.call(
                          n,
                          "isPrototypeOf"
                        ) !== !1
                      );
                    },
                    isSafeInteger: function (t) {
                      return pt(t) && t >= 0 && t <= Number.MAX_SAFE_INTEGER;
                    },
                    keys: yt,
                    listenOnce: function (t, n, r) {
                      var e = ut ? "on" + n : n,
                        o = ut ? t.attachEvent : t.addEventListener,
                        a = ut ? t.detachEvent : t.removeEventListener,
                        i = function () {
                          a && a.call(t, e, i, !1), r();
                        };
                      o && o.call(t, e, i, !1);
                    },
                    map: Ct,
                    reduce: function (t, n, r, o) {
                      if (t == null)
                        throw new TypeError(" array is null or not defined");
                      if (typeof n != "function")
                        throw new TypeError(n + " is not a function");
                      var e,
                        a = Object(t),
                        i = a.length >>> 0,
                        l = 0;
                      if (r != null || o === !0) e = r;
                      else {
                        for (; l < i && !(l in a); ) l++;
                        if (l >= i)
                          throw new TypeError(
                            "Reduce of empty array with no initial value"
                          );
                        e = a[l++];
                      }
                      for (; l < i; ) l in a && (e = n(e, a[l], l, t)), l++;
                      return e;
                    },
                    some: function (t, n) {
                      return bt.call(t, n);
                    },
                    stringIncludes: function (t, n) {
                      return t != null && n != null && t.indexOf(n) >= 0;
                    },
                    stringStartsWith: function (t, n) {
                      return t != null && n != null && t.indexOf(n) === 0;
                    },
                  },
                  kt = Et;
                function It(e, t) {
                  var n = Object.keys(e);
                  if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t &&
                      (r = r.filter(function (t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                      })),
                      n.push.apply(n, r);
                  }
                  return n;
                }
                function Tt(e) {
                  for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t] != null ? arguments[t] : {};
                    t % 2
                      ? It(Object(n), !0).forEach(function (t) {
                          Dt(e, t, n[t]);
                        })
                      : Object.getOwnPropertyDescriptors
                      ? Object.defineProperties(
                          e,
                          Object.getOwnPropertyDescriptors(n)
                        )
                      : It(Object(n)).forEach(function (t) {
                          Object.defineProperty(
                            e,
                            t,
                            Object.getOwnPropertyDescriptor(n, t)
                          );
                        });
                  }
                  return e;
                }
                function Dt(e, t, n) {
                  return (
                    (t = Pt(t)) in e
                      ? Object.defineProperty(e, t, {
                          value: n,
                          enumerable: !0,
                          configurable: !0,
                          writable: !0,
                        })
                      : (e[t] = n),
                    e
                  );
                }
                function xt(e) {
                  return (
                    (xt =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator"
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    xt(e)
                  );
                }
                function $t(e, t) {
                  for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    (r.enumerable = r.enumerable || !1),
                      (r.configurable = !0),
                      "value" in r && (r.writable = !0),
                      Object.defineProperty(e, Pt(r.key), r);
                  }
                }
                function Pt(e) {
                  var t = (function (e, t) {
                    if (xt(e) != "object" || !e) return e;
                    var n =
                      e[
                        typeof Symbol == "function"
                          ? Symbol.toPrimitive
                          : "@@toPrimitive"
                      ];
                    if (n !== void 0) {
                      var r = n.call(e, t || "default");
                      if (xt(r) != "object") return r;
                      throw new TypeError(
                        "@@toPrimitive must return a primitive value."
                      );
                    }
                    return (t === "string" ? String : Number)(e);
                  })(e, "string");
                  return xt(t) == "symbol" ? t : t + "";
                }
                function Nt(e, t, n) {
                  return (
                    (t = Ft(t)),
                    (function (e, t) {
                      if (t && (xt(t) == "object" || typeof t == "function"))
                        return t;
                      if (t !== void 0)
                        throw new TypeError(
                          "Derived constructors may only return object or undefined"
                        );
                      return (function (e) {
                        if (e === void 0)
                          throw new ReferenceError(
                            "this hasn't been initialised - super() hasn't been called"
                          );
                        return e;
                      })(e);
                    })(
                      e,
                      wt()
                        ? Reflect.construct(t, n || [], Ft(e).constructor)
                        : t.apply(e, n)
                    )
                  );
                }
                function Mt(e) {
                  var t = typeof Map == "function" ? new Map() : void 0;
                  return (
                    (Mt = function (n) {
                      if (
                        n === null ||
                        !(function (e) {
                          try {
                            return (
                              Function.toString
                                .call(e)
                                .indexOf("[native code]") !== -1
                            );
                          } catch (t) {
                            return typeof e == "function";
                          }
                        })(n)
                      )
                        return n;
                      if (typeof n != "function")
                        throw new TypeError(
                          "Super expression must either be null or a function"
                        );
                      if (t !== void 0) {
                        if (t.has(n)) return t.get(n);
                        t.set(n, e);
                      }
                      function e() {
                        return (function (e, t, n) {
                          if (wt())
                            return Reflect.construct.apply(null, arguments);
                          var r = [null];
                          r.push.apply(r, t);
                          var o = new (e.bind.apply(e, r))();
                          return n && At(o, n.prototype), o;
                        })(n, arguments, Ft(this).constructor);
                      }
                      return (
                        (e.prototype = Object.create(n.prototype, {
                          constructor: {
                            value: e,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0,
                          },
                        })),
                        At(e, n)
                      );
                    }),
                    Mt(e)
                  );
                }
                function wt() {
                  try {
                    var e = !Boolean.prototype.valueOf.call(
                      Reflect.construct(Boolean, [], function () {})
                    );
                  } catch (e) {}
                  return (wt = function () {
                    return !!e;
                  })();
                }
                function At(e, t) {
                  return (
                    (At = Object.setPrototypeOf
                      ? Object.setPrototypeOf.bind()
                      : function (e, t) {
                          return (e.__proto__ = t), e;
                        }),
                    At(e, t)
                  );
                }
                function Ft(e) {
                  return (
                    (Ft = Object.setPrototypeOf
                      ? Object.getPrototypeOf.bind()
                      : function (e) {
                          return e.__proto__ || Object.getPrototypeOf(e);
                        }),
                    Ft(e)
                  );
                }
                var Ot = kt.isSafeInteger,
                  Bt = kt.reduce,
                  Wt = (function (e) {
                    function t() {
                      var e,
                        n =
                          arguments.length > 0 && arguments[0] !== void 0
                            ? arguments[0]
                            : "";
                      return (
                        (function (e, t) {
                          if (!(e instanceof t))
                            throw new TypeError(
                              "Cannot call a class as a function"
                            );
                        })(this, t),
                        ((e = Nt(this, t, [n])).name = "PixelCoercionError"),
                        e
                      );
                    }
                    return (
                      (function (e, t) {
                        if (typeof t != "function" && t !== null)
                          throw new TypeError(
                            "Super expression must either be null or a function"
                          );
                        (e.prototype = Object.create(t && t.prototype, {
                          constructor: {
                            value: e,
                            writable: !0,
                            configurable: !0,
                          },
                        })),
                          Object.defineProperty(e, "prototype", {
                            writable: !1,
                          }),
                          t && At(e, t);
                      })(t, e),
                      (n = t),
                      r && $t(n.prototype, r),
                      o && $t(n, o),
                      Object.defineProperty(n, "prototype", { writable: !1 }),
                      n
                    );
                    var n, r, o;
                  })(Mt(Error));
                function qt() {
                  return function (e) {
                    if (e == null || !Array.isArray(e)) throw new Wt();
                    return e;
                  };
                }
                function Ut(e, t) {
                  try {
                    return t(e);
                  } catch (e) {
                    if (e.name === "PixelCoercionError") return null;
                    throw e;
                  }
                }
                function Vt(e, t) {
                  return t(e);
                }
                function Ht(e) {
                  if (!e) throw new Wt();
                }
                function Gt(e) {
                  var t = e.def,
                    n = e.validators;
                  return function (e) {
                    var r = Vt(e, t);
                    return (
                      n.forEach(function (e) {
                        if (!e(r)) throw new Wt();
                      }),
                      r
                    );
                  };
                }
                var zt = /^[1-9][0-9]{0,25}$/,
                  jt = {
                    allowNull: function (t) {
                      return function (e) {
                        return e == null ? null : t(e);
                      };
                    },
                    array: qt,
                    arrayOf: function (t) {
                      return function (e) {
                        return Vt(e, jt.array()).map(t);
                      };
                    },
                    assert: Ht,
                    boolean: function () {
                      return function (e) {
                        if (typeof e != "boolean") throw new Wt();
                        return e;
                      };
                    },
                    enumeration: function (t) {
                      return function (e) {
                        if (((n = t), Object.values(n)).includes(e)) return e;
                        var n;
                        throw new Wt();
                      };
                    },
                    fbid: function () {
                      return Gt({
                        def: function (t) {
                          var e = Ut(t, jt.number());
                          return e != null
                            ? (jt.assert(Ot(e)), "".concat(e))
                            : Vt(t, jt.string());
                        },
                        validators: [
                          function (e) {
                            return zt.test(e);
                          },
                        ],
                      });
                    },
                    mapOf: function (t) {
                      return function (e) {
                        var n = Vt(e, jt.object());
                        return Bt(
                          Object.keys(n),
                          function (e, r) {
                            return Tt(Tt({}, e), {}, Dt({}, r, t(n[r])));
                          },
                          {}
                        );
                      };
                    },
                    matches: function (t) {
                      return function (e) {
                        var n = Vt(e, jt.string());
                        if (t.test(n)) return n;
                        throw new Wt();
                      };
                    },
                    number: function () {
                      return function (e) {
                        if (typeof e != "number") throw new Wt();
                        return e;
                      };
                    },
                    object: function () {
                      return function (e) {
                        if (xt(e) !== "object" || Array.isArray(e) || e == null)
                          throw new Wt();
                        return e;
                      };
                    },
                    objectOrString: function () {
                      return function (e) {
                        if (
                          (xt(e) !== "object" && typeof e != "string") ||
                          Array.isArray(e) ||
                          e == null
                        )
                          throw new Wt();
                        return e;
                      };
                    },
                    objectWithFields: function (t) {
                      return function (e) {
                        var n = Vt(e, jt.object());
                        return Bt(
                          Object.keys(t),
                          function (e, r) {
                            if (e == null) return null;
                            var o = (0, t[r])(n[r]);
                            return Tt(Tt({}, e), {}, Dt({}, r, o));
                          },
                          {}
                        );
                      };
                    },
                    string: function () {
                      return function (e) {
                        if (typeof e != "string") throw new Wt();
                        return e;
                      };
                    },
                    stringOrNumber: function () {
                      return function (e) {
                        if (typeof e != "string" && typeof e != "number")
                          throw new Wt();
                        return e;
                      };
                    },
                    tuple: function (t) {
                      return function (e) {
                        var n = Vt(e, qt());
                        return (
                          Ht(n.length === t.length),
                          n.map(function (e, n) {
                            return Vt(e, t[n]);
                          })
                        );
                      };
                    },
                    withValidation: Gt,
                    func: function () {
                      return function (e) {
                        if (typeof e != "function" || e == null) throw new Wt();
                        return e;
                      };
                    },
                  },
                  Kt = {
                    Typed: jt,
                    coerce: Ut,
                    enforce: Vt,
                    PixelCoercionError: Wt,
                  },
                  Qt = Kt.Typed,
                  Xt = Qt.objectWithFields({
                    type: Qt.withValidation({
                      def: Qt.number(),
                      validators: [
                        function (e) {
                          return e >= 1 && e <= 3;
                        },
                      ],
                    }),
                    conditions: Qt.arrayOf(
                      Qt.objectWithFields({
                        targetType: Qt.withValidation({
                          def: Qt.number(),
                          validators: [
                            function (e) {
                              return e >= 1 && e <= 6;
                            },
                          ],
                        }),
                        extractor: Qt.allowNull(
                          Qt.withValidation({
                            def: Qt.number(),
                            validators: [
                              function (e) {
                                return e >= 1 && e <= 11;
                              },
                            ],
                          })
                        ),
                        operator: Qt.withValidation({
                          def: Qt.number(),
                          validators: [
                            function (e) {
                              return e >= 1 && e <= 4;
                            },
                          ],
                        }),
                        action: Qt.withValidation({
                          def: Qt.number(),
                          validators: [
                            function (e) {
                              return e >= 1 && e <= 4;
                            },
                          ],
                        }),
                        value: Qt.allowNull(Qt.string()),
                      })
                    ),
                  }),
                  Yt = "*";
                function Jt(e) {
                  var t = [],
                    n = e;
                  do {
                    var r = n.indexOf(Yt);
                    r < 0
                      ? (t.push(n), (n = ""))
                      : r === 0
                      ? (t.push(Yt), (n = n.slice(1)))
                      : (t.push(n.slice(0, r)), (n = n.slice(r)));
                  } while (n.length > 0);
                  return t;
                }
                var Zt = function (t, n) {
                  for (var e = Jt(t), r = n, o = 0; o < e.length; o++) {
                    var a = e[o];
                    if (a !== Yt) {
                      if (r.indexOf(a) !== 0) return !1;
                      r = r.slice(a.length);
                    } else {
                      if (o === e.length - 1) return !0;
                      var i = e[o + 1];
                      if (i === Yt) continue;
                      var l = r.indexOf(i);
                      if (l < 0) return !1;
                      r = r.slice(l);
                    }
                  }
                  return r === "";
                };
                function en(e, t) {
                  return (
                    (function (e) {
                      if (Array.isArray(e)) return e;
                    })(e) ||
                    (function (e, t) {
                      var n =
                        e == null
                          ? null
                          : (typeof Symbol != "undefined" &&
                              e[
                                typeof Symbol == "function"
                                  ? Symbol.iterator
                                  : "@@iterator"
                              ]) ||
                            e["@@iterator"];
                      if (n != null) {
                        var r,
                          o,
                          a,
                          i,
                          l = [],
                          s = !0,
                          u = !1;
                        try {
                          if (((a = (n = n.call(e)).next), t === 0)) {
                            if (Object(n) !== n) return;
                            s = !1;
                          } else
                            for (
                              ;
                              !(s = (r = a.call(n)).done) &&
                              (l.push(r.value), l.length !== t);
                              s = !0
                            );
                        } catch (e) {
                          (u = !0), (o = e);
                        } finally {
                          try {
                            if (
                              !s &&
                              n.return != null &&
                              ((i = n.return()), Object(i) !== i)
                            )
                              return;
                          } finally {
                            if (u) throw o;
                          }
                        }
                        return l;
                      }
                    })(e, t) ||
                    (function (e, t) {
                      if (e) {
                        if (typeof e == "string") return tn(e, t);
                        var n = {}.toString.call(e).slice(8, -1);
                        return (
                          n === "Object" &&
                            e.constructor &&
                            (n = e.constructor.name),
                          n === "Map" || n === "Set"
                            ? Array.from(e)
                            : n === "Arguments" ||
                              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
                            ? tn(e, t)
                            : void 0
                        );
                      }
                    })(e, t) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                      );
                    })()
                  );
                }
                function tn(e, t) {
                  (t == null || t > e.length) && (t = e.length);
                  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                  return r;
                }
                var nn = Kt.enforce,
                  rn = Zt,
                  on = Object.freeze({
                    CLICK: 1,
                    LOAD: 2,
                    BECOME_VISIBLE: 3,
                    TRACK: 4,
                  }),
                  an = Object.freeze({
                    BUTTON: 1,
                    PAGE: 2,
                    JS_VARIABLE: 3,
                    EVENT: 4,
                    ELEMENT: 6,
                  }),
                  ln = Object.freeze({
                    CONTAINS: 1,
                    EQUALS: 2,
                    DOMAIN_MATCHES: 3,
                    STRING_MATCHES: 4,
                  }),
                  sn = Object.freeze({
                    URL: 1,
                    TOKENIZED_TEXT_V1: 2,
                    TOKENIZED_TEXT_V2: 3,
                    TEXT: 4,
                    CLASS_NAME: 5,
                    ELEMENT_ID: 6,
                    EVENT_NAME: 7,
                    DESTINATION_URL: 8,
                    DOMAIN: 9,
                    PAGE_TITLE: 10,
                    IMAGE_URL: 11,
                  }),
                  un = Object.freeze({ ALL: 1, ANY: 2, NONE: 3 });
                function cn(e, t, n) {
                  if (t == null) return null;
                  switch (e) {
                    case an.PAGE:
                      return (function (e, t) {
                        switch (e) {
                          case sn.URL:
                            return t.resolvedLink;
                          case sn.DOMAIN:
                            return new URL(t.resolvedLink).hostname;
                          case sn.PAGE_TITLE:
                            if (t.pageFeatures != null)
                              return JSON.parse(
                                t.pageFeatures
                              ).title.toLowerCase();
                            break;
                          default:
                            return null;
                        }
                      })(t, n);
                    case an.BUTTON:
                      return (function (e, t) {
                        var n;
                        t.buttonText != null &&
                          (n = t.buttonText.toLowerCase());
                        var r = {};
                        switch (
                          (t.buttonFeatures != null &&
                            (r = JSON.parse(t.buttonFeatures)),
                          e)
                        ) {
                          case sn.DESTINATION_URL:
                            return r.destination;
                          case sn.TEXT:
                            return n;
                          case sn.TOKENIZED_TEXT_V1:
                            return n == null ? null : pn(n);
                          case sn.TOKENIZED_TEXT_V2:
                            return n == null ? null : _n(n);
                          case sn.ELEMENT_ID:
                            return r.id;
                          case sn.CLASS_NAME:
                            return r.classList;
                          case sn.IMAGE_URL:
                            return r.imageUrl;
                          default:
                            return null;
                        }
                      })(t, n);
                    case an.EVENT:
                      return (function (e, t) {
                        return e === sn.EVENT_NAME ? t.event : null;
                      })(t, n);
                    default:
                      return null;
                  }
                }
                function dn(e) {
                  return e.split("#")[0];
                }
                function mn(e, t) {
                  var n = e.replace(
                      /[\-!$><-==&_\/\?\.,0-9:; \]\[%~\"\{\}\)\(\+\@\^\`]/g,
                      " "
                    ),
                    r = n.replace(/([A-Z])/g, " $1").split(" ");
                  if (r == null || r.length === 0) return "";
                  n = en(r, 1)[0];
                  for (var o = 1; o < r.length; o++)
                    r[o - 1] != null &&
                    r[o] != null &&
                    r[o - 1].length === 1 &&
                    r[o].length === 1 &&
                    r[o - 1] === r[o - 1].toUpperCase() &&
                    r[o] === r[o].toUpperCase()
                      ? (n += r[o])
                      : (n += " " + r[o]);
                  var a = n.split(" ");
                  if (a == null || a.length === 0) return n;
                  n = "";
                  for (var i = t ? 1 : 2, l = 0; l < a.length; l++)
                    a[l] != null && a[l].length > i && (n += a[l] + " ");
                  return n.replace(/\s+/g, " ");
                }
                function pn(e) {
                  var t = mn(e, !0).toLowerCase().split(" ");
                  return t
                    .filter(function (e, n) {
                      return t.indexOf(e) === n;
                    })
                    .join(" ")
                    .trim();
                }
                function _n(e) {
                  return mn(e, !1).toLowerCase().trim();
                }
                function fn(e, t) {
                  if (t.startsWith("*.")) {
                    var n = t.slice(2).split(".").reverse(),
                      r = e.split(".").reverse();
                    if (n.length !== r.length) return !1;
                    for (var o = 0; o < n.length; o++)
                      if (n[o] !== r[o]) return !1;
                    return !0;
                  }
                  return e === t;
                }
                function gn(e) {
                  try {
                    var t = new URL(e),
                      n = t.searchParams;
                    return (
                      n.delete("utm_source"),
                      n.delete("utm_medium"),
                      n.delete("utm_campaign"),
                      n.delete("utm_content"),
                      n.delete("utm_term"),
                      n.delete("utm_id"),
                      n.delete("utm_name"),
                      n.delete("fbclid"),
                      n.delete("fb_action_ids"),
                      n.delete("fb_action_types"),
                      n.delete("fb_source"),
                      n.delete("fb_aggregation_id"),
                      n.sort(),
                      t.origin + t.pathname + "?" + n.toString()
                    );
                  } catch (t) {
                    return e;
                  }
                }
                function hn(e) {
                  try {
                    return unescape(encodeURIComponent(e));
                  } catch (t) {
                    return e;
                  }
                }
                function yn(e, t, n) {
                  var r =
                    arguments.length > 3 &&
                    arguments[3] !== void 0 &&
                    arguments[3];
                  switch (e) {
                    case ln.EQUALS:
                      return (function (e, t) {
                        var n =
                            arguments.length > 2 &&
                            arguments[2] !== void 0 &&
                            arguments[2],
                          r =
                            e === t ||
                            e.toLowerCase() === hn(t).toLowerCase() ||
                            pn(e) === t ||
                            dn(e) === dn(t);
                        if (!n || r) return r;
                        var o = t.toLowerCase(),
                          a = e.toLowerCase();
                        return (
                          (r =
                            (r = r || a === o) ||
                            hn(a).toLowerCase() === hn(o).toLowerCase()),
                          (r = (r = pn(a) === o) || dn(a) === dn(o)) ||
                            gn(a) === gn(o)
                        );
                      })(t, n, r);
                    case ln.CONTAINS:
                      return n != null && n.includes(t);
                    case ln.DOMAIN_MATCHES:
                      return fn(n, t);
                    case ln.STRING_MATCHES:
                      return n != null && rn(t, n);
                    default:
                      return !1;
                  }
                }
                function Cn(e, t) {
                  var n =
                    arguments.length > 2 &&
                    arguments[2] !== void 0 &&
                    arguments[2];
                  if (
                    !(function (e, t) {
                      switch (e) {
                        case on.LOAD:
                          return t.event === "PageView";
                        case on.CLICK:
                          return t.event === "SubscribedButtonClick";
                        case on.TRACK:
                          return !0;
                        case on.BECOME_VISIBLE:
                        default:
                          return !1;
                      }
                    })(e.action, t)
                  )
                    return !1;
                  var r = cn(e.targetType, e.extractor, t);
                  if (r == null) return !1;
                  var o = e.value;
                  return (
                    o != null &&
                    ((e.extractor !== sn.TOKENIZED_TEXT_V1 &&
                      e.extractor !== sn.TOKENIZED_TEXT_V2) ||
                      (o = o.toLowerCase()),
                    yn(e.operator, o, r, n))
                  );
                }
                var bn = {
                    isMatchESTRule: function (t, n) {
                      var e =
                          arguments.length > 2 &&
                          arguments[2] !== void 0 &&
                          arguments[2],
                        r = t;
                      typeof t == "string" && (r = JSON.parse(t));
                      for (
                        var o = nn(r, Xt), a = [], i = 0;
                        i < o.conditions.length;
                        i++
                      )
                        a.push(Cn(o.conditions[i], n, e));
                      switch (o.type) {
                        case un.ALL:
                          return !a.includes(!1);
                        case un.ANY:
                          return a.includes(!0);
                        case un.NONE:
                          return !a.includes(!0);
                      }
                      return !1;
                    },
                    getKeywordsStringFromTextV1: pn,
                    getKeywordsStringFromTextV2: _n,
                    domainMatches: fn,
                  },
                  vn = Kt.coerce,
                  Sn = Kt.Typed,
                  Rn = kt.each,
                  Ln = kt.filter,
                  En = kt.reduce,
                  kn = [
                    "product",
                    "product_group",
                    "vehicle",
                    "automotive_model",
                  ],
                  In = Sn.objectWithFields({
                    "@context": Sn.string(),
                    additionalType: Sn.allowNull(Sn.string()),
                    offers: Sn.allowNull(
                      Sn.objectWithFields({
                        priceCurrency: Sn.allowNull(Sn.string()),
                        price: Sn.allowNull(Sn.string()),
                      })
                    ),
                    order_id: function (t) {
                      return typeof t == "string" ? t : null;
                    },
                    productID: Sn.allowNull(Sn.string()),
                    sku: Sn.allowNull(Sn.string()),
                    "@type": Sn.string(),
                  }),
                  Tn = Sn.objectWithFields({
                    "@context": Sn.string(),
                    "@type": Sn.string(),
                    item: In,
                  }),
                  Dn = Sn.objectWithFields({
                    "@context": Sn.string(),
                    "@type": Sn.string(),
                    itemListElement: Sn.array(),
                    totalPrice: Sn.allowNull(Sn.string()),
                  });
                function xn(e) {
                  var t = vn(e, In);
                  if (t == null) return null;
                  var n = typeof t.productID == "string" ? t.productID : null,
                    r = typeof t.sku == "string" ? t.sku : null,
                    o = t.offers,
                    a = null,
                    i = null;
                  o != null && ((a = Mn(o.price)), (i = o.priceCurrency));
                  var l =
                      typeof t.additionalType == "string" &&
                      kn.includes(t.additionalType)
                        ? t.additionalType
                        : null,
                    s = typeof t.order_id == "string" ? t.order_id : null,
                    u = [n, r],
                    c = {};
                  return (
                    (u = Ln(u, function (e) {
                      return e != null;
                    })).length && (c.content_ids = u),
                    i != null && (c.currency = i),
                    a != null && (c.value = a),
                    l != null && (c.content_type = l),
                    s != null && (c.order_id = s),
                    [c]
                  );
                }
                function $n(e) {
                  var t = vn(e, Tn);
                  return t == null ? null : Nn([t.item]);
                }
                function Pn(e) {
                  var t = vn(e, Dn);
                  if (t == null) return null;
                  var n = typeof t.totalPrice == "string" ? t.totalPrice : null;
                  n = Mn(n);
                  var r = Nn(t.itemListElement),
                    o = null;
                  return (
                    r != null &&
                      r.length > 0 &&
                      (o = En(
                        r,
                        function (e, t) {
                          var n = t.value;
                          if (n == null) return e;
                          try {
                            var r = parseFloat(n);
                            return e == null ? r : e + r;
                          } catch (t) {
                            return e;
                          }
                        },
                        null,
                        !0
                      )),
                    (r = [
                      { value: n },
                      { value: o != null ? o.toString() : null },
                    ].concat(r))
                  );
                }
                function Nn(e) {
                  var t = [];
                  return (
                    Rn(e, function (n) {
                      if (e != null) {
                        var r =
                          typeof n["@type"] == "string" ? n["@type"] : null;
                        if (r !== null) {
                          var o = null;
                          switch (r) {
                            case "Product":
                              o = xn(n);
                              break;
                            case "ItemList":
                              o = Pn(n);
                              break;
                            case "ListItem":
                              o = $n(n);
                          }
                          o != null && (t = t.concat(o));
                        }
                      }
                    }),
                    (t = Ln(t, function (e) {
                      return e != null;
                    })),
                    Rn(t, function (e) {
                      Rn(Object.keys(e), function (t) {
                        var n = e[t];
                        (Array.isArray(n) && n.length > 0) ||
                          (typeof n == "string" && n !== "") ||
                          delete e[t];
                      });
                    }),
                    (t = Ln(t, function (e) {
                      return Object.keys(e).length > 0;
                    }))
                  );
                }
                function Mn(e) {
                  if (e == null) return null;
                  var t = e.replace(/\\u[\dA-F]{4}/gi, function (e) {
                    var t = e.replace(/\\u/g, ""),
                      n = parseInt(t, 16);
                    return String.fromCharCode(n);
                  });
                  if (
                    ((t = (function (e) {
                      var t = e;
                      if (t.length >= 3) {
                        var n = t.substring(t.length - 3);
                        if (/((\.)(\d)(0)|(\,)(0)(0))/.test(n)) {
                          var r = n.charAt(0),
                            o = n.charAt(1),
                            a = n.charAt(2);
                          o !== "0" && (r += o),
                            a !== "0" && (r += a),
                            r.length === 1 && (r = ""),
                            (t = t.substring(0, t.length - 3) + r);
                        }
                      }
                      return t;
                    })(
                      (t = (t = (t = t.replace(/[^\d,\.]/g, "")).replace(
                        /(\.){2,}/g,
                        ""
                      )).replace(/(\,){2,}/g, ""))
                    )),
                    !wn(t))
                  )
                    return null;
                  var n = (function (e) {
                    var t = e,
                      n = (function (e) {
                        var t = e.replace(/\,/g, "");
                        return Fn((t = An(t)), !1);
                      })(t),
                      r = (function (e) {
                        var t = e.replace(/\./g, "");
                        return Fn((t = An((t = t.replace(/\,/g, ".")))), !0);
                      })(t);
                    if (n == null || r == null)
                      return n != null ? n : r != null ? r : null;
                    var o = r.length;
                    return (
                      o > 0 && r.charAt(o - 1) !== "0" && (o -= 1),
                      n.length >= o ? n : r
                    );
                  })(t);
                  return n == null ? null : wn((t = n)) ? t : null;
                }
                function wn(e) {
                  return /\d/.test(e);
                }
                function An(e) {
                  var t = e,
                    n = t.indexOf(".");
                  return n < 0
                    ? t
                    : (t =
                        t.substring(0, n + 1) +
                        t.substring(n + 1).replace(/\./g, ""));
                }
                function Fn(e, t) {
                  try {
                    var n = parseFloat(e);
                    if (typeof (o = n) != "number" || Number.isNaN(o))
                      return null;
                    var r = t ? 3 : 2;
                    return parseFloat(n.toFixed(r)).toString();
                  } catch (e) {
                    return null;
                  }
                  var o;
                }
                var On = {
                    genCustomData: Nn,
                    reduceCustomData: function (t) {
                      if (t.length === 0) return {};
                      var e = En(
                        t,
                        function (e, t) {
                          return (
                            Rn(Object.keys(t), function (n) {
                              var r = t[n],
                                o = e[n];
                              if (o == null) e[n] = r;
                              else if (Array.isArray(o)) {
                                var a = Array.isArray(r) ? r : [r];
                                e[n] = o.concat(a);
                              }
                            }),
                            e
                          );
                        },
                        {}
                      );
                      return (
                        Rn(Object.keys(e), function (t) {
                          e[t], e[t] == null && delete e[t];
                        }),
                        e
                      );
                    },
                    getProductData: xn,
                    getItemListData: Pn,
                    getListItemData: $n,
                    genNormalizePrice: Mn,
                  },
                  Bn = function (t, n) {
                    var e = t.id,
                      r = t.tagName,
                      o = u(t),
                      a = r.toLowerCase(),
                      i = t.className,
                      l = t.querySelectorAll(He).length,
                      s = null;
                    t.tagName === "A" &&
                    t instanceof HTMLAnchorElement &&
                    t.href
                      ? (s = t.href)
                      : n != null &&
                        n instanceof HTMLFormElement &&
                        n.action &&
                        (s = n.action),
                      typeof s != "string" && (s = "");
                    var c = {
                      classList: i,
                      destination: s,
                      id: e,
                      imageUrl: Qe(t),
                      innerText: o || "",
                      numChildButtons: l,
                      tag: a,
                      type: t.getAttribute("type"),
                    };
                    return (
                      (t instanceof HTMLInputElement ||
                        t instanceof HTMLSelectElement ||
                        t instanceof HTMLTextAreaElement ||
                        t instanceof HTMLButtonElement) &&
                        ((c.name = t.name), (c.value = t.value)),
                      t instanceof HTMLAnchorElement && (c.name = t.name),
                      c
                    );
                  },
                  Wn = function () {
                    var e = t.querySelector("title");
                    return { title: Be(e && e.text, 500) };
                  },
                  qn = function (t, n) {
                    var e = t,
                      r =
                        t.matches ||
                        e.matchesSelector ||
                        e.mozMatchesSelector ||
                        e.msMatchesSelector ||
                        e.oMatchesSelector ||
                        e.webkitMatchesSelector ||
                        null;
                    return r !== null && r.bind(t)(n);
                  },
                  Un = function (t) {
                    if (t instanceof HTMLInputElement) return t.form;
                    if (qn(t, ze)) return null;
                    for (var e = I(t); e.nodeName !== "FORM"; ) {
                      var n = I(e.parentElement);
                      if (n == null) return null;
                      e = n;
                    }
                    return e;
                  },
                  Vn = function (t) {
                    return Ue(t).substring(0, 200);
                  },
                  Hn = function (n) {
                    if (
                      e.FacebookIWL != null &&
                      e.FacebookIWL.getIWLRoot != null &&
                      typeof e.FacebookIWL.getIWLRoot == "function"
                    ) {
                      var t = e.FacebookIWL.getIWLRoot();
                      return t && t.contains(n);
                    }
                    return !1;
                  },
                  Gn = "Outbound",
                  zn = "Download",
                  jn = [
                    ".pdf",
                    ".docx",
                    ".doc",
                    ".txt",
                    ".jpg",
                    ".jpeg",
                    ".png",
                    ".gif",
                    ".mp3",
                    ".wav",
                    ".ogg",
                    ".zip",
                    ".rar",
                    ".7z",
                    ".exe",
                    ".msi",
                    ".xlsx",
                    ".xls",
                    ".pptx",
                    ".ppt",
                  ],
                  Kn = function (n) {
                    var t = [],
                      r = e.location.hostname,
                      o = n.getAttribute("href");
                    return (
                      o !== null &&
                        o !== "" &&
                        typeof o == "string" &&
                        (o.startsWith("http://") || o.startsWith("https://")) &&
                        (new URL(o).host !== r && t.push(Gn),
                        jn.some(function (e) {
                          return o.endsWith(e);
                        }) && t.push(zn)),
                      t
                    );
                  },
                  Qn = (0, kt.filter)(He.split(Ve), function (e) {
                    return e !== "a";
                  }).join(Ve),
                  Xn = function e(t, n, r) {
                    var o =
                      arguments.length > 3 &&
                      arguments[3] !== void 0 &&
                      arguments[3];
                    if (t == null || !ot(t)) return null;
                    if (qn(t, n ? He : Qn)) return t;
                    if (r && qn(t, Ge)) {
                      var a = Kn(t);
                      if (a != null && a.length > 0) return t;
                    }
                    var i = t.parentNode,
                      l =
                        o && i != null && i.nodeType === 11 ? I(i.host) : I(i);
                    return l != null ? e(l, n, r, o) : null;
                  },
                  Yn = 32,
                  Jn = 10,
                  Zn = 9,
                  er = 13,
                  tr = 160,
                  nr = 8192,
                  rr = 8202,
                  or = 8239,
                  ar = 8287,
                  ir = 12288;
                function lr(e) {
                  return /^[0-9A-Fa-f]$/.test(e);
                }
                function sr(e) {
                  return e >= "0" && e <= "9";
                }
                function ur(e) {
                  return ",:[]/{}()\n+".includes(e);
                }
                function cr(e) {
                  return (
                    (e >= "a" && e <= "z") ||
                    (e >= "A" && e <= "Z") ||
                    e === "_" ||
                    e === "$"
                  );
                }
                function dr(e) {
                  return (
                    (e >= "a" && e <= "z") ||
                    (e >= "A" && e <= "Z") ||
                    e === "_" ||
                    e === "$" ||
                    (e >= "0" && e <= "9")
                  );
                }
                var mr = /^(http|https|ftp|mailto|file|data|irc):\/\/$/,
                  pr = /^[A-Za-z0-9-._~:/?#@!$&\'()*+;=]$/;
                function _r(e) {
                  return ",[]/{}\n+".includes(e);
                }
                function fr(e) {
                  return br(e) || gr.test(e);
                }
                var gr = /^[[{\w-]$/;
                function hr(e, t) {
                  var n = e.charCodeAt(t);
                  return n === Yn || n === Jn || n === Zn || n === er;
                }
                function yr(e, t) {
                  var n = e.charCodeAt(t);
                  return n === Yn || n === Zn || n === er;
                }
                function Cr(e, t) {
                  var n = e.charCodeAt(t);
                  return (
                    n === tr ||
                    (n >= nr && n <= rr) ||
                    n === or ||
                    n === ar ||
                    n === ir
                  );
                }
                function br(e) {
                  return vr(e) || Rr(e);
                }
                function vr(e) {
                  return e === '"' || e === "\u201C" || e === "\u201D";
                }
                function Sr(e) {
                  return e === '"';
                }
                function Rr(e) {
                  return (
                    e === "'" ||
                    e === "\u2018" ||
                    e === "\u2019" ||
                    e === "`" ||
                    e === "\xB4"
                  );
                }
                function Lr(e) {
                  return e === "'";
                }
                function Er(e, t) {
                  var n =
                      arguments.length > 2 &&
                      arguments[2] !== void 0 &&
                      arguments[2],
                    r = e.lastIndexOf(t);
                  return r !== -1
                    ? e.substring(0, r) + (n ? "" : e.substring(r + 1))
                    : e;
                }
                function kr(e, t) {
                  var n = e.length;
                  if (!hr(e, n - 1)) return e + t;
                  for (; hr(e, n - 1); ) n--;
                  return e.substring(0, n) + t + e.substring(n);
                }
                function Ir(e, t, n) {
                  return e.substring(0, t) + e.substring(t + n);
                }
                function Tr(e, t) {
                  var n =
                    (typeof Symbol != "undefined" &&
                      e[
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator"
                      ]) ||
                    e["@@iterator"];
                  if (!n) {
                    if (
                      Array.isArray(e) ||
                      (n = (function (e, t) {
                        if (e) {
                          if (typeof e == "string") return Dr(e, t);
                          var n = {}.toString.call(e).slice(8, -1);
                          return (
                            n === "Object" &&
                              e.constructor &&
                              (n = e.constructor.name),
                            n === "Map" || n === "Set"
                              ? Array.from(e)
                              : n === "Arguments" ||
                                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(
                                  n
                                )
                              ? Dr(e, t)
                              : void 0
                          );
                        }
                      })(e)) ||
                      (t && e && typeof e.length == "number")
                    ) {
                      n && (e = n);
                      var r = 0,
                        o = function () {};
                      return {
                        s: o,
                        n: function () {
                          return r >= e.length
                            ? { done: !0 }
                            : { done: !1, value: e[r++] };
                        },
                        e: function (t) {
                          throw t;
                        },
                        f: o,
                      };
                    }
                    throw new TypeError(
                      "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                    );
                  }
                  var a,
                    i = !0,
                    l = !1;
                  return {
                    s: function () {
                      n = n.call(e);
                    },
                    n: function () {
                      var e = n.next();
                      return (i = e.done), e;
                    },
                    e: function (t) {
                      (l = !0), (a = t);
                    },
                    f: function () {
                      try {
                        i || n.return == null || n.return();
                      } finally {
                        if (l) throw a;
                      }
                    },
                  };
                }
                function Dr(e, t) {
                  (t == null || t > e.length) && (t = e.length);
                  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                  return r;
                }
                var xr = {
                    "\b": "\\b",
                    "\f": "\\f",
                    "\n": "\\n",
                    "\r": "\\r",
                    "	": "\\t",
                  },
                  $r = {
                    '"': '"',
                    "\\": "\\",
                    "/": "/",
                    b: "\b",
                    f: "\f",
                    n: "\n",
                    r: "\r",
                    t: "	",
                  };
                function Pr(e) {
                  var t = 0,
                    n = "";
                  s(["```", "[```", "{```"]),
                    o() ||
                      (function () {
                        throw new Error(
                          "Unexpected end of json string at position ".concat(
                            e.length
                          )
                        );
                      })(),
                    s(["```", "```]", "```}"]);
                  var r = u(",");
                  for (
                    r && a(),
                      fr(e[t]) &&
                      (function (e) {
                        return /[,\n][ \t\r]*$/.test(e);
                      })(n)
                        ? (r || (n = kr(n, ",")),
                          (function () {
                            for (var e = !0, t = !0; t; )
                              e ? (e = !1) : u(",") || (n = kr(n, ",")),
                                (t = o());
                            t || (n = Er(n, ",")), (n = "[\n".concat(n, "\n]"));
                          })())
                        : r && (n = Er(n, ","));
                    e[t] === "}" || e[t] === "]";

                  )
                    t++, a();
                  if (t >= e.length) return n;
                  function o() {
                    a();
                    var r =
                      (function () {
                        if (e[t] !== "{") return !1;
                        (n += "{"), t++, a(), c(",") && a();
                        for (var r = !0; t < e.length && e[t] !== "}"; ) {
                          if (
                            (r ? (r = !1) : (u(",") || (n = kr(n, ",")), a()),
                            m(),
                            !(p() || S(!0)))
                          ) {
                            e[t] === "}" ||
                            e[t] === "{" ||
                            e[t] === "]" ||
                            e[t] === "[" ||
                            e[t] === void 0
                              ? (n = Er(n, ","))
                              : k();
                            break;
                          }
                          a();
                          var i = u(":"),
                            l = t >= e.length;
                          i || (fr(e[t]) || l ? (n = kr(n, ":")) : I()),
                            o() || (i || l ? (n += "null") : I());
                        }
                        return (
                          (function () {
                            e[t] === "}" ? ((n += "}"), t++) : (n = kr(n, "}"));
                          })(),
                          !0
                        );
                      })() ||
                      (function () {
                        if (e[t] === "[") {
                          (n += "["), t++, a(), c(",") && a();
                          for (var r = !0; t < e.length && e[t] !== "]"; )
                            if (
                              (r ? (r = !1) : u(",") || (n = kr(n, ",")),
                              m(),
                              !o())
                            ) {
                              n = Er(n, ",");
                              break;
                            }
                          return (
                            e[t] === "]" ? ((n += "]"), t++) : (n = kr(n, "]")),
                            !0
                          );
                        }
                        return !1;
                      })() ||
                      p() ||
                      (function () {
                        var r = t;
                        if (e[t] === "-") {
                          if ((t++, L())) return E(r), !0;
                          if (!sr(e[t])) return (t = r), !1;
                        }
                        for (; sr(e[t]); ) t++;
                        if (e[t] === ".") {
                          if ((t++, L())) return E(r), !0;
                          if (!sr(e[t])) return (t = r), !1;
                          for (; sr(e[t]); ) t++;
                        }
                        if (e[t] === "e" || e[t] === "E") {
                          if ((t++, (e[t] !== "-" && e[t] !== "+") || t++, L()))
                            return E(r), !0;
                          if (!sr(e[t])) return (t = r), !1;
                          for (; sr(e[t]); ) t++;
                        }
                        if (!L()) return (t = r), !1;
                        if (t > r) {
                          var o = e.slice(r, t),
                            a = /^0\d/.test(o);
                          return (n += a ? '"'.concat(o, '"') : o), !0;
                        }
                        return !1;
                      })() ||
                      v("true", "true") ||
                      v("false", "false") ||
                      v("null", "null") ||
                      v("True", "true") ||
                      v("False", "false") ||
                      v("None", "null") ||
                      S(!1) ||
                      (function () {
                        if (e[t] === "/") {
                          var r = t;
                          for (
                            t++;
                            t < e.length && (e[t] !== "/" || e[t - 1] === "\\");

                          )
                            t++;
                          return (
                            t++, (n += '"'.concat(e.substring(r, t), '"')), !0
                          );
                        }
                      })();
                    return a(), r;
                  }
                  function a() {
                    var e =
                        !(arguments.length > 0 && arguments[0] !== void 0) ||
                        arguments[0],
                      n = t,
                      r = i(e);
                    do (r = l()) && (r = i(e));
                    while (r);
                    return t > n;
                  }
                  function i(r) {
                    for (var o = r ? hr : yr, a = ""; ; )
                      if (o(e, t)) (a += e[t]), t++;
                      else {
                        if (!Cr(e, t)) break;
                        (a += " "), t++;
                      }
                    return a.length > 0 && ((n += a), !0);
                  }
                  function l() {
                    if (e[t] === "/" && e[t + 1] === "*") {
                      for (; t < e.length && !Nr(e, t); ) t++;
                      return (t += 2), !0;
                    }
                    if (e[t] === "/" && e[t + 1] === "/") {
                      for (; t < e.length && e[t] !== "\n"; ) t++;
                      return !0;
                    }
                    return !1;
                  }
                  function s(n) {
                    if (
                      (function (n) {
                        var r,
                          o = Tr(n);
                        try {
                          for (o.s(); !(r = o.n()).done; ) {
                            var a = r.value,
                              i = t + a.length;
                            if (e.slice(t, i) === a) return (t = i), !0;
                          }
                        } catch (e) {
                          o.e(e);
                        } finally {
                          o.f();
                        }
                        return !1;
                      })(n)
                    ) {
                      if (cr(e[t])) for (; t < e.length && dr(e[t]); ) t++;
                      return a(), !0;
                    }
                    return !1;
                  }
                  function u(r) {
                    return e[t] === r && ((n += e[t]), t++, !0);
                  }
                  function c(n) {
                    return e[t] === n && (t++, !0);
                  }
                  function d() {
                    return c("\\");
                  }
                  function m() {
                    return (
                      a(),
                      e[t] === "." &&
                        e[t + 1] === "." &&
                        e[t + 2] === "." &&
                        ((t += 3), a(), c(","), !0)
                    );
                  }
                  function p() {
                    var r =
                        arguments.length > 0 &&
                        arguments[0] !== void 0 &&
                        arguments[0],
                      o =
                        arguments.length > 1 && arguments[1] !== void 0
                          ? arguments[1]
                          : -1,
                      a = e[t] === "\\";
                    if ((a && (t++, (a = !0)), !br(e[t]))) return !1;
                    var i = Sr(e[t]) ? Sr : Lr(e[t]) ? Lr : Rr(e[t]) ? Rr : vr,
                      l = t,
                      s = n.length,
                      u = '"';
                    for (t++; ; ) {
                      var c = {
                          str: u,
                          stopAtDelimiter: r,
                          iBefore: l,
                          oBefore: s,
                          stopAtIndex: o,
                          isEndQuote: i,
                        },
                        m = _(c);
                      if (m !== null) return m;
                      var p = f(c);
                      if (p !== null) return p;
                      var b = g(c);
                      if (b !== null) {
                        if (b.shouldContinue) {
                          u = b.str;
                          continue;
                        }
                        return b.result;
                      }
                      var v = h(c);
                      if (v !== null) return v;
                      var S = y(u);
                      (u = S !== null ? S : C(u)), a && d();
                    }
                  }
                  function _(r) {
                    if (t >= e.length) {
                      var o = r.str,
                        a = r.stopAtDelimiter,
                        i = r.iBefore,
                        l = r.oBefore,
                        s = R(t - 1);
                      if (!a && ur(e.charAt(s)))
                        return (t = i), (n = n.substring(0, l)), p(!0);
                      var u = kr(o, '"');
                      return (n += u), !0;
                    }
                    return null;
                  }
                  function f(e) {
                    if (t === e.stopAtIndex) {
                      var r = kr(e.str, '"');
                      return (n += r), !0;
                    }
                    return null;
                  }
                  function g(r) {
                    if (r.isEndQuote(e[t])) {
                      var o = r.str,
                        i = r.stopAtDelimiter,
                        l = r.iBefore,
                        s = r.oBefore,
                        u = t,
                        c = o.length,
                        d = o + '"';
                      if (
                        (t++,
                        (n += d),
                        a(!1),
                        i || t >= e.length || ur(e[t]) || br(e[t]) || sr(e[t]))
                      )
                        return b(), { result: !0, shouldContinue: !1 };
                      var m = R(u - 1),
                        _ = e.charAt(m);
                      return _ === ","
                        ? ((t = l),
                          (n = n.substring(0, s)),
                          { result: p(!1, m), shouldContinue: !1 })
                        : ur(_)
                        ? ((t = l),
                          (n = n.substring(0, s)),
                          { result: p(!0), shouldContinue: !1 })
                        : ((n = n.substring(0, s)),
                          (t = u + 1),
                          {
                            str: ""
                              .concat(d.substring(0, c), "\\")
                              .concat(d.substring(c)),
                            shouldContinue: !0,
                          });
                    }
                    return null;
                  }
                  function h(r) {
                    if (r.stopAtDelimiter && _r(e[t])) {
                      var o = r.iBefore,
                        a = r.str;
                      if (
                        e[t - 1] === ":" &&
                        mr.test(e.substring(o + 1, t + 2))
                      )
                        for (; t < e.length && pr.test(e[t]); )
                          (a += e[t]), t++;
                      var i = kr(a, '"');
                      return (n += i), b(), !0;
                    }
                    return null;
                  }
                  function y(n) {
                    if (e[t] === "\\") {
                      var r = e.charAt(t + 1);
                      if ($r[r] !== void 0) (n += e.slice(t, t + 2)), (t += 2);
                      else if (r === "u") {
                        for (var o = 2; o < 6 && lr(e[t + o]); ) o++;
                        o === 6
                          ? ((n += e.slice(t, t + 6)), (t += 6))
                          : t + o >= e.length
                          ? (t = e.length)
                          : (function () {
                              var n = e.slice(t, t + 6);
                              throw new Error(
                                'Invalid unicode character "'
                                  .concat(n, '" at position ')
                                  .concat(t)
                              );
                            })();
                      } else (n += r), (t += 2);
                      return n;
                    }
                    return null;
                  }
                  function C(n) {
                    var r,
                      o = e.charAt(t);
                    return (
                      o === '"' && e[t - 1] !== "\\"
                        ? ((n += "\\".concat(o)), t++)
                        : (r = o) === "\n" ||
                          r === "\r" ||
                          r === "	" ||
                          r === "\b" ||
                          r === "\f"
                        ? ((n += xr[o]), t++)
                        : (o >= " " ||
                            (function (e) {
                              throw new Error(
                                "Invalid character "
                                  .concat(JSON.stringify(e), " at position ")
                                  .concat(t)
                              );
                            })(o),
                          (n += o),
                          t++),
                      n
                    );
                  }
                  function b() {
                    var r = !1;
                    for (a(); e[t] === "+"; ) {
                      (r = !0), t++, a();
                      var o = (n = Er(n, '"', !0)).length,
                        i = p();
                      n = i ? Ir(n, o, 1) : kr(n, '"');
                    }
                    return r;
                  }
                  function v(r, o) {
                    return (
                      e.slice(t, t + r.length) === r &&
                      ((n += o), (t += r.length), !0)
                    );
                  }
                  function S(r) {
                    var a = t;
                    if (cr(e[t])) {
                      for (; t < e.length && dr(e[t]); ) t++;
                      for (var i = t; hr(e, i); ) i++;
                      if (e[i] === "(")
                        return (
                          (t = i + 1),
                          o(),
                          e[t] === ")" && (t++, e[t] === ";" && t++),
                          !0
                        );
                    }
                    if (
                      ((function (n, r) {
                        for (
                          ;
                          t < e.length &&
                          !_r(e[t]) &&
                          !br(e[t]) &&
                          (!r || e[t] !== ":");

                        )
                          t++;
                        if (e[t - 1] === ":" && mr.test(e.substring(n, t + 2)))
                          for (; t < e.length && pr.test(e[t]); ) t++;
                      })(a, r),
                      t > a)
                    ) {
                      for (; hr(e, t - 1) && t > 0; ) t--;
                      var l = e.slice(a, t);
                      return (
                        (n += l === "undefined" ? "null" : JSON.stringify(l)),
                        e[t] === '"' && t++,
                        !0
                      );
                    }
                  }
                  function R(t) {
                    for (var n = t; n > 0 && hr(e, n); ) n--;
                    return n;
                  }
                  function L() {
                    return t >= e.length || ur(e[t]) || hr(e, t);
                  }
                  function E(r) {
                    n += "".concat(e.slice(r, t), "0");
                  }
                  function k() {
                    throw new Error(
                      "Object key expected at position ".concat(t)
                    );
                  }
                  function I() {
                    throw new Error("Colon expected at position ".concat(t));
                  }
                  (function () {
                    throw new Error(
                      "Unexpected character "
                        .concat(JSON.stringify(e[t]), " at position ")
                        .concat(t)
                    );
                  })();
                }
                function Nr(e, t) {
                  return e[t] === "*" && e[t + 1] === "/";
                }
                function Mr(e) {
                  return (
                    (Mr =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator"
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    Mr(e)
                  );
                }
                function wr(e) {
                  return (
                    (function (e) {
                      if (Array.isArray(e)) return Ar(e);
                    })(e) ||
                    (function (e) {
                      if (
                        (typeof Symbol != "undefined" &&
                          e[
                            typeof Symbol == "function"
                              ? Symbol.iterator
                              : "@@iterator"
                          ] != null) ||
                        e["@@iterator"] != null
                      )
                        return Array.from(e);
                    })(e) ||
                    (function (e, t) {
                      if (e) {
                        if (typeof e == "string") return Ar(e, t);
                        var n = {}.toString.call(e).slice(8, -1);
                        return (
                          n === "Object" &&
                            e.constructor &&
                            (n = e.constructor.name),
                          n === "Map" || n === "Set"
                            ? Array.from(e)
                            : n === "Arguments" ||
                              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
                            ? Ar(e, t)
                            : void 0
                        );
                      }
                    })(e) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
                      );
                    })()
                  );
                }
                function Ar(e, t) {
                  (t == null || t > e.length) && (t = e.length);
                  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                  return r;
                }
                function Fr(e, t) {
                  var n = Object.keys(e);
                  if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t &&
                      (r = r.filter(function (t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                      })),
                      n.push.apply(n, r);
                  }
                  return n;
                }
                function Or(e) {
                  for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t] != null ? arguments[t] : {};
                    t % 2
                      ? Fr(Object(n), !0).forEach(function (t) {
                          Br(e, t, n[t]);
                        })
                      : Object.getOwnPropertyDescriptors
                      ? Object.defineProperties(
                          e,
                          Object.getOwnPropertyDescriptors(n)
                        )
                      : Fr(Object(n)).forEach(function (t) {
                          Object.defineProperty(
                            e,
                            t,
                            Object.getOwnPropertyDescriptor(n, t)
                          );
                        });
                  }
                  return e;
                }
                function Br(e, t, n) {
                  return (
                    (t = (function (e) {
                      var t = (function (e, t) {
                        if (Mr(e) != "object" || !e) return e;
                        var n =
                          e[
                            typeof Symbol == "function"
                              ? Symbol.toPrimitive
                              : "@@toPrimitive"
                          ];
                        if (n !== void 0) {
                          var r = n.call(e, t || "default");
                          if (Mr(r) != "object") return r;
                          throw new TypeError(
                            "@@toPrimitive must return a primitive value."
                          );
                        }
                        return (t === "string" ? String : Number)(e);
                      })(e, "string");
                      return Mr(t) == "symbol" ? t : t + "";
                    })(t)) in e
                      ? Object.defineProperty(e, t, {
                          value: n,
                          enumerable: !0,
                          configurable: !0,
                          writable: !0,
                        })
                      : (e[t] = n),
                    e
                  );
                }
                var Wr = kt.each,
                  qr = kt.filter,
                  Ur = kt.FBSet,
                  Vr = 500,
                  Hr = 12e4,
                  Gr = ["og:image"],
                  zr = [{ property: "image", type: "Product" }],
                  jr = ["gtin", "gtin8", "gtin12", "gtin13", "gtin14", "isbn"],
                  Kr = [
                    "product",
                    "https://schema.org/product",
                    "http://schema.org/product",
                  ],
                  Qr = [
                    "offer",
                    "https://schema.org/offer",
                    "http://schema.org/offer",
                  ],
                  Xr = [
                    "aggregateoffer",
                    "https://schema.org/aggregateoffer",
                    "http://schema.org/aggregateoffer",
                  ],
                  Yr = [
                    "aggregaterating",
                    "https://schema.org/aggregaterating",
                    "http://schema.org/aggregaterating",
                  ],
                  Jr = [
                    "brand",
                    "https://schema.org/brand",
                    "http://schema.org/brand",
                  ],
                  Zr = ["mpn"],
                  eo = ["name"],
                  to = ["description"],
                  no = ["aggregaterating"],
                  ro = ["availability"],
                  oo = ["price", "lowprice"],
                  ao = ["pricecurrency"],
                  io = ["sku", "productid", "@id"],
                  lo = ["offers", "offer"],
                  so = ["pricespecification"],
                  uo = ["url"],
                  co = ["itemcondition"],
                  mo = ["keywords"],
                  po = ["category"],
                  _o = ["brand"],
                  fo = [
                    "name",
                    "description",
                    "ids",
                    "aggregate_rating",
                    "item_condition",
                    "keywords",
                    "category",
                    "brand",
                  ];
                function go(e) {
                  return e.replace(/<[^>]+>/g, "");
                }
                function ho(e) {
                  var t = {
                    "&amp;": "&",
                    "&lt;": "<",
                    "&gt;": ">",
                    "&quot;": '"',
                    "&#39;": "'",
                    "&apos;": "'",
                  };
                  return e
                    .replace(/&(amp|lt|gt|quot|#39|apos);/g, function (e) {
                      var n;
                      return (n = t[e]) !== null && n !== void 0 ? n : e;
                    })
                    .replace(/&#x([0-9a-fA-F]+);/g, function (e, t) {
                      return String.fromCharCode(parseInt(t, 16));
                    })
                    .replace(/&#(\d+);/g, function (e, t) {
                      return String.fromCharCode(parseInt(t, 10));
                    });
                }
                function yo(e) {
                  return e.replace(/\s+/g, " ").trim();
                }
                function Co(e) {
                  if (e == null || typeof e != "string") return null;
                  var t = yo(ho(go(e)));
                  return t === "" ? null : t;
                }
                function bo(e, t) {
                  return zr.some(function (n) {
                    return (
                      (e === "https://schema.org/".concat(n.type) ||
                        e === "http://schema.org/".concat(n.type)) &&
                      n.property === t
                    );
                  });
                }
                function vo(e) {
                  return Object.keys(e).length === 0;
                }
                function So(e) {
                  for (
                    var t = {
                        automaticParameters: {},
                        productID: null,
                        productUrl: null,
                        productContents: [],
                        productUrls: [],
                      },
                      n = 0;
                    n < e.length;
                    n++
                  ) {
                    var r = e[n];
                    if (
                      ((t.automaticParameters = Ro(
                        t.automaticParameters,
                        r.automaticParameters
                      )),
                      (t.productContents = Lo(
                        t.productContents,
                        r.productContents
                      )),
                      r.productUrls != null)
                    )
                      for (var o = 0; o < r.productUrls.length; o++) {
                        var a = r.productUrls[o];
                        t.productUrls.includes(a) || t.productUrls.push(a);
                      }
                    r.productID != null &&
                      t.productID == null &&
                      (t.productID = r.productID),
                      r.productUrl != null &&
                        t.productUrl == null &&
                        (t.productUrl = r.productUrl);
                  }
                  return t;
                }
                function Ro(e, t) {
                  return (
                    t.currency != null && (e.currency = t.currency),
                    t.contents != null &&
                      Array.isArray(t.contents) &&
                      (e.contents == null
                        ? (e.contents = t.contents)
                        : (e.contents = e.contents.concat(t.contents))),
                    e
                  );
                }
                function Lo(e, t) {
                  return e == null
                    ? t || []
                    : t == null
                    ? e || []
                    : e.concat(t);
                }
                function Eo(e, t) {
                  var n = e.getAttribute(t);
                  return n == null || typeof n != "string" ? "" : n;
                }
                function ko(e, t, n) {
                  return (
                    !n.has(e) &&
                    !!t.contains(e) &&
                    (function (e, t) {
                      for (var n = e.parentElement; n != null; ) {
                        if (n.hasAttribute("itemscope")) {
                          var r = n.getAttribute("itemtype");
                          if (
                            typeof r == "string" &&
                            Kr.includes(r.toLowerCase())
                          )
                            return n;
                        }
                        if (n === t) return t;
                        n = n.parentElement;
                      }
                      return t;
                    })(e, t) === t
                  );
                }
                function Io(e) {
                  for (
                    var t = e.querySelectorAll("[itemprop]"), n = [], r = 0;
                    r < t.length;
                    r++
                  ) {
                    for (
                      var o = t[r], a = o.parentElement;
                      a != null && a !== e && !a.hasAttribute("itemscope");

                    )
                      a = a.parentElement;
                    a === e && n.push(o);
                  }
                  return n;
                }
                function To() {
                  var e =
                      arguments.length > 0 &&
                      arguments[0] !== void 0 &&
                      arguments[0],
                    n =
                      arguments.length > 1 &&
                      arguments[1] !== void 0 &&
                      arguments[1],
                    r = t.querySelectorAll("[itemscope]");
                  if (r.length === 0)
                    return { automaticParameters: {}, allProductContents: [] };
                  var o = qr(r, function (e) {
                    return Kr.includes(Eo(e, "itemtype").toLowerCase());
                  });
                  if (o.length === 0)
                    return { automaticParameters: {}, allProductContents: [] };
                  var a = {},
                    i = [];
                  return (
                    o.forEach(function (t) {
                      var r = (function (e) {
                        var t =
                            arguments.length > 2 &&
                            arguments[2] !== void 0 &&
                            arguments[2],
                          n = null,
                          r = null,
                          o = null,
                          a = null,
                          i = [
                            {
                              itempropsLowerCase: ["price"],
                              property: "item_price",
                              apply: function (t) {
                                return Vo(t);
                              },
                              getDefault: function () {
                                return null;
                              },
                              setDefault: function (t) {},
                            },
                            {
                              itempropsLowerCase: ["availability"],
                              property: "availability",
                              apply: function (t) {
                                return Qo(t);
                              },
                              getDefault: function () {
                                return null;
                              },
                              setDefault: function (t) {},
                            },
                            {
                              itempropsLowerCase: ["mpn"],
                              property: "mpn",
                              apply: function (t) {
                                return t;
                              },
                              getDefault: function () {
                                return r;
                              },
                              setDefault: function (t) {
                                r = t;
                              },
                            },
                            {
                              itempropsLowerCase: jr,
                              property: "gtin",
                              apply: function (t) {
                                return t;
                              },
                              getDefault: function () {
                                return o;
                              },
                              setDefault: function (t) {
                                o = t;
                              },
                            },
                            {
                              itempropsLowerCase: [
                                "productid",
                                "sku",
                                "product_id",
                              ],
                              property: "id",
                              apply: function (t) {
                                return t;
                              },
                              getDefault: function () {
                                return n;
                              },
                              setDefault: function (t) {
                                n = t;
                              },
                            },
                            {
                              itempropsLowerCase: ["pricecurrency"],
                              property: "currency",
                              apply: function (t) {
                                return null;
                              },
                              getDefault: function () {
                                return a;
                              },
                              setDefault: function (t) {
                                a = t;
                              },
                            },
                          ],
                          l = {};
                        if (
                          arguments.length > 1 &&
                          arguments[1] !== void 0 &&
                          arguments[1]
                        ) {
                          Io(e).forEach(function (e) {
                            var t = e.getAttribute("itemprop");
                            if (typeof t == "string" && t !== "") {
                              var n = d(e);
                              n != null &&
                                n !== "" &&
                                i.forEach(function (e) {
                                  var r = e.setDefault,
                                    o = e.itempropsLowerCase;
                                  (0, e.getDefault)() == null &&
                                    o.includes(t.toLowerCase()) &&
                                    r(n);
                                });
                            }
                          });
                          var s = qr(
                              e.querySelectorAll("[itemscope]"),
                              function (e) {
                                return Qr.includes(
                                  Eo(e, "itemtype").toLowerCase()
                                );
                              }
                            ),
                            u = [];
                          s.forEach(function (e) {
                            var t = {};
                            Io(e).forEach(function (e) {
                              var n = e.getAttribute("itemprop");
                              if (typeof n == "string" && n !== "") {
                                var r = d(e);
                                r != null &&
                                  r !== "" &&
                                  i.forEach(function (e) {
                                    var o = e.apply,
                                      a = e.property;
                                    if (
                                      e.itempropsLowerCase.includes(
                                        n.toLowerCase()
                                      )
                                    ) {
                                      var i = o(r);
                                      Ho(t, a, i);
                                    }
                                  });
                              }
                            }),
                              u.push(t);
                          }),
                            u.forEach(function (e) {
                              Ho(e, "mpn", e.mpn ? e.mpn : r),
                                Ho(e, "gtin", e.gtin ? e.gtin : o),
                                Ho(e, "id", e.id ? e.id : n);
                            }),
                            qo((l = { currency: a }), !0, u);
                        }
                        var c = {};
                        if (t)
                          for (
                            var m = e.querySelectorAll("[itemscope]"),
                              p = [e].concat(wr(m)),
                              _ = new Ur(),
                              f = p.length - 1;
                            f >= 0;
                            f--
                          ) {
                            var g = p[f],
                              h = g.getAttribute("itemtype");
                            if (
                              typeof h == "string" &&
                              h !== "" &&
                              (g === e || !Kr.includes(h.toLowerCase()))
                            )
                              for (var y = Io(g), C = 0; C < y.length; C++) {
                                var b = y[C];
                                if (ko(b, e, _)) {
                                  _.add(b);
                                  var v = b.getAttribute("itemprop");
                                  if (typeof v == "string" && v !== "") {
                                    var S = d(b);
                                    S != null && S !== "" && xo(c, h, v, S);
                                  }
                                }
                              }
                          }
                        return {
                          automaticParameters: l,
                          productContentData: c,
                        };
                      })(t, e, n);
                      (a = Ro(a, r.automaticParameters)),
                        n && i.push(r.productContentData);
                    }),
                    { automaticParameters: a, allProductContents: i }
                  );
                }
                function Do() {
                  var e =
                      arguments.length > 0 &&
                      arguments[0] !== void 0 &&
                      arguments[0],
                    n =
                      arguments.length > 2 &&
                      arguments[2] !== void 0 &&
                      arguments[2],
                    r = t.querySelectorAll("[itemscope]"),
                    o = [],
                    a = (function (e) {
                      for (var t = new Ur(), n = 0; n < e.length; n++)
                        t.add(e[n]);
                      return t;
                    })(r),
                    i = {},
                    l = {},
                    s = {
                      automaticParameters: {},
                      productID: null,
                      productUrl: null,
                      productContents: [],
                    },
                    u =
                      e || n
                        ? To(e, n)
                        : { automaticParameters: {}, allProductContents: [] },
                    c = u.automaticParameters,
                    m = u.allProductContents,
                    p = (function (e) {
                      for (
                        var t = e.scopes,
                          n = e.seenProperties,
                          r = e.scopeSchemas,
                          o = e.productMetadata,
                          a = e.contentData,
                          i = e.includeAutomaticParameters,
                          l = e.productContentData,
                          s = e.includeProductContent,
                          u = null,
                          c = null,
                          m = t.length - 1;
                        m >= 0;
                        m--
                      ) {
                        var p = t[m],
                          _ = p.getAttribute("itemtype");
                        if (typeof _ == "string" && _ !== "") {
                          for (
                            var f = {},
                              g = p.querySelectorAll("[itemprop]"),
                              h = 0;
                            h < g.length;
                            h++
                          ) {
                            var y = g[h];
                            if (!n.has(y)) {
                              n.add(y);
                              var C = y.getAttribute("itemprop");
                              if (typeof C == "string" && C !== "") {
                                var b = d(y);
                                if (b != null && b !== "") {
                                  var v = f[C];
                                  v != null && bo(_, C)
                                    ? Array.isArray(v)
                                      ? f[C].push(b)
                                      : (f[C] = [v, b])
                                    : (o.productID == null &&
                                        (C.toLowerCase() === "productid"
                                          ? (u = b)
                                          : C.toLowerCase() === "sku" &&
                                            (c = b)),
                                      o.productUrl == null &&
                                        C === "url" &&
                                        (o.productUrl = b),
                                      i && $o(a, o, C, b),
                                      s && xo(l, _, C, b),
                                      (f[C] = b));
                                }
                              }
                            }
                          }
                          r.unshift({
                            schema: {
                              dimensions: {
                                h: p.clientHeight,
                                w: p.clientWidth,
                              },
                              properties: f,
                              subscopes: [],
                              type: _,
                            },
                            scope: p,
                          });
                        }
                      }
                      return { localProductID: u, SKU: c };
                    })({
                      scopes: r,
                      seenProperties: a,
                      scopeSchemas: o,
                      productMetadata: s,
                      contentData: i,
                      includeAutomaticParameters: e,
                      productContentData: l,
                      includeProductContent: n,
                    });
                  (function (e, t, n) {
                    t != null
                      ? (e.productID = t)
                      : n != null && (e.productID = n);
                  })(s, p.localProductID, p.SKU),
                    c.contents == null && (c.contents = []),
                    c.contents.push(i),
                    qo(s.automaticParameters, e, c.contents),
                    Uo(s.productContents, n, [].concat(wr(m), [l]));
                  var _ = (function (e) {
                    for (var t = [], n = [], r = 0; r < e.length; r++) {
                      for (
                        var o = e[r],
                          a = o.scope,
                          i = o.schema,
                          l = n.length - 1;
                        l >= 0;
                        l--
                      ) {
                        if (n[l].scope.contains(a)) {
                          n[l].schema.subscopes.push(i);
                          break;
                        }
                        n.pop();
                      }
                      n.length === 0 && t.push(i),
                        n.push({ schema: i, scope: a });
                    }
                    return t;
                  })(o);
                  return { extractedProperties: _, productMetadata: s };
                }
                function xo(e, t, n, r) {
                  var o,
                    a = n.toLowerCase();
                  (a !== "productid" && a !== "sku") ||
                    (e.ids == null
                      ? (e.ids = [r])
                      : e.ids.includes(r) || e.ids.push(r)),
                    Kr.includes(t.toLowerCase()) &&
                      a === "name" &&
                      (e.name = r),
                    Kr.includes(t.toLowerCase()) &&
                      a === "description" &&
                      (e.description =
                        (o = Co(r)) !== null && o !== void 0 ? o : r),
                    Yr.includes(t.toLowerCase()) &&
                      (e.aggregate_rating == null && (e.aggregate_rating = {}),
                      a === "ratingvalue"
                        ? (e.aggregate_rating.ratingValue = r)
                        : a === "ratingcount"
                        ? (e.aggregate_rating.ratingCount = r)
                        : a === "reviewcount"
                        ? (e.aggregate_rating.reviewCount = r)
                        : a === "bestrating"
                        ? (e.aggregate_rating.bestRating = r)
                        : a === "worstrating" &&
                          (e.aggregate_rating.worstRating = r)),
                    Qr.includes(t.toLowerCase()) &&
                      e.item_condition == null &&
                      n === "itemCondition" &&
                      Ho(e, "item_condition", Qo(r)),
                    Kr.includes(t.toLowerCase()) &&
                      e.keywords == null &&
                      n === "keywords" &&
                      (e.keywords = r),
                    Jr.includes(t.toLowerCase()) &&
                      e.brand == null &&
                      n === "name" &&
                      (e.brand = r),
                    Kr.includes(t.toLowerCase()) &&
                      (e.category == null &&
                        n === "category" &&
                        (e.category = r),
                      e.brand == null && n === "brand" && (e.brand = r));
                }
                function $o(e, t, n, r) {
                  var o = n.toLowerCase();
                  t.automaticParameters.currency == null &&
                    o === "pricecurrency" &&
                    (t.automaticParameters.currency = r),
                    e.id != null ||
                      (o !== "productid" && o !== "sku") ||
                      (e.id = r),
                    e.mpn == null && o === "mpn" && (e.mpn = r),
                    e.gtin == null && jr.includes(o) && (e.gtin = r),
                    e.item_price == null &&
                      o === "price" &&
                      Ho(e, "item_price", Vo(r)),
                    e.availability == null &&
                      o === "availability" &&
                      Ho(e, "availability", Qo(r));
                }
                function Po(e, t) {
                  if (e == null) return { content: [], currency: null };
                  var n = {},
                    r = (function (e) {
                      var t = { price: null, currency: null };
                      if (e == null) return t;
                      (t.price = Vo(zo(e, oo))), (t.currency = zo(e, ao));
                      var n = (function (e) {
                        var t = { price: null, currency: null };
                        return e == null
                          ? t
                          : Array.isArray(e)
                          ? (e.length === 0 ||
                              Wr(e, function (e) {
                                e.priceCurrency != null &&
                                  (t.currency = zo(e, ao)),
                                  (t.price = (function (e, t) {
                                    return e == null
                                      ? t
                                      : t == null
                                      ? e
                                      : e > t
                                      ? t
                                      : e;
                                  })(Vo(zo(e, oo)), t.price));
                              }),
                            t)
                          : ((t.price = Vo(zo(e, oo))),
                            (t.currency = zo(e, ao)),
                            t);
                      })(zo(e, so));
                      return (
                        t.price == null && (t.price = n.price),
                        t.currency == null && (t.currency = n.currency),
                        t
                      );
                    })(e),
                    o = zo(e, Zr, t.mpn),
                    a = zo(e, jr, t.gtin);
                  Ho(n, "mpn", o),
                    Ho(n, "gtin", a),
                    Ho(n, "item_price", r.price),
                    Ho(n, "availability", Qo(zo(e, ro)));
                  var i = (function (e, t) {
                      var n =
                          arguments.length > 2 && arguments[2] !== void 0
                            ? arguments[2]
                            : null,
                        r = [];
                      if ((n && r.push(n), Mr(e) !== "object")) return r;
                      var o = [];
                      return (
                        Wr(Object.keys(e), function (n) {
                          t.includes(n.toLowerCase()) &&
                            Go(e[n]) &&
                            o.push(e[n]);
                        }),
                        o.length > 0 ? o : r
                      );
                    })(e, io, t.id),
                    l = (function (e, t) {
                      var n = [];
                      return (
                        t.forEach(function (t) {
                          if (t != null) {
                            var r = Or({}, e);
                            (r.id = t), n.push(r);
                          }
                        }),
                        n.length !== 0 || vo(e) || n.push(e),
                        n
                      );
                    })(n, i);
                  return { content: l, currency: r.currency };
                }
                function No() {
                  for (
                    var e =
                        arguments.length > 0 &&
                        arguments[0] !== void 0 &&
                        arguments[0],
                      n =
                        arguments.length > 1 &&
                        arguments[1] !== void 0 &&
                        arguments[1],
                      r = arguments.length > 2 ? arguments[2] : void 0,
                      o =
                        arguments.length > 3 &&
                        arguments[3] !== void 0 &&
                        arguments[3],
                      a = {
                        automaticParameters: {},
                        productID: null,
                        productUrl: null,
                        productContents: [],
                      },
                      i = [],
                      l = [],
                      s = t.querySelectorAll(
                        'script[type="application/ld+json"]'
                      ),
                      u = 0,
                      c = [],
                      d = {},
                      m = 0;
                    m < s.length;
                    m++
                  ) {
                    var p = s[m].textContent || s[m].innerText;
                    if (p != null && p !== "")
                      try {
                        if ((u += p.length) > Hr)
                          return (
                            qo(a.automaticParameters, e, c),
                            Uo(a.productContents, o, [d]),
                            {
                              extractedProperties: i,
                              invalidInnerTexts: l,
                              productMetadata: a,
                            }
                          );
                        for (var _ = Mo(p, n), f = 0; f < _.length; f++) {
                          var g = _[f];
                          Bo(_, zo(g, ["mainentity"])),
                            Bo(_, zo(g, ["@graph"])),
                            Bo(_, zo(g, ["hasvariant"]));
                          var h = {},
                            y = wo({
                              json: g,
                              productMetadata: a,
                              contentData: h,
                              includeAutomaticParameters: e,
                              productContentData: d,
                              includeProductContent: o,
                              logInfo: r,
                            }),
                            C = y.isTypeProduct,
                            b = y.offers;
                          if ((a.productUrl == null || C) && b != null) {
                            var v = Fo({
                              offers: b,
                              productMetadata: a,
                              contentData: h,
                              includeAutomaticParameters: e,
                              productContentData: d,
                              includeProductContent: o,
                              logInfo: r,
                            });
                            c = c.concat(v);
                          }
                          i.push(g);
                        }
                      } catch (e) {
                        l.push(p);
                      }
                  }
                  return (
                    qo(a.automaticParameters, e, c),
                    Uo(a.productContents, o, [d]),
                    {
                      extractedProperties: i,
                      invalidInnerTexts: l,
                      productMetadata: a,
                    }
                  );
                }
                function Mo(e, t) {
                  var n = null;
                  n = oa(e);
                  try {
                    n = JSON.parse(n.replace(/[\n\r\t]+/g, " "));
                  } catch (e) {
                    if (!t) throw e;
                    try {
                      (n = aa(n)),
                        (n = JSON.parse(n.replace(/[\n\r\t]+/g, " ")));
                    } catch (t) {
                      throw new Error(
                        "Failed to parse JSON even after repair attempt. Original error: ".concat(
                          e.message
                        )
                      );
                    }
                  }
                  return Array.isArray(n) || (n = [n]), n;
                }
                function wo(e) {
                  var t = e.json,
                    n = e.productMetadata,
                    r = e.contentData,
                    o = e.includeAutomaticParameters,
                    a = e.productContentData,
                    i = e.includeProductContent,
                    l = Wo(t),
                    s = Kr.includes(l),
                    u = zo(t, lo);
                  if (!s) return { isTypeProduct: s, offers: u };
                  var c = zo(t, io);
                  if (
                    ((n.productID != null && n.productID !== "") ||
                      (n.productID = c),
                    o &&
                      (Ho(r, "id", c),
                      Ho(r, "mpn", zo(t, Zr)),
                      Ho(r, "gtin", zo(t, jr))),
                    i)
                  ) {
                    c &&
                      (a.ids == null
                        ? (a.ids = [c])
                        : a.ids.includes(c) || a.ids.push(c)),
                      Ho(a, "name", zo(t, eo)),
                      Ho(a, "description", Co(zo(t, to))),
                      Ho(a, "aggregate_rating", zo(t, no)),
                      Ho(a, "keywords", zo(t, mo)),
                      Ho(a, "category", zo(t, po));
                    var d = zo(t, _o);
                    typeof d == "string"
                      ? (a.brand = d)
                      : Ho(a, "brand", zo(d, eo));
                  }
                  return Oo(t, n), Ao(t, n), { isTypeProduct: s, offers: u };
                }
                function Ao(e, t) {
                  var n = zo(e, uo);
                  n != null &&
                    n !== "" &&
                    (t.productUrls == null && (t.productUrls = []),
                    t.productUrls.push(n));
                }
                function Fo(e) {
                  var t = e.offers,
                    n = e.productMetadata,
                    r = e.contentData,
                    o = e.includeAutomaticParameters,
                    a = e.productContentData,
                    i = e.includeProductContent,
                    l = [],
                    s = [];
                  if (Array.isArray(t)) s = t;
                  else {
                    var u = Wo(t),
                      c = Qr.includes(u),
                      d = Xr.includes(u);
                    (c || d) && (s = [t]);
                  }
                  return (
                    s.length === 0 ||
                      Wr(s, function (e) {
                        if ((Oo(e, n), Ao(e, n), o)) {
                          var t = Po(e, r);
                          n.automaticParameters.currency == null &&
                            (n.automaticParameters.currency = t.currency),
                            (l = l.concat(t.content));
                        }
                        i &&
                          ((function (e, t) {
                            if (e != null) {
                              var n = zo(e, io);
                              n != null &&
                                (t.ids == null
                                  ? (t.ids = [n])
                                  : t.ids.includes(n) || t.ids.push(n));
                            }
                          })(e, a),
                          (function (e, t, n) {
                            e != null &&
                              Ho(
                                t,
                                "item_condition",
                                Qo(zo(e, co, n.item_condition))
                              );
                          })(e, a, r));
                      }),
                    l
                  );
                }
                function Oo(e, t) {
                  var n = zo(e, uo);
                  (t.productUrl != null && t.productUrl !== "") ||
                    (t.productUrl = n);
                }
                function Bo(e, t) {
                  if (t != null) {
                    var n = t;
                    Array.isArray(t) || (n = [t]), e.push.apply(e, wr(n));
                  }
                }
                function Wo(e) {
                  return e == null
                    ? ""
                    : typeof e["@type"] == "string" && e["@type"] != null
                    ? e["@type"].toLowerCase()
                    : "";
                }
                function qo(e, t, n) {
                  if (t) {
                    var r = n.filter(function (e) {
                      return !vo(e);
                    });
                    r.length !== 0 && (e.contents = r);
                  }
                }
                function Uo(e, t, n) {
                  if (t) {
                    var r = n
                      .map(function (e) {
                        return (function (e) {
                          for (
                            var t = {}, n = 0, r = Object.keys(e);
                            n < r.length;
                            n++
                          ) {
                            var o = r[n];
                            fo.includes(o) && (t[o] = e[o]);
                          }
                          return t;
                        })(e);
                      })
                      .filter(function (e) {
                        return !vo(e);
                      });
                    r.length !== 0 && e.push.apply(e, wr(r));
                  }
                }
                function Vo(e) {
                  if (typeof e == "string") {
                    var t = parseFloat(e.replace(/[^0-9.]/g, ""));
                    return isNaN(t) ? null : t;
                  }
                  return typeof e == "number" ? e : null;
                }
                function Ho(e, t, n) {
                  n != null && (e[t] = n);
                }
                function Go(e) {
                  return e != null && (typeof e != "string" || e !== "");
                }
                function zo(e, t) {
                  var n =
                    arguments.length > 2 && arguments[2] !== void 0
                      ? arguments[2]
                      : null;
                  if (e == null || Mr(e) !== "object") return n;
                  var r = Object.keys(e),
                    o = {};
                  Wr(r, function (n) {
                    t.includes(n.toLowerCase()) && (o[n.toLowerCase()] = e[n]);
                  });
                  var a = t.find(function (e) {
                    return Go(o[e]);
                  });
                  return a ? o[a] : n;
                }
                function jo(e, t, n, r, o, a, i) {
                  var l,
                    s =
                      arguments.length > 7 &&
                      arguments[7] !== void 0 &&
                      arguments[7],
                    u = null,
                    c = null,
                    d = !1,
                    m = n[e];
                  return (
                    m != null && ((l = e), Gr.includes(l))
                      ? Array.isArray(m)
                        ? n[e].push(t)
                        : (n[e] = [m, t])
                      : (t &&
                          ((r.productID != null && r.productID !== "") ||
                            (e === "product:retailer_item_id" &&
                              ((u = t), (d = !0)),
                            e === "product:sku" && ((c = t), (d = !0))),
                          (r.productUrl != null && r.productUrl !== "") ||
                            e !== "og:url" ||
                            (r.productUrl = t),
                          e === "og:type" &&
                            t.toLowerCase().includes("product") &&
                            (d = !0),
                          s &&
                            (function (e, t, n) {
                              var r;
                              n.name != null ||
                                (e !== "product:name" && e !== "og:title") ||
                                (n.name = t),
                                n.description != null ||
                                  (e !== "product:description" &&
                                    e !== "og:description") ||
                                  (n.description =
                                    (r = Co(t)) !== null && r !== void 0
                                      ? r
                                      : t),
                                (e !== "product:retailer_item_id" &&
                                  e !== "product:sku") ||
                                  (n.ids == null
                                    ? (n.ids = [t])
                                    : n.ids.includes(t) || n.ids.push(t)),
                                (e !== "product:brand" && e !== "og:brand") ||
                                  (n.brand = t),
                                (e !== "product:category" &&
                                  e !== "og:category") ||
                                  (n.category = t),
                                n.item_condition != null ||
                                  (e !== "product:condition" &&
                                    e !== "og:condition") ||
                                  Ho(n, "item_condition", Qo(t)),
                                n.keywords != null ||
                                  (e !== "product:keywords" &&
                                    e !== "og:keywords") ||
                                  (n.keywords = t);
                            })(e, t, i),
                          a &&
                            (function (e, t, n, r) {
                              n.automaticParameters.currency != null ||
                                (e !== "product:price:currency" &&
                                  e !== "og:price:currency") ||
                                (n.automaticParameters.currency = t),
                                r.id != null ||
                                  (e !== "product:retailer_item_id" &&
                                    e !== "product:sku") ||
                                  (r.id = t),
                                r.mpn == null &&
                                  e === "product:mfr_part_no" &&
                                  (r.mpn = t),
                                r.gtin == null &&
                                  jr
                                    .map(function (e) {
                                      return "product:".concat(e);
                                    })
                                    .includes(e) &&
                                  (r.gtin = t),
                                r.item_price != null ||
                                  (e !== "product:price:amount" &&
                                    e !== "og:price:amount") ||
                                  Ho(r, "item_price", Vo(t)),
                                r.availability != null ||
                                  (e !== "product:availability" &&
                                    e !== "og:availability") ||
                                  Ho(r, "availability", Qo(t));
                            })(e, t, r, o)),
                        (n[e] = t)),
                    { productRetailerItemID: u, productSKU: c, isProduct: d }
                  );
                }
                function Ko() {
                  for (
                    var e =
                        arguments.length > 0 &&
                        arguments[0] !== void 0 &&
                        arguments[0],
                      n =
                        arguments.length > 2 &&
                        arguments[2] !== void 0 &&
                        arguments[2],
                      r = {
                        automaticParameters: {},
                        productID: null,
                        productUrl: null,
                        productContents: [],
                      },
                      o = new Ur([
                        "og",
                        "product",
                        "music",
                        "video",
                        "article",
                        "book",
                        "profile",
                        "website",
                        "twitter",
                      ]),
                      a = {},
                      i = null,
                      l = null,
                      s = !1,
                      u = {},
                      c = {},
                      d = t.querySelectorAll("meta[property]"),
                      m = 0;
                    m < d.length;
                    m++
                  ) {
                    var p = d[m],
                      _ = p.getAttribute("property"),
                      f = p.getAttribute("content");
                    if (
                      typeof _ == "string" &&
                      _.indexOf(":") !== -1 &&
                      typeof f == "string" &&
                      o.has(_.split(":")[0])
                    ) {
                      var g = jo(_, Be(f, Vr), a, r, u, e, c, n);
                      g.productRetailerItemID && (i = g.productRetailerItemID),
                        g.productSKU && (l = g.productSKU),
                        g.isProduct === !0 && (s = !0);
                    }
                  }
                  return (
                    i != null
                      ? (r.productID = i)
                      : l != null && (r.productID = l),
                    qo(r.automaticParameters, e, [u]),
                    s && Uo(r.productContents, n, [c]),
                    { extractedProperties: a, productMetadata: r }
                  );
                }
                function Qo(e) {
                  if (typeof e != "string" && !(e instanceof String))
                    return null;
                  var t = e.split("/");
                  return t.length > 0 ? t[t.length - 1] : "";
                }
                var Xo = { description: !0, keywords: !0 };
                function Yo() {
                  var e =
                      arguments.length > 0 &&
                      arguments[0] !== void 0 &&
                      arguments[0],
                    n = t.querySelector("title"),
                    r = n && (n.textContent || n.innerText);
                  if (e && (!r || r.trim() === "")) {
                    var o = t.querySelector('meta[property="og:title"]');
                    if (o) {
                      var a = o.getAttribute("content");
                      a && (r = a);
                    }
                  }
                  var i = { title: Be(r, Vr) },
                    l = (function () {
                      var e = t.querySelector('meta[property="og:locale"]');
                      if (e != null) {
                        var n = e.getAttribute("content");
                        if (n != null && n !== "") return n.substring(0, Jo);
                      }
                      var r = t.documentElement;
                      if (r != null) {
                        var o = r.getAttribute("lang");
                        if (o != null && o !== "") return o.substring(0, Jo);
                      }
                      var a = t.querySelector(
                        'meta[http-equiv="content-language"]'
                      );
                      if (a != null) {
                        var i = a.getAttribute("content");
                        if (i != null && i !== "") return i.substring(0, Jo);
                      }
                      return null;
                    })();
                  l != null && (i.locale = l);
                  for (
                    var s = t.querySelectorAll("meta[name]"), u = 0;
                    u < s.length;
                    u++
                  ) {
                    var c = s[u],
                      d = c.getAttribute("name"),
                      m = c.getAttribute("content");
                    typeof d == "string" &&
                      typeof m == "string" &&
                      Xo[d] &&
                      (i[d] = Be(m, Vr));
                  }
                  return i;
                }
                var Jo = 50;
                function Zo(e) {
                  return String(e).replace(/\s+/g, " ").trim().toLowerCase();
                }
                function ea(e, t) {
                  var n = e.name,
                    r = t.name;
                  if (n != null && r != null) {
                    var o = Zo(n),
                      a = Zo(r);
                    if (o !== "" && a !== "" && o === a) return !0;
                  }
                  var i = e.ids,
                    l = t.ids;
                  if (Array.isArray(i) && Array.isArray(l)) {
                    for (
                      var s = l.map(function (e) {
                          return Zo(e);
                        }),
                        u = 0;
                      u < i.length;
                      u++
                    )
                      if (s.includes(Zo(i[u]))) return !0;
                  }
                  return !1;
                }
                function ta(e, t) {
                  if (e === t) return !0;
                  if (e == null || t == null) return e == null && t == null;
                  if (Mr(e) !== Mr(t)) return !1;
                  if (typeof e == "string" && typeof t == "string")
                    return Zo(e) === Zo(t);
                  if (Mr(e) === "object" && Mr(t) === "object") {
                    var n = Object.keys(e),
                      r = Object.keys(t);
                    if (n.length !== r.length) return !1;
                    for (var o = 0; o < n.length; o++) {
                      var a = n[o];
                      if (!ta(e[a], t[a])) return !1;
                    }
                    return !0;
                  }
                  return !1;
                }
                function na(e, t) {
                  var n,
                    r,
                    o,
                    a,
                    i,
                    l = {},
                    s =
                      ((n = e.ids),
                      (r = t.ids),
                      (o = []),
                      (a = new Ur()),
                      (i = function (t) {
                        if (Array.isArray(t))
                          for (var e = 0; e < t.length; e++) {
                            var n = Zo(t[e]);
                            a.has(n) || (a.add(n), o.push(t[e]));
                          }
                      }),
                      i(n),
                      i(r),
                      o);
                  s.length > 0 && (l.ids = s);
                  for (var u = 0; u < fo.length; u++) {
                    var c = fo[u];
                    if (c !== "ids") {
                      var d = e[c],
                        m = t[c];
                      if (d != null || m != null)
                        if (d == null) l[c] = m;
                        else if (m == null) l[c] = d;
                        else if (ta(d, m)) l[c] = d;
                        else {
                          if (
                            c !== "description" ||
                            typeof d != "string" ||
                            typeof m != "string"
                          )
                            return null;
                          var p = Zo(d),
                            _ = Zo(m);
                          if (p.includes(_)) l[c] = d;
                          else {
                            if (!_.includes(p)) return null;
                            l[c] = m;
                          }
                        }
                    }
                  }
                  return l;
                }
                function ra(e) {
                  if (e.length <= 1) return e;
                  for (var t = [], n = 0; n < e.length; n++) {
                    for (var r = e[n], o = !1, a = 0; a < t.length; a++)
                      if (ea(r, t[a])) {
                        var i = na(t[a], r);
                        if (i != null) {
                          (t[a] = i), (o = !0);
                          break;
                        }
                      }
                    o || t.push(Or({}, r));
                  }
                  return t;
                }
                function oa(e) {
                  return e == null
                    ? null
                    : e.replace(
                        /\\"|\"(?:\\"|[^\"])*\"|(\/\/.*|\/\*[\s\S]*?\*\/)/g,
                        function (e, t) {
                          return t ? "" : e;
                        }
                      );
                }
                function aa(e) {
                  if (e == null) return null;
                  try {
                    return Pr(e);
                  } catch (t) {
                    return e;
                  }
                }
                function ia() {
                  return {
                    extractedProperties: [],
                    productMetadata: {
                      automaticParameters: {},
                      productID: null,
                      productUrl: null,
                      productContents: [],
                      productUrls: [],
                    },
                  };
                }
                var la = l,
                  sa = s;
                o.exports = i;
              })();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsShopifySandboxConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    enableSandboxProviders: t.boolean(),
                    sandboxProviderRollout: t.boolean(),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsShopifySandboxContextConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    pixelId: t.string(),
                    runtimeContext: t.string(),
                    browser: t.allowNull(t.object()),
                    context: t.object(),
                    initialCookies: t.identity(),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("signalsFBEventsShopifyUtil", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                t = e.coerce,
                n = e.Typed,
                r = a.getFbeventsModules("signalsFBEventsFeatureGate"),
                i = a.getFbeventsModules("SignalsFBEventsLogging"),
                l = i.logError,
                s = ["collection_viewed", "cart_viewed"];
              function u(e, r) {
                if (e !== "ViewContent") return !1;
                var o = t(
                  r,
                  n.objectWithFields({
                    shopify_event_name: n.allowNull(n.string()),
                  })
                );
                return (
                  (o == null ? void 0 : o.shopify_event_name) != null &&
                  s.includes(o.shopify_event_name)
                );
              }
              function c(e, o, a, i, s) {
                i = i || {};
                try {
                  if (s == null || Object.keys(s).length === 0 || !e) return i;
                  var u = r("content_type_opt", o),
                    c = r("enable_product_variant_id", o),
                    d = r("enable_shopify_payment_fields", o),
                    m = r("enable_shopify_search_contents", o),
                    p = t(
                      s,
                      n.objectWithFields({
                        product_variant_ids: n.allowNull(
                          n.arrayOf(n.stringOrNumber())
                        ),
                        content_type_favor_variant: n.allowNull(n.string()),
                        contents: n.allowNull(
                          n.arrayOf(n.allowNull(n.object()))
                        ),
                        order_id: n.allowNull(n.stringOrNumber()),
                        payment_method: n.allowNull(
                          n.objectWithFields({
                            gateway: n.allowNull(n.string()),
                            name: n.allowNull(n.string()),
                            type: n.allowNull(n.string()),
                          })
                        ),
                      })
                    );
                  return p == null
                    ? i
                    : (p.order_id != null && (i.order_id = p.order_id),
                      d &&
                        p.payment_method != null &&
                        (i.payment_method = p.payment_method),
                      a === "Search"
                        ? (m &&
                            p.contents != null &&
                            p.contents.length > 0 &&
                            (i.contents = p.contents),
                          i)
                        : (c
                            ? p.contents != null &&
                              p.contents.length > 0 &&
                              (i.contents = p.contents)
                            : u &&
                              ((i.content_ids = p.product_variant_ids),
                              (i.content_type = p.content_type_favor_variant)),
                          i));
                } catch (e) {
                  return (e.message = "[Shopify]: ".concat(e.message)), l(e), i;
                }
              }
              o.exports = {
                isIncrementalShopifyEvent: u,
                updateContentDataForShopify: c,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsShouldRestrictReferrerEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsEventPayload"),
                  t = a.getFbeventsModules("SignalsFBEventsBaseEvent");
                function n(t) {
                  var n = t instanceof e ? t : null;
                  return n != null ? [n] : null;
                }
                var r = new t(n);
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsSmartSetupPixelConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    type: t.string(),
                    selector: t.string(),
                    key: t.string(),
                  }),
                  r = t.objectWithFields({
                    rules: t.allowNull(t.mapOf(t.allowNull(n))),
                    maxEntriesPerKey: t.allowNull(t.number()),
                    maxValueLength: t.allowNull(t.number()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("signalsFBEventsSPANavigationUtil", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              var a = n.href,
                i = t.referrer;
              function l(e) {
                s(e), u(e);
              }
              function s(t) {
                if (
                  t.fbq.disablePushState !== !0 &&
                  !(!r.pushState || !r.replaceState)
                ) {
                  var o = t.makeSafe(function () {
                    t.automaticPageView.trigger(),
                      (i = a),
                      (a = n.href),
                      a !== i && t.onPageChange();
                  });
                  t.injectMethod(r, "pushState", o),
                    t.injectMethod(r, "replaceState", o),
                    e.addEventListener("popstate", o, !1);
                }
              }
              function u(t) {
                "onpageshow" in e &&
                  e.addEventListener("pageshow", function (e) {
                    e.persisted &&
                      (t.automaticPageView.trigger(), t.onPageChange());
                  });
              }
              o.exports = { setupSPANavigation: l };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsStandardParamChecksConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    standardParamChecks: t.allowNull(
                      t.mapOf(
                        t.allowNull(
                          t.arrayOf(
                            t.allowNull(
                              t.objectWithFields({
                                require_exact_match: t.boolean(),
                                potential_matches: t.allowNull(
                                  t.arrayOf(t.string())
                                ),
                              })
                            )
                          )
                        )
                      )
                    ),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsTelemetry", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsLogging"),
                n = a.getFbeventsModules("SignalsEventPayload"),
                r = a.getFbeventsModules("signalsFBEventsSendGET"),
                i = 0.01,
                l = Math.random(),
                s =
                  e.fbq && e.fbq._releaseSegment
                    ? e.fbq._releaseSegment
                    : "unknown",
                u = l < i || s === "canary",
                c = "https://connect.facebook.net/log/fbevents_telemetry/";
              function d(o) {
                var a =
                    arguments.length > 1 && arguments[1] !== void 0
                      ? arguments[1]
                      : 0,
                  i =
                    arguments.length > 2 && arguments[2] !== void 0
                      ? arguments[2]
                      : !1;
                if (!(!i && !u))
                  try {
                    var l = new n();
                    l.append(
                      "v",
                      e.fbq && e.fbq.version ? e.fbq.version : "unknown"
                    ),
                      l.append("rs", s),
                      l.append("e", o),
                      l.append("p", String(a)),
                      r(l, { ignoreRequestLengthCheck: !0, url: c });
                  } catch (e) {
                    t.logError(e);
                  }
              }
              function m(e) {
                d("FBMQ_FORWARDED", e, !0);
              }
              o.exports = { logMobileNativeForwarding: m };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsTrackEventEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsTyped"),
                n = t.Typed,
                r = n.objectWithFields({
                  pixelID: n.allowNull(n.string()),
                  eventName: n.string(),
                  customData: n.allowNull(n.object()),
                  eventData: n.allowNull(n.object()),
                  eventId: n.allowNull(n.string()),
                }),
                i = new e(n.tuple([r]));
              o.exports = i;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsTriggerSgwPixelTrackCommandConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    sgwPixelId: t.allowNull(t.string()),
                    sgwHostUrl: t.allowNull(t.string()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsTyped", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            l = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                t = e.reduce,
                n = a.getFbeventsModules("SignalsFBEventsUtils"),
                r = n.isSafeInteger,
                l = (function (e) {
                  function t() {
                    var e,
                      n =
                        arguments.length > 0 && arguments[0] !== void 0
                          ? arguments[0]
                          : "",
                      r = arguments.length > 1 ? arguments[1] : void 0;
                    $(this, t);
                    var o = r != null ? "".concat(r, ": ").concat(n) : n;
                    return (
                      (e = i(this, t, [o])),
                      (e.name = "FBEventsCoercionError"),
                      e
                    );
                  }
                  return u(t, e), N(t);
                })(c(Error));
              function s(e) {
                return Object.values(e);
              }
              function d() {
                return function (e) {
                  if (typeof e != "boolean")
                    throw new l(
                      "Expected boolean, got ".concat(G(e)),
                      "Typed.boolean"
                    );
                  return e;
                };
              }
              function m() {
                return function (e) {
                  if (typeof e != "number")
                    throw new l(
                      "Expected number, got ".concat(G(e)),
                      "Typed.number"
                    );
                  return e;
                };
              }
              function p() {
                return function (e) {
                  return e;
                };
              }
              function _() {
                return function (e) {
                  if (typeof e == "string") return e;
                  if (G(e) === "object" && e !== null)
                    try {
                      return JSON.stringify(e);
                    } catch (e) {
                      throw new l(
                        "Expected string, got object that cannot be stringified",
                        "Typed.string"
                      );
                    }
                  throw new l(
                    "Expected string, got ".concat(G(e)),
                    "Typed.string"
                  );
                };
              }
              function f() {
                return function (e) {
                  var t = P(e, W.string());
                  return t.toLowerCase();
                };
              }
              function g() {
                return function (e) {
                  if (typeof e != "string" && typeof e != "number")
                    throw new l(
                      "Expected string or number, got ".concat(G(e)),
                      "Typed.stringOrNumber"
                    );
                  return e;
                };
              }
              function h() {
                return function (e) {
                  if (G(e) !== "object" || Array.isArray(e) || e == null)
                    throw new l(
                      "Expected object, got "
                        .concat(G(e))
                        .concat(Array.isArray(e) ? " (array)" : ""),
                      "Typed.object"
                    );
                  return e;
                };
              }
              function y() {
                return function (e) {
                  if (G(e) !== "object" || Array.isArray(e) || e == null)
                    throw new l(
                      "Expected object, got "
                        .concat(G(e))
                        .concat(Array.isArray(e) ? " (array)" : ""),
                      "Typed.mutableObject"
                    );
                  return v({}, e);
                };
              }
              function C() {
                return function (e) {
                  if (G(e) !== "object" || Array.isArray(e) || e == null)
                    throw new l(
                      "Expected object, got "
                        .concat(G(e))
                        .concat(Array.isArray(e) ? " (array)" : ""),
                      "Typed.stringRecord"
                    );
                  for (
                    var t = {}, n = 0, r = Object.keys(e);
                    n < r.length;
                    n++
                  ) {
                    var o = r[n],
                      a = e[o];
                    if (typeof a != "string")
                      throw new l(
                        'Expected all values to be strings, but key "'
                          .concat(o, '" has type ')
                          .concat(G(a)),
                        "Typed.stringRecord"
                      );
                    t[o] = a;
                  }
                  return t;
                };
              }
              function b() {
                return function (e) {
                  if (
                    (G(e) !== "object" && typeof e != "string") ||
                    Array.isArray(e) ||
                    e == null
                  )
                    throw new l(
                      "Expected object or string, got "
                        .concat(G(e))
                        .concat(Array.isArray(e) ? " (array)" : ""),
                      "Typed.objectOrString"
                    );
                  return e;
                };
              }
              function R() {
                return function (e) {
                  if (typeof e != "function" || e == null)
                    throw new l(
                      "Expected function, got ".concat(G(e)),
                      "Typed.func"
                    );
                  return e;
                };
              }
              function L() {
                return function (e) {
                  if (e == null || !Array.isArray(e))
                    throw new l(
                      "Expected array, got ".concat(G(e)),
                      "Typed.array"
                    );
                  return e;
                };
              }
              function E(e) {
                return function (t) {
                  if (s(e).includes(t)) return t;
                  throw new l(
                    "Expected one of ["
                      .concat(s(e).join(", "), "], got ")
                      .concat(String(t)),
                    "Typed.enumeration"
                  );
                };
              }
              function k(e) {
                return function (t) {
                  return P(t, W.array()).map(e);
                };
              }
              function I(e) {
                return function (n) {
                  var r = P(n, W.object());
                  return t(
                    Object.keys(r),
                    function (t, n) {
                      return v(v({}, t), {}, S({}, n, e(r[n])));
                    },
                    {}
                  );
                };
              }
              function T(e) {
                return function (t) {
                  return t == null ? null : e(t);
                };
              }
              function D(e) {
                return function (n) {
                  var r = P(n, W.object()),
                    o = t(
                      Object.keys(e),
                      function (t, n) {
                        var o = e[n],
                          a = r[n],
                          i = o(a);
                        return v(v({}, t), {}, S({}, n, i));
                      },
                      {}
                    );
                  return o;
                };
              }
              function x(e, t) {
                try {
                  return t(e);
                } catch (e) {
                  if (e.name === "FBEventsCoercionError") return null;
                  throw e;
                }
              }
              function P(e, t) {
                return t(e);
              }
              function M(e) {
                return function (t) {
                  var n = P(t, W.string());
                  if (e.test(n)) return n;
                  throw new l(
                    'String "'
                      .concat(n, '" does not match pattern ')
                      .concat(e.toString()),
                    "Typed.matches"
                  );
                };
              }
              function w(e) {
                if (!e) throw new l("Assertion failed", "Typed.assert");
              }
              function A(e) {
                return function (t) {
                  var n = P(t, L());
                  return (
                    w(n.length === e.length),
                    n.map(function (t, n) {
                      return P(t, e[n]);
                    })
                  );
                };
              }
              function F(e) {
                var t = e.def,
                  n = e.validators;
                return function (e) {
                  var r = P(e, t);
                  return (
                    n.forEach(function (e) {
                      if (!e(r))
                        throw new l(
                          "Validation failed for value: ".concat(String(r)),
                          "Typed.withValidation"
                        );
                    }),
                    r
                  );
                };
              }
              var O = /^[1-9][0-9]{0,25}$/;
              function B() {
                return F({
                  def: function (t) {
                    var e = x(t, W.number());
                    return e != null
                      ? (W.assert(r(e)), "".concat(e))
                      : P(t, W.string());
                  },
                  validators: [
                    function (e) {
                      return O.test(e);
                    },
                  ],
                });
              }
              var W = {
                allowNull: T,
                array: L,
                arrayOf: k,
                assert: w,
                boolean: d,
                enumeration: E,
                fbid: B,
                identity: p,
                mapOf: I,
                matches: M,
                mutableObject: y,
                number: m,
                object: h,
                objectOrString: b,
                objectWithFields: D,
                string: _,
                stringOrNumber: g,
                stringRecord: C,
                tuple: A,
                withValidation: F,
                func: R,
                lowercaseString: f,
              };
              o.exports = {
                Typed: W,
                coerce: x,
                enforce: P,
                FBEventsCoercionError: l,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsTypeVersioning", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                t = e.enforce,
                n = e.FBEventsCoercionError;
              function r(e) {
                return function (r) {
                  for (var o = 0; o < e.length; o++) {
                    var a = e[o];
                    try {
                      return t(r, a);
                    } catch (e) {
                      if (e.name === "FBEventsCoercionError") continue;
                      throw e;
                    }
                  }
                  throw new n();
                };
              }
              function i(e, n) {
                return function (r) {
                  return n(t(r, e));
                };
              }
              var l = { waterfall: r, upgrade: i };
              o.exports = l;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsUnwantedDataTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    blacklisted_keys: t.allowNull(
                      t.mapOf(t.mapOf(t.arrayOf(t.string())))
                    ),
                    sensitive_keys: t.allowNull(
                      t.mapOf(t.mapOf(t.arrayOf(t.string())))
                    ),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsUnwantedEventNamesConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    unwantedEventNames: t.allowNull(
                      t.mapOf(t.allowNull(t.number()))
                    ),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsUnwantedEventsConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    restrictedEventNames: t.allowNull(
                      t.mapOf(t.allowNull(t.number()))
                    ),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsUnwantedParamsConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    unwantedParams: t.allowNull(t.arrayOf(t.string())),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsURLManager", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              var e = [];
              function r() {
                for (var t = 0; t < e.length; t++) {
                  var r = e[t];
                  if (r != null && !r.disabled) return r.getURL();
                }
                return n.href;
              }
              function a() {
                for (var n = 0; n < e.length; n++) {
                  var r = e[n];
                  if (r != null && !r.disabled) return r.getReferrer();
                }
                return t.referrer;
              }
              o.exports = { providers: e, getURL: r, getReferrer: a };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsURLMetadataConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    contentIDRegex: t.arrayOf(
                      t.objectWithFields({
                        regex: t.string(),
                        regex_type: t.enumeration({
                          reversedpathregex: "REVERSED_PATH_REGEX",
                          queryparamregex: "QUERY_PARAM_REGEX",
                          pathregex: "PATH_REGEX",
                        }),
                        domain: t.string(),
                      })
                    ),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("signalsFBEventsUserDataParams", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                t = e.logError,
                n = a.getFbeventsModules("SignalsFBEventsPIIInvalidatedEvent"),
                r =
                  "b68919aff001d8366249403a2544fba2d833084f1ad22839b6310aadacb6a138";
              function i(e) {
                var t = e.toLowerCase().trim(),
                  n = t.endsWith("@icloud.com"),
                  r = t.endsWith("@privaterelay.appleid.com");
                if (n) return 2;
                if (r) return 1;
              }
              function l(e, o) {
                try {
                  var a = (e && e.userData) || {},
                    l = (e && e.censoredUserDataFormat) || {},
                    s = (e && e.censoredUserDataFormatFormFields) || {},
                    u = (e && e.userDataFormFields) || {},
                    c = (e && e.alternateUserDataFormFields) || {},
                    d = (e && e.alternateUserData) || {},
                    m,
                    p = {},
                    _ = {},
                    f = a.em;
                  if (f != null) {
                    var g = i(f);
                    g != null && ((m = g), g === 1 && (p.em = r));
                  }
                  var h = u.em;
                  if (h != null) {
                    var y = i(h);
                    y != null && ((m = y), y === 1 && (_.em = r));
                  }
                  var C = {},
                    b = d.em;
                  if (b != null) {
                    var S = i(b);
                    S != null && ((m = S), S === 1 && (C.em = r));
                  }
                  var R = {},
                    L = c.em;
                  if (L != null) {
                    var E = i(L);
                    E != null && ((m = E), E === 1 && (R.em = r));
                  }
                  m != null && o.append("ped", m),
                    Object.keys(l).length > 0 && o.append("cud", l),
                    Object.keys(s).length > 0 && o.append("cudff", s),
                    o.append("ud", v(v({}, a), p), !0),
                    o.append("aud", v(v({}, d), C), !0),
                    o.append("udff", v(v({}, u), _), !0),
                    o.append("audff", v(v({}, c), R), !0);
                } catch (r) {
                  t(r, "pixel", "pii_invalidated"), n.trigger(e);
                }
              }
              o.exports = {
                getPrivateEmailDomain: i,
                appendUserDataParams: l,
                redactedEmailHash: r,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsUtils", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              var e = Object.prototype.toString,
                n = Object.prototype.hasOwnProperty;
              function r(e, t) {
                return n.call(e, t);
              }
              var a = !("addEventListener" in t);
              function i(e, t) {
                return t != null && e instanceof t;
              }
              function l(t) {
                return Array.isArray
                  ? Array.isArray(t)
                  : e.call(t) === "[object Array]";
              }
              function s(e) {
                return (
                  typeof e == "number" ||
                  (typeof e == "string" && /^\d+$/.test(e))
                );
              }
              function u(e) {
                return e != null && G(e) === "object" && l(e) === !1;
              }
              function c(t) {
                return u(t) === !0 && e.call(t) === "[object Object]";
              }
              function d(e) {
                if (c(e) === !1) return !1;
                var t = e.constructor;
                if (typeof t != "function") return !1;
                var n = t.prototype;
                return !(c(n) === !1 || r(n, "isPrototypeOf") === !1);
              }
              var m =
                Number.isInteger ||
                function (e) {
                  return (
                    typeof e == "number" && isFinite(e) && Math.floor(e) === e
                  );
                };
              function p(e) {
                return m(e) && e >= 0 && e <= Number.MAX_SAFE_INTEGER;
              }
              function _(e, t, n) {
                var r = a ? "on" + t : t,
                  o = a ? e.attachEvent : e.addEventListener,
                  i = a ? e.detachEvent : e.removeEventListener,
                  l = function () {
                    i && i.call(e, r, l, !1), n();
                  };
                o && o.call(e, r, l, !1);
              }
              var f = Object.prototype.propertyIsEnumerable,
                g = !f.call({ toString: null }, "toString"),
                h = [
                  "toString",
                  "toLocaleString",
                  "valueOf",
                  "hasOwnProperty",
                  "isPrototypeOf",
                  "propertyIsEnumerable",
                  "constructor",
                ],
                y = h.length;
              function C(e) {
                if (G(e) !== "object" && (typeof e != "function" || e === null))
                  throw new TypeError("Object.keys called on non-object");
                var t = [];
                for (var r in e) n.call(e, r) && t.push(r);
                if (g)
                  for (var o = 0; o < y; o++) n.call(e, h[o]) && t.push(h[o]);
                return t;
              }
              function b(e, t) {
                if (e == null)
                  throw new TypeError("array is null or not defined");
                var n = e.length;
                if (typeof t != "function")
                  throw new TypeError(t + " is not a function");
                for (var r = new Array(n), o = 0; o < n; )
                  o in e && (r[o] = t(e[o], o, e)), o++;
                return r;
              }
              function v(e, t, n) {
                if (e == null)
                  throw new TypeError("array is null or not defined");
                if (typeof t != "function")
                  throw new TypeError(t + " is not a function");
                var r = e.length,
                  o = 0,
                  a;
                if (n != null) a = n;
                else {
                  for (; o < r && !(o in e); ) o++;
                  if (o >= r)
                    throw new TypeError(
                      "Reduce of empty array with no initial value"
                    );
                  a = e[o++];
                }
                for (; o < r; ) o in e && (a = t(a, e[o], o, e)), o++;
                return a;
              }
              function S(e, t) {
                if (typeof t != "function") throw new TypeError();
                if (e == null) return !1;
                for (var n = e.length, r = 0; r < n; r++)
                  if (r in e && t(e[r], r, e)) return !0;
                return !1;
              }
              function R(e) {
                return C(e).length === 0;
              }
              function L(e, t) {
                if (e == null)
                  throw new TypeError("array is null or not defined");
                if (typeof t != "function") throw new TypeError();
                for (var n = e.length, r = [], o = 0; o < n; o++)
                  if (o in e) {
                    var a = e[o];
                    t(a, o, e) && r.push(a);
                  }
                return r;
              }
              function E(e, t) {
                try {
                  return t(e);
                } catch (e) {
                  if (e instanceof TypeError) {
                    if (k.test(e.message)) return null;
                    if (I.test(e.message)) return;
                  }
                  throw e;
                }
              }
              var k = /^null | null$|^[^(]* null /i,
                I = /^undefined | undefined$|^[^(]* undefined /i;
              E.default = E;
              var T = (function () {
                function e(t) {
                  $(this, e), (this.items = t || []);
                }
                return N(e, [
                  {
                    key: "has",
                    value: function (t) {
                      return S(this.items, function (e) {
                        return e === t;
                      });
                    },
                  },
                  {
                    key: "add",
                    value: function (t) {
                      this.items.push(t);
                    },
                  },
                ]);
              })();
              function D(e, t) {
                return e == null || t == null ? !1 : e.indexOf(t) >= 0;
              }
              function x(e, t) {
                return e == null || t == null ? !1 : e.indexOf(t) === 0;
              }
              function P(e) {
                return e.filter(function (t, n) {
                  return e.indexOf(t) === n;
                });
              }
              function M() {
                var e = Date.now();
                return typeof e == "number" ? e : new Date().getTime();
              }
              var w = {
                FBSet: T,
                each: function (t, n) {
                  if (t != null)
                    for (var e = t.length, r = 0; r < e; r++) n(t[r], r);
                },
                filter: function (t, n) {
                  return L(t, n);
                },
                getCurrentTime: M,
                idx: E,
                isArray: l,
                isEmptyObject: R,
                isInstanceOf: i,
                isInteger: m,
                isNumber: s,
                isObject: u,
                isPlainObject: d,
                isSafeInteger: p,
                keys: C,
                listenOnce: _,
                map: b,
                reduce: v,
                some: function (t, n) {
                  return S(t, n);
                },
                stringIncludes: D,
                stringStartsWith: x,
                hasOwn: r,
                removeDuplicates: P,
              };
              o.exports = w;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsValidateCustomParametersEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsTyped"),
                  n = t.coerce,
                  r = t.Typed,
                  i = a.getFbeventsModules("SignalsFBEventsPixelTypedef");
                function l() {
                  for (
                    var e = arguments.length, t = new Array(e), o = 0;
                    o < e;
                    o++
                  )
                    t[o] = arguments[o];
                  return n(t, r.tuple([i, r.object(), r.string()]));
                }
                var s = new e(l);
                o.exports = s;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsValidateGetClickIDFromBrowserProperties",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent");
                function t(e) {
                  return e != null && typeof e == "string" && e !== ""
                    ? e
                    : null;
                }
                var n = new e(t);
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsValidateGetIMEFromBrowserPropertiesPlatform",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent");
                function t(e) {
                  return e != null && typeof e == "number" ? [e] : null;
                }
                var n = new e(t);
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsValidateUrlParametersEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsTyped"),
                  n = t.coerce,
                  r = t.Typed,
                  i = a.getFbeventsModules("SignalsFBEventsPixelTypedef");
                function l() {
                  for (
                    var e = arguments.length, t = new Array(e), o = 0;
                    o < e;
                    o++
                  )
                    t[o] = arguments[o];
                  return n(
                    t,
                    r.tuple([i, r.mapOf(r.string()), r.string(), r.object()])
                  );
                }
                var s = new e(l);
                o.exports = s;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsValidationUtils", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                t = e.stringStartsWith,
                n = /^[a-f0-9]{64}$/i,
                r = /^\s+|\s+$/g,
                i = /\s+/g,
                l = /[!\"#\$%&\'\(\)\*\+,\-\.\/:;<=>\?@ \[\\\]\^_`\{\|\}~\s]+/g,
                s = /[^a-zA-Z0-9]+/g,
                u = /^1\(?\d{3}\)?\d{7}$/,
                c = /^47\d{8}$/,
                d = /^\d{1,4}\(?\d{2,3}\)?\d{4,}$/;
              function m(e) {
                return typeof e == "string" ? e.replace(r, "") : "";
              }
              function p(e) {
                var t =
                    arguments.length > 1 && arguments[1] !== void 0
                      ? arguments[1]
                      : "whitespace_only",
                  n = "";
                if (typeof e == "string")
                  switch (t) {
                    case "whitespace_only":
                      n = e.replace(i, "");
                      break;
                    case "whitespace_and_punctuation":
                      n = e.replace(l, "");
                      break;
                    case "all_non_latin_alpha_numeric":
                      n = e.replace(s, "");
                      break;
                  }
                return n;
              }
              function _(e) {
                return typeof e == "string" && n.test(e);
              }
              function f(e) {
                var n = String(e)
                  .replace(/[\-\s]+/g, "")
                  .replace(/^\+?0{0,2}/, "");
                return t(n, "0")
                  ? !1
                  : t(n, "1")
                  ? u.test(n)
                  : t(n, "47")
                  ? c.test(n)
                  : d.test(n);
              }
              o.exports = {
                isInternationalPhoneNumber: f,
                looksLikeHashed: _,
                strip: p,
                trim: m,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsWebchatConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    automaticEventNamesEnabled: t.arrayOf(t.string()),
                    automaticEventsEnabled: t.boolean(),
                    pixelDataToWebchatEnabled: t.boolean(),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered("SignalsFBEventsWebChatEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsTyped"),
                n = t.Typed,
                r = n.objectWithFields({
                  pixelID: n.allowNull(n.string()),
                  eventName: n.string(),
                  customData: n.allowNull(n.mutableObject()),
                  eventData: n.allowNull(n.object()),
                  customParams: n.allowNull(n.stringRecord()),
                }),
                i = new e(n.tuple([r]));
              o.exports = i;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsParamList", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsCensor"),
                t = e.censoredIneligibleKeysWithUD,
                n = a.getFbeventsModules("SignalsFBEventsUtils"),
                r = n.hasOwn,
                i = a.getFbeventsModules("SignalsEventPayload"),
                l = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                s = "deep",
                u = "shallow",
                c = ["eid"];
              function d(e) {
                return JSON == null || !JSON.stringify
                  ? Object.prototype.toString.call(e)
                  : JSON.stringify(e);
              }
              function m(e) {
                if (e == null) return !0;
                var t = G(e);
                return t === "number" || t === "boolean" || t === "string";
              }
              var p = (function () {
                function e(t) {
                  $(this, e),
                    S(this, "_params", new Map()),
                    (this._piiTranslator = t);
                }
                return N(
                  e,
                  [
                    {
                      key: "containsKey",
                      value: function (t) {
                        return this._params.has(t);
                      },
                    },
                    {
                      key: "get",
                      value: function (t) {
                        var e = this._params.get(t);
                        return e == null || e.length === 0
                          ? null
                          : e[e.length - 1];
                      },
                    },
                    {
                      key: "getAll",
                      value: function (t) {
                        var e = this._params.get(t);
                        return e || null;
                      },
                    },
                    {
                      key: "getAllParams",
                      value: function () {
                        var e = [],
                          t = U(this._params.entries()),
                          n;
                        try {
                          for (t.s(); !(n = t.n()).done; ) {
                            var r = R(n.value, 2),
                              o = r[0],
                              a = r[1],
                              i = U(a),
                              l;
                            try {
                              for (i.s(); !(l = i.n()).done; ) {
                                var s = l.value;
                                e.push({ name: o, value: s });
                              }
                            } catch (e) {
                              i.e(e);
                            } finally {
                              i.f();
                            }
                          }
                        } catch (e) {
                          t.e(e);
                        } finally {
                          t.f();
                        }
                        return e;
                      },
                    },
                    {
                      key: "replaceEntry",
                      value: function (t, n) {
                        this._removeKey(t), this.append(t, n);
                      },
                    },
                    {
                      key: "replaceObjectEntry",
                      value: function (t, n) {
                        this._removeObjectKey(t, n), this.append(t, n);
                      },
                    },
                    {
                      key: "addRange",
                      value: function (t) {
                        this.addParams(t.getAllParams());
                      },
                    },
                    {
                      key: "addParams",
                      value: function (t) {
                        for (var e = 0; e < t.length; e++) {
                          var n = t[e];
                          this._append({ name: n.name, value: n.value }, u, !1);
                        }
                        return this;
                      },
                    },
                    {
                      key: "append",
                      value: function (t, n) {
                        var e =
                          arguments.length > 2 && arguments[2] !== void 0
                            ? arguments[2]
                            : !1;
                        return (
                          this._append(
                            { name: encodeURIComponent(t), value: n },
                            s,
                            e
                          ),
                          this
                        );
                      },
                    },
                    {
                      key: "appendHash",
                      value: function (t) {
                        var e =
                          arguments.length > 1 && arguments[1] !== void 0
                            ? arguments[1]
                            : !1;
                        for (var n in t)
                          r(t, n) &&
                            this._append(
                              { name: encodeURIComponent(n), value: t[n] },
                              s,
                              e
                            );
                        return this;
                      },
                    },
                    {
                      key: "_removeKey",
                      value: function (t) {
                        this._params.delete(t);
                      },
                    },
                    {
                      key: "_removeObjectKey",
                      value: function (t, n) {
                        for (var e in n)
                          if (r(n, e)) {
                            var o = ""
                              .concat(t, "[")
                              .concat(encodeURIComponent(e), "]");
                            this._removeKey(o);
                          }
                      },
                    },
                    {
                      key: "_append",
                      value: function (t, n, r) {
                        var e = t.name,
                          o = t.value;
                        if (o != null)
                          for (var a = 0; a < c.length; a++) {
                            var i = c[a];
                            i === e && this._removeKey(e);
                          }
                        m(o)
                          ? this._appendPrimitive(e, o, r)
                          : n === s
                          ? this._appendObject(e, o, r)
                          : this._appendPrimitive(e, d(o), r);
                      },
                    },
                    {
                      key: "_translateValue",
                      value: function (n, r, o) {
                        if (typeof r == "boolean") return r ? "true" : "false";
                        if (!o) return "".concat(r);
                        if (!this._piiTranslator)
                          throw new Error(
                            "Cannot translate value for key '".concat(
                              n,
                              "' - translator is not initialized"
                            )
                          );
                        var e = this._piiTranslator(n, "".concat(r));
                        return e == null
                          ? null
                          : (t.includes(n) &&
                              l.eval("send_normalized_ud_format") &&
                              this._appendPrimitive(
                                "nc" + n,
                                e.censoredFormat,
                                !1
                              ),
                            e.finalValue);
                      },
                    },
                    {
                      key: "_appendPrimitive",
                      value: function (t, n, r) {
                        if (n != null) {
                          var e = this._translateValue(t, n, r);
                          if (e != null) {
                            var o = this._params.get(t);
                            o != null
                              ? (o.push(e), this._params.set(t, o))
                              : this._params.set(t, [e]);
                          }
                        }
                      },
                    },
                    {
                      key: "_appendObject",
                      value: function (t, n, o) {
                        var e = null;
                        for (var a in n)
                          if (r(n, a)) {
                            var i = ""
                              .concat(t, "[")
                              .concat(encodeURIComponent(a), "]");
                            try {
                              this._append({ name: i, value: n[a] }, u, o);
                            } catch (t) {
                              e == null && (e = t);
                            }
                          }
                        if (e != null) throw e;
                      },
                    },
                    {
                      key: "each",
                      value: function (t) {
                        var e = U(this._params.entries()),
                          n;
                        try {
                          for (e.s(); !(n = e.n()).done; ) {
                            var r = R(n.value, 2),
                              o = r[0],
                              a = r[1],
                              i = U(a),
                              l;
                            try {
                              for (i.s(); !(l = i.n()).done; ) {
                                var s = l.value;
                                t(o, s);
                              }
                            } catch (e) {
                              i.e(e);
                            } finally {
                              i.f();
                            }
                          }
                        } catch (t) {
                          e.e(t);
                        } finally {
                          e.f();
                        }
                      },
                    },
                    {
                      key: "getEventId",
                      value: function () {
                        for (
                          var e = ["eid", "eid[]", encodeURIComponent("eid[]")],
                            t = 0,
                            n = e;
                          t < n.length;
                          t++
                        ) {
                          var r = n[t],
                            o = this.get(r);
                          if (o != null && o.length > 0) return o;
                        }
                        return null;
                      },
                    },
                    {
                      key: "toPayload",
                      value: function () {
                        var e = new i();
                        return (
                          this.each(function (t, n) {
                            e.append(t, n);
                          }),
                          e
                        );
                      },
                    },
                  ],
                  [
                    {
                      key: "fromHash",
                      value: function (n, r) {
                        return new e(r).appendHash(n);
                      },
                    },
                  ]
                );
              })();
              o.exports = p;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsPixelCookieUtils", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsPixelCookie"),
                n = a.getFbeventsModules("signalsFBEventsGetIsChrome"),
                r = a.getFbeventsModules("SignalsFBEventsLogging"),
                i = r.logWarning,
                l = a.getFbeventsModules("SignalsFBEventsQEV2"),
                s = a.getFbeventsModules("SignalsFBEventsExperimentNames"),
                u = s.COOKIE_TTL_FIX,
                c = a.getFbeventsModules("SignalsFBEventsUtils"),
                d = c.getCurrentTime,
                m = a.getFbeventsModules("SignalsFBEventsComparedManagers"),
                p = 2160 * 60 * 60 * 1e3,
                _ = 1e3,
                f = "_fbc",
                g = "fbc",
                h = "fbcs",
                y = "aems",
                C = "_fbp",
                b = "fbp",
                v = "fbclid",
                S = [{ prefix: "", query: "fbclid", ebp_path: "clickID" }],
                R = { params: S },
                L = !1;
              function E(e) {
                var t = l.isInTestPageLoadLevelExperiment(u);
                if (t) {
                  var n = d();
                  return new Date(n + Math.round(e)).toUTCString();
                }
                return new Date(Date.now() + Math.round(e)).toUTCString();
              }
              function k(e) {
                var n = m.getComparedCookieRaw(e);
                return typeof n != "string" || n === "" ? null : t.unpack(n);
              }
              function I(e, t) {
                return e.slice(e.length - 1 - t).join(".");
              }
              function T(e, t, r, o) {
                return (
                  "".concat(e, "=").concat(t, ";") +
                  "expires=".concat(E(o), ";") +
                  "domain=.".concat(r, ";") +
                  "".concat(n() ? "SameSite=Lax;" : "") +
                  "path=/"
                );
              }
              function D(e, t, r, o) {
                return (
                  "".concat(e, "=").concat(t, ";") +
                  "max-age=".concat(Math.floor(o / _), ";") +
                  "domain=.".concat(r, ";") +
                  "".concat(n() ? "SameSite=Lax;" : "") +
                  "path=/"
                );
              }
              function x(e, t, n) {
                var r =
                    arguments.length > 3 && arguments[3] !== void 0
                      ? arguments[3]
                      : p,
                  o = encodeURIComponent(t);
                try {
                  m.setComparedCookieRaw(T(e, o, n, r));
                } catch (e) {
                  i("Fail to write cookie: " + e.message);
                }
                var a = k(e);
                if (a == null) {
                  var s = l.isInTestPageLoadLevelExperiment(u);
                  if (s)
                    try {
                      m.setComparedCookieRaw(D(e, o, n, r));
                    } catch (e) {
                      i("Fail to write cookie with max-age: " + e.message);
                    }
                }
              }
              function $(t, n) {
                var r = e.location.hostname,
                  o = r.split(".");
                if (n.subdomainIndex == null)
                  throw new Error("Subdomain index not set on cookie.");
                var a = I(o, n.subdomainIndex);
                return (
                  x(t, n.pack(), a, p), m.updateCookieCache(t, n.pack()), n
                );
              }
              function P(n, r) {
                for (
                  var o =
                      arguments.length > 2 && arguments[2] !== void 0
                        ? arguments[2]
                        : p,
                    a = e.location.hostname,
                    i = a.split("."),
                    l = new t(r),
                    s = 0;
                  s < i.length;
                  s++
                ) {
                  var u = I(i, s);
                  (l.subdomainIndex = s), x(n, l.pack(), u, o);
                  var c = m.getComparedCookieRaw(n);
                  if (c != null && c != "" && t.unpack(c) != null)
                    return m.updateCookieCache(n, l.pack()), l;
                }
                return m.updateCookieCache(n, l.pack()), l;
              }
              o.exports = {
                buildCookieString: T,
                readPackedCookie: k,
                writeNewCookie: P,
                writeExistingCookie: $,
                CLICK_ID_PARAMETER: v,
                CLICKTHROUGH_COOKIE_NAME: f,
                CLICKTHROUGH_COOKIE_PARAM: g,
                DOMAIN_SCOPED_BROWSER_ID_COOKIE_NAME: C,
                DOMAIN_SCOPED_BROWSER_ID_COOKIE_PARAM: b,
                DEFAULT_FBC_PARAMS: S,
                DEFAULT_FBC_PARAM_CONFIG: R,
                DEFAULT_ENABLE_FBC_PARAM_SPLIT: L,
                MULTI_CLICKTHROUGH_COOKIE_PARAM: h,
                NINETY_DAYS_IN_MS: p,
                AEM_SOURCE_PAYLOAD_KEY: y,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsPixelPIIConstants", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                t = e.keys,
                n = e.map,
                r = {
                  ct: "ct",
                  city: "ct",
                  dob: "db",
                  dobd: "dobd",
                  dobm: "dobm",
                  doby: "doby",
                  email: "em",
                  fn: "fn",
                  f_name: "fn",
                  gen: "ge",
                  ln: "ln",
                  l_name: "ln",
                  phone: "ph",
                  st: "st",
                  state: "st",
                  zip: "zp",
                  zip_code: "zp",
                  pn: "ph",
                  primaryphone: "ph",
                  user_email: "em",
                  emailaddress: "em",
                  email_sha256: "em",
                  email_paypal: "em",
                  consent_global_email_nl: "em",
                  consent_global_email_drip: "em",
                  consent_fide_email_nl: "em",
                  consent_fide_email_drip: "em",
                  bd: "db",
                  birthday: "db",
                  dateofbirth: "db",
                  gender: "ge",
                  firstname: "fn",
                  lastname: "ln",
                  postal: "zp",
                  cn: "country",
                  extern_id: "external_id",
                  external_id: "external_id",
                  userid: "uid",
                },
                i = {
                  em: [
                    "email",
                    "email_address",
                    "emailaddress",
                    "user_email",
                    "consent_global_email_nl",
                    "consent_global_email_drip",
                    "consent_fide_email_nl",
                    "consent_fide_email_drip",
                    "email_sha256",
                    "email_paypal",
                  ],
                  ph: [
                    "primaryphone",
                    "primary_phone",
                    "pn",
                    "phone",
                    "phone_number",
                    "tel",
                    "mobile",
                  ],
                  ln: ["lastname", "last_name", "surname", "lastnameeng"],
                  fn: [
                    "f_name",
                    "firstname",
                    "first_name",
                    "firstnameeng",
                    "name",
                    "profile_name",
                    "account_name",
                    "fbq_custom_name",
                  ],
                  ge: ["gender", "gen", "$gender"],
                  db: ["dob", "bd", "birthday", "d0b", "dateofbirth"],
                  ct: ["city", "$city"],
                  st: ["state", "$state"],
                  zp: [
                    "zipcode",
                    "zip_code",
                    "zip",
                    "postcode",
                    "post_code",
                    "postal",
                  ],
                  country: ["cn"],
                },
                l = {
                  CITY: ["city"],
                  DATE: ["date", "dt", "day", "dobd"],
                  DOB: ["birth", "bday", "bdate", "bmonth", "byear", "dob"],
                  FEMALE: ["female", "girl", "woman"],
                  FIRST_NAME: [
                    "firstname",
                    "fn",
                    "fname",
                    "givenname",
                    "forename",
                  ],
                  GENDER_FIELDS: ["gender", "gen", "sex"],
                  GENDER_VALUES: [
                    "male",
                    "boy",
                    "man",
                    "female",
                    "girl",
                    "woman",
                  ],
                  LAST_NAME: [
                    "lastname",
                    "ln",
                    "lname",
                    "surname",
                    "sname",
                    "familyname",
                  ],
                  MALE: ["male", "boy", "man"],
                  MONTH: ["month", "mo", "mnth", "dobm"],
                  NAME: ["name", "fullname"],
                  PHONE_NUMBER: ["phone", "mobile", "contact"],
                  RESTRICTED: [
                    "ssn",
                    "unique",
                    "cc",
                    "card",
                    "cvv",
                    "cvc",
                    "cvn",
                    "creditcard",
                    "billing",
                    "security",
                    "social",
                    "pass",
                  ],
                  STATE: ["state", "province"],
                  USERNAME: ["username"],
                  YEAR: ["year", "yr", "doby"],
                  ZIP_CODE: [
                    "zip",
                    "zcode",
                    "pincode",
                    "pcode",
                    "postalcode",
                    "postcode",
                  ],
                },
                s = {
                  alabama: "al",
                  alaska: "ak",
                  arizona: "az",
                  arkansas: "ar",
                  california: "ca",
                  colorado: "co",
                  connecticut: "ct",
                  delaware: "de",
                  florida: "fl",
                  georgia: "ga",
                  hawaii: "hi",
                  idaho: "id",
                  illinois: "il",
                  indiana: "in",
                  iowa: "ia",
                  kansas: "ks",
                  kentucky: "ky",
                  louisiana: "la",
                  maine: "me",
                  maryland: "md",
                  massachusetts: "ma",
                  michigan: "mi",
                  minnesota: "mn",
                  mississippi: "ms",
                  missouri: "mo",
                  montana: "mt",
                  nebraska: "ne",
                  nevada: "nv",
                  newhampshire: "nh",
                  newjersey: "nj",
                  newmexico: "nm",
                  newyork: "ny",
                  northcarolina: "nc",
                  northdakota: "nd",
                  ohio: "oh",
                  oklahoma: "ok",
                  oregon: "or",
                  pennsylvania: "pa",
                  rhodeisland: "ri",
                  southcarolina: "sc",
                  southdakota: "sd",
                  tennessee: "tn",
                  texas: "tx",
                  utah: "ut",
                  vermont: "vt",
                  virginia: "va",
                  washington: "wa",
                  westvirginia: "wv",
                  wisconsin: "wi",
                  wyoming: "wy",
                },
                u = {
                  ontario: "on",
                  quebec: "qc",
                  britishcolumbia: "bc",
                  alberta: "ab",
                  saskatchewan: "sk",
                  manitoba: "mb",
                  novascotia: "ns",
                  newbrunswick: "nb",
                  princeedwardisland: "pe",
                  newfoundlandandlabrador: "nl",
                  yukon: "yt",
                  northwestterritories: "nt",
                  nunavut: "nu",
                },
                c = v(v({}, u), s),
                d = {
                  unitedstates: "us",
                  usa: "us",
                  ind: "in",
                  afghanistan: "af",
                  alandislands: "ax",
                  albania: "al",
                  algeria: "dz",
                  americansamoa: "as",
                  andorra: "ad",
                  angola: "ao",
                  anguilla: "ai",
                  antarctica: "aq",
                  antiguaandbarbuda: "ag",
                  argentina: "ar",
                  armenia: "am",
                  aruba: "aw",
                  australia: "au",
                  austria: "at",
                  azerbaijan: "az",
                  bahamas: "bs",
                  bahrain: "bh",
                  bangladesh: "bd",
                  barbados: "bb",
                  belarus: "by",
                  belgium: "be",
                  belize: "bz",
                  benin: "bj",
                  bermuda: "bm",
                  bhutan: "bt",
                  boliviaplurinationalstateof: "bo",
                  bolivia: "bo",
                  bonairesinteustatinsandsaba: "bq",
                  bosniaandherzegovina: "ba",
                  botswana: "bw",
                  bouvetisland: "bv",
                  brazil: "br",
                  britishindianoceanterritory: "io",
                  bruneidarussalam: "bn",
                  brunei: "bn",
                  bulgaria: "bg",
                  burkinafaso: "bf",
                  burundi: "bi",
                  cambodia: "kh",
                  cameroon: "cm",
                  canada: "ca",
                  capeverde: "cv",
                  caymanislands: "ky",
                  centralafricanrepublic: "cf",
                  chad: "td",
                  chile: "cl",
                  china: "cn",
                  christmasisland: "cx",
                  cocoskeelingislands: "cc",
                  colombia: "co",
                  comoros: "km",
                  congo: "cg",
                  congothedemocraticrepublicofthe: "cd",
                  democraticrepublicofthecongo: "cd",
                  cookislands: "ck",
                  costarica: "cr",
                  cotedivoire: "ci",
                  ivorycoast: "ci",
                  croatia: "hr",
                  cuba: "cu",
                  curacao: "cw",
                  cyprus: "cy",
                  czechrepublic: "cz",
                  denmark: "dk",
                  djibouti: "dj",
                  dominica: "dm",
                  dominicanrepublic: "do",
                  ecuador: "ec",
                  egypt: "eg",
                  elsalvador: "sv",
                  equatorialguinea: "gq",
                  eritrea: "er",
                  estonia: "ee",
                  ethiopia: "et",
                  falklandislandsmalvinas: "fk",
                  faroeislands: "fo",
                  fiji: "fj",
                  finland: "fi",
                  france: "fr",
                  frenchguiana: "gf",
                  frenchpolynesia: "pf",
                  frenchsouthernterritories: "tf",
                  gabon: "ga",
                  gambia: "gm",
                  georgia: "ge",
                  germany: "de",
                  ghana: "gh",
                  gibraltar: "gi",
                  greece: "gr",
                  greenland: "gl",
                  grenada: "gd",
                  guadeloupe: "gp",
                  guam: "gu",
                  guatemala: "gt",
                  guernsey: "gg",
                  guinea: "gn",
                  guineabissau: "gw",
                  guyana: "gy",
                  haiti: "ht",
                  heardislandandmcdonaldislands: "hm",
                  holyseevaticancitystate: "va",
                  vatican: "va",
                  honduras: "hn",
                  hongkong: "hk",
                  hungary: "hu",
                  iceland: "is",
                  india: "in",
                  indonesia: "id",
                  iranislamicrepublicof: "ir",
                  iran: "ir",
                  iraq: "iq",
                  ireland: "ie",
                  isleofman: "im",
                  israel: "il",
                  italy: "it",
                  jamaica: "jm",
                  japan: "jp",
                  jersey: "je",
                  jordan: "jo",
                  kazakhstan: "kz",
                  kenya: "ke",
                  kiribati: "ki",
                  koreademocraticpeoplesrepublicof: "kp",
                  northkorea: "kp",
                  korearepublicof: "kr",
                  southkorea: "kr",
                  kuwait: "kw",
                  kyrgyzstan: "kg",
                  laopeoplesdemocraticrepublic: "la",
                  laos: "la",
                  latvia: "lv",
                  lebanon: "lb",
                  lesotho: "ls",
                  liberia: "lr",
                  libya: "ly",
                  liechtenstein: "li",
                  lithuania: "lt",
                  luxembourg: "lu",
                  macao: "mo",
                  macedoniatheformeryugoslavrepublicof: "mk",
                  macedonia: "mk",
                  madagascar: "mg",
                  malawi: "mw",
                  malaysia: "my",
                  maldives: "mv",
                  mali: "ml",
                  malta: "mt",
                  marshallislands: "mh",
                  martinique: "mq",
                  mauritania: "mr",
                  mauritius: "mu",
                  mayotte: "yt",
                  mexico: "mx",
                  micronesiafederatedstatesof: "fm",
                  micronesia: "fm",
                  moldovarepublicof: "md",
                  moldova: "md",
                  monaco: "mc",
                  mongolia: "mn",
                  montenegro: "me",
                  montserrat: "ms",
                  morocco: "ma",
                  mozambique: "mz",
                  myanmar: "mm",
                  namibia: "na",
                  nauru: "nr",
                  nepal: "np",
                  netherlands: "nl",
                  newcaledonia: "nc",
                  newzealand: "nz",
                  nicaragua: "ni",
                  niger: "ne",
                  nigeria: "ng",
                  niue: "nu",
                  norfolkisland: "nf",
                  northernmarianaislands: "mp",
                  norway: "no",
                  oman: "om",
                  pakistan: "pk",
                  palau: "pw",
                  palestinestateof: "ps",
                  palestine: "ps",
                  panama: "pa",
                  papuanewguinea: "pg",
                  paraguay: "py",
                  peru: "pe",
                  philippines: "ph",
                  pitcairn: "pn",
                  poland: "pl",
                  portugal: "pt",
                  puertorico: "pr",
                  qatar: "qa",
                  reunion: "re",
                  romania: "ro",
                  russianfederation: "ru",
                  russia: "ru",
                  rwanda: "rw",
                  saintbarthelemy: "bl",
                  sainthelenaascensionandtristandacunha: "sh",
                  saintkittsandnevis: "kn",
                  saintlucia: "lc",
                  saintmartinfrenchpart: "mf",
                  saintpierreandmiquelon: "pm",
                  saintvincentandthegrenadines: "vc",
                  samoa: "ws",
                  sanmarino: "sm",
                  saotomeandprincipe: "st",
                  saudiarabia: "sa",
                  senegal: "sn",
                  serbia: "rs",
                  seychelles: "sc",
                  sierraleone: "sl",
                  singapore: "sg",
                  sintmaartenductchpart: "sx",
                  slovakia: "sk",
                  slovenia: "si",
                  solomonislands: "sb",
                  somalia: "so",
                  southafrica: "za",
                  southgeorgiaandthesouthsandwichislands: "gs",
                  southsudan: "ss",
                  spain: "es",
                  srilanka: "lk",
                  sudan: "sd",
                  suriname: "sr",
                  svalbardandjanmayen: "sj",
                  eswatini: "sz",
                  swaziland: "sz",
                  sweden: "se",
                  switzerland: "ch",
                  syrianarabrepublic: "sy",
                  syria: "sy",
                  taiwanprovinceofchina: "tw",
                  taiwan: "tw",
                  tajikistan: "tj",
                  tanzaniaunitedrepublicof: "tz",
                  tanzania: "tz",
                  thailand: "th",
                  timorleste: "tl",
                  easttimor: "tl",
                  togo: "tg",
                  tokelau: "tk",
                  tonga: "to",
                  trinidadandtobago: "tt",
                  tunisia: "tn",
                  turkey: "tr",
                  turkmenistan: "tm",
                  turksandcaicosislands: "tc",
                  tuvalu: "tv",
                  uganda: "ug",
                  ukraine: "ua",
                  unitedarabemirates: "ae",
                  unitedkingdom: "gb",
                  unitedstatesofamerica: "us",
                  unitedstatesminoroutlyingislands: "um",
                  uruguay: "uy",
                  uzbekistan: "uz",
                  vanuatu: "vu",
                  venezuelabolivarianrepublicof: "ve",
                  venezuela: "ve",
                  vietnam: "vn",
                  virginislandsbritish: "vg",
                  virginislandsus: "vi",
                  wallisandfutuna: "wf",
                  westernsahara: "eh",
                  yemen: "ye",
                  zambia: "zm",
                  zimbabwe: "zw",
                },
                m =
                  /^\+?\d{1,4}[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}$/,
                p =
                  /^[\w!#\$%&\'\*\+\/\=\?\^`\{\|\}~\-]+(:?\.[\w!#\$%&\'\*\+\/\=\?\^`\{\|\}~\-]+)*@(?:[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?$/i,
                _ = /^\d{5}(?:[-\s]\d{4})?$/,
                f = Object.freeze({ US: "^\\d{5}$" }),
                g = n(t(f), function (e) {
                  return f[e];
                }),
                h = {};
              (h["^\\d{1,2}/\\d{1,2}/\\d{4}$"] = ["DD/MM/YYYY", "MM/DD/YYYY"]),
                (h["^\\d{1,2}-\\d{1,2}-\\d{4}$"] = [
                  "DD-MM-YYYY",
                  "MM-DD-YYYY",
                ]),
                (h["^\\d{4}/\\d{1,2}/\\d{1,2}$"] = ["YYYY/MM/DD"]),
                (h["^\\d{4}-\\d{1,2}-\\d{1,2}$"] = ["YYYY-MM-DD"]),
                (h["^\\d{1,2}/\\d{1,2}/\\d{2}$"] = ["DD/MM/YY", "MM/DD/YY"]),
                (h["^\\d{1,2}-\\d{1,2}-\\d{2}$"] = ["DD-MM-YY", "MM-DD-YY"]),
                (h["^\\d{2}/\\d{1,2}/\\d{1,2}$"] = ["YY/MM/DD"]),
                (h["^\\d{2}-\\d{1,2}-\\d{1,2}$"] = ["YY-MM-DD"]);
              var y = [
                "MM-DD-YYYY",
                "MM/DD/YYYY",
                "DD-MM-YYYY",
                "DD/MM/YYYY",
                "YYYY-MM-DD",
                "YYYY/MM/DD",
                "MM-DD-YY",
                "MM/DD/YY",
                "DD-MM-YY",
                "DD/MM/YY",
                "YY-MM-DD",
                "YY/MM/DD",
              ];
              o.exports = {
                COUNTRY_MAPPINGS: d,
                EMAIL_REGEX: p,
                PHONE_NUMBER_REGEX: m,
                POSSIBLE_FEATURE_FIELDS: l,
                PII_KEY_ALIAS_TO_SHORT_CODE: r,
                SIGNALS_FBEVENTS_DATE_FORMATS: y,
                VALID_DATE_REGEX_FORMATS: h,
                ZIP_REGEX_VALUES: g,
                ZIP_CODE_REGEX: _,
                STATE_MAPPINGS: c,
                PII_KEYS_TO_ALIASES_EXPANDED: i,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsPixelPIIUtils", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsCensor"),
                t = e.censorPII,
                n = a.getFbeventsModules("SignalsFBEventsNormalizers"),
                r = a.getFbeventsModules("SignalsFBEventsPixelPIISchema"),
                i = a.getFbeventsModules("SignalsFBEventsUtils"),
                l = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                s = a.getFbeventsModules("normalizeSignalsFBEventsEmailType"),
                u = a.getFbeventsModules(
                  "normalizeSignalsFBEventsPostalCodeType"
                ),
                c = a.getFbeventsModules(
                  "normalizeSignalsFBEventsPhoneNumberType"
                ),
                d = a.getFbeventsModules("normalizeSignalsFBEventsStringType"),
                m = d.normalizeName,
                p = d.normalizeCity,
                _ = d.normalizeState,
                f = a.getFbeventsModules("SignalsPixelPIIConstants"),
                g = f.EMAIL_REGEX,
                h = f.POSSIBLE_FEATURE_FIELDS,
                y = f.PII_KEY_ALIAS_TO_SHORT_CODE,
                C = f.PII_KEYS_TO_ALIASES_EXPANDED,
                b = f.ZIP_REGEX_VALUES,
                S = f.ZIP_CODE_REGEX,
                L = f.PHONE_NUMBER_REGEX,
                E = i.some,
                k = i.stringIncludes;
              function I(e) {
                var t = e.id,
                  n = e.keyword,
                  r = e.name,
                  o = e.placeholder,
                  a = e.value;
                return n.length > 2
                  ? k(r, n) || k(t, n) || k(o, n) || k(a, n)
                  : r === n || t === n || o === n || a === n;
              }
              function T(e) {
                var t = e.id,
                  n = e.keywords,
                  r = e.name,
                  o = e.placeholder,
                  a = e.value;
                return E(n, function (e) {
                  return I({
                    id: t,
                    keyword: e,
                    name: r,
                    placeholder: o,
                    value: a,
                  });
                });
              }
              function D(e) {
                return e != null && typeof e == "string" && g.test(e);
              }
              function x(e) {
                var t = e;
                return (
                  typeof t == "number" &&
                    typeof t.toString == "function" &&
                    (t = t.toString()),
                  t != null && typeof t == "string" && t.length > 6 && L.test(t)
                );
              }
              function $(e) {
                var t = e;
                return (
                  typeof t == "number" &&
                    typeof t.toString == "function" &&
                    (t = t.toString()),
                  t != null && typeof t == "string" && S.test(t)
                );
              }
              function P(e) {
                var t = e.value,
                  n = e.parentElement,
                  r = e.previousElementSibling,
                  o = null;
                if (
                  ((r instanceof HTMLInputElement ||
                    r instanceof HTMLTextAreaElement) &&
                    (o = r.value),
                  o == null || typeof o != "string" || n == null)
                )
                  return null;
                var a = n.innerText != null ? n.innerText : n.textContent;
                if (a == null || a.indexOf("@") < 0) return null;
                var i = "".concat(o, "@").concat(t);
                return g.test(i) ? i : null;
              }
              function N(e, t) {
                var n = e.name,
                  r = e.id,
                  o = e.placeholder,
                  a = e.value;
                return (
                  (t === "tel" && !(a.length <= 6 && h.ZIP_CODE.includes(r))) ||
                  T({
                    id: r,
                    keywords: h.PHONE_NUMBER,
                    name: n,
                    placeholder: o,
                  })
                );
              }
              function M(e) {
                var t = e.name,
                  n = e.id,
                  r = e.placeholder;
                return T({
                  id: n,
                  keywords: h.FIRST_NAME,
                  name: t,
                  placeholder: r,
                });
              }
              function w(e) {
                var t = e.name,
                  n = e.id,
                  r = e.placeholder;
                return T({
                  id: n,
                  keywords: h.LAST_NAME,
                  name: t,
                  placeholder: r,
                });
              }
              function A(e) {
                var t = e.name,
                  n = e.id,
                  r = e.placeholder;
                return (
                  T({ id: n, keywords: h.NAME, name: t, placeholder: r }) &&
                  !T({ id: n, keywords: h.USERNAME, name: t, placeholder: r })
                );
              }
              function F(e) {
                var t = e.name,
                  n = e.id,
                  r = e.placeholder;
                return T({ id: n, keywords: h.CITY, name: t, placeholder: r });
              }
              function O(e) {
                var t = e.name,
                  n = e.id,
                  r = e.placeholder;
                return T({ id: n, keywords: h.STATE, name: t, placeholder: r });
              }
              function B(e, t, n) {
                var r = e.name,
                  o = e.id,
                  a = e.placeholder,
                  i = e.value;
                return (t === "checkbox" || t === "radio") && n === !0
                  ? T({
                      id: o,
                      keywords: h.GENDER_VALUES,
                      name: r,
                      placeholder: a,
                      value: i,
                    })
                  : t === "text"
                  ? T({
                      id: o,
                      keywords: h.GENDER_FIELDS,
                      name: r,
                      placeholder: a,
                    })
                  : !1;
              }
              function W(e, t) {
                var n = e.name,
                  r = e.id;
                return (
                  (t !== "" &&
                    E(b, function (e) {
                      var n = t.match(String(e));
                      return n != null && n[0] === t;
                    })) ||
                  T({ id: r, keywords: h.ZIP_CODE, name: n })
                );
              }
              function q(e) {
                var t = e.name,
                  n = e.id;
                return T({ id: n, keywords: h.RESTRICTED, name: t });
              }
              function V(e) {
                return e.trim().toLowerCase().replace(/[_-]/g, "");
              }
              function H(e) {
                return e.trim().toLowerCase();
              }
              function G(e) {
                return E(h.MALE, function (t) {
                  return t === e;
                })
                  ? "m"
                  : E(h.FEMALE, function (t) {
                      return t === e;
                    })
                  ? "f"
                  : "";
              }
              function z(e) {
                var t = e.toLowerCase();
                return y[t] !== void 0 ? y[t] : t;
              }
              var j = (function () {
                for (
                  var e = {}, t = 0, n = Object.entries(C);
                  t < n.length;
                  t++
                ) {
                  var r = R(n[t], 2),
                    o = r[0],
                    a = r[1];
                  if (Array.isArray(a)) {
                    var i = U(a),
                      l;
                    try {
                      for (i.s(); !(l = i.n()).done; ) {
                        var s = l.value;
                        typeof s == "string" && e[s] === void 0 && (e[s] = o);
                      }
                    } catch (e) {
                      i.e(e);
                    } finally {
                      i.f();
                    }
                  }
                }
                for (var u = 0, c = Object.entries(y); u < c.length; u++) {
                  var d = R(c[u], 2),
                    m = d[0],
                    p = d[1];
                  typeof p == "string" && (e[m] = p);
                }
                return e;
              })();
              function K(e) {
                var t = e.toLowerCase();
                return j[t] !== void 0 ? j[t] : t;
              }
              function Q(e, t) {
                var o =
                    arguments.length > 2 && arguments[2] !== void 0
                      ? arguments[2]
                      : !1,
                  a = z(e),
                  i = r[a];
                (i == null || i.length === 0) && (i = r.default);
                var l = n[i.type];
                if (l == null) return null;
                var s = l(t, i.typeParams, o);
                return s != null && s !== "" ? s : null;
              }
              function X(e, n) {
                var r = n.value,
                  o = n instanceof HTMLInputElement && n.checked === !0,
                  a = e.name,
                  i = e.id,
                  d = e.inputType,
                  f = e.placeholder,
                  g = {
                    id: V(a),
                    name: V(i),
                    placeholder: (f != null && V(f)) || "",
                    value: H(r),
                  };
                if (q(g) || d === "password" || r === "" || r == null)
                  return null;
                if (D(g.value))
                  return {
                    normalized: { em: s(g.value) },
                    alternateNormalized: { em: s(g.value) },
                    rawCensored: l.eval("send_censored_em") ? { em: t(r) } : {},
                  };
                if (P(n) != null)
                  return {
                    normalized: { em: s(P(n)) },
                    alternateNormalized: { em: s(P(n)) },
                    rawCensored: l.eval("send_censored_em") ? { em: t(r) } : {},
                  };
                if (M(g))
                  return {
                    normalized: { fn: m(g.value) },
                    alternateNormalized: { fn: m(g.value) },
                    rawCensored: l.eval("send_censored_ph") ? { fn: t(r) } : {},
                  };
                if (w(g))
                  return {
                    normalized: { ln: m(g.value) },
                    alternateNormalized: { ln: m(g.value) },
                    rawCensored: l.eval("send_censored_ph") ? { ln: t(r) } : {},
                  };
                if (N(g, d))
                  return {
                    normalized: { ph: c(g.value) },
                    alternateNormalized: { ph: c(g.value, null, !0) },
                    rawCensored: l.eval("send_censored_ph")
                      ? { ph: t(g.value) }
                      : {},
                  };
                if (A(g)) {
                  var h = r.split(" "),
                    y = h[0];
                  h.shift();
                  var C = h.join(" "),
                    b = g.value.split(" "),
                    S = { fn: m(b[0]) };
                  b.shift();
                  var R = { ln: m(b.join(" ")) };
                  return {
                    normalized: v(v({}, S), R),
                    alternateNormalized: v(v({}, S), R),
                    rawCensored: l.eval("send_censored_ph")
                      ? { fn: t(y), ln: t(C) }
                      : {},
                  };
                } else {
                  if (F(g))
                    return {
                      normalized: { ct: p(g.value) },
                      alternateNormalized: { ct: p(g.value) },
                      rawCensored: { ct: t(r) },
                    };
                  if (O(g))
                    return {
                      normalized: { st: _(g.value) },
                      alternateNormalized: { st: _(g.value, null, !0) },
                      rawCensored: l.eval("send_censored_ph")
                        ? { st: t(r) }
                        : {},
                    };
                  if (d != null && B(g, d, o))
                    return {
                      normalized: { ge: G(g.value) },
                      alternateNormalized: { ge: G(g.value) },
                      rawCensored: l.eval("send_censored_ph")
                        ? { ge: t(r) }
                        : {},
                    };
                  if (W(g, r))
                    return {
                      normalized: { zp: u(g.value) },
                      alternateNormalized: { zp: u(g.value) },
                      rawCensored: l.eval("send_censored_ph")
                        ? { zp: t(r) }
                        : {},
                    };
                }
                return null;
              }
              o.exports = {
                extractPIIFields: X,
                getNormalizedPIIKey: z,
                getNormalizedPIIKeyExpanded: K,
                getNormalizedPIIValue: Q,
                isEmail: D,
                getGenderCharacter: G,
                isPhoneNumber: x,
                isZipCode: $,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("WebStorage", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              var t = typeof e != "undefined" ? e : self,
                n = {
                  getLocalStorage: function () {
                    var e = null;
                    try {
                      if (
                        ((e = t.localStorage),
                        e != null &&
                          typeof e.setItem == "function" &&
                          typeof e.removeItem == "function")
                      ) {
                        var n = "__test__" + Date.now();
                        return e.setItem(n, ""), e.removeItem(n), e;
                      }
                    } catch (e) {
                      return null;
                    }
                    return null;
                  },
                };
              o.exports = n;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("WebStorageMutex", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              function e() {
                return Date.now();
              }
              function t() {
                return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
                  /[xy]/g,
                  function (e) {
                    var t = (Math.random() * 16) | 0,
                      n = e === "x" ? t : (t & 3) | 8;
                    return n.toString(16);
                  }
                );
              }
              var n = "pixel_mutex:",
                r = 1e3,
                i = a.getFbeventsModules("WebStorage"),
                l = i.getLocalStorage,
                s = t(),
                u = null,
                c = !1;
              function d() {
                return c || ((c = !0), (u = l())), u;
              }
              function m(e) {
                return n + e;
              }
              function p() {
                return ""
                  .concat(e(), "-")
                  .concat(Math.random().toString(16).slice(2), "-")
                  .concat(t());
              }
              function _(e) {
                var t = d();
                if (!t) return null;
                var n = t.getItem(m(e));
                if (n == null) return null;
                try {
                  var r = JSON.parse(n);
                  if (
                    r &&
                    typeof r.ownerId == "string" &&
                    typeof r.token == "string" &&
                    Number.isFinite(r.expiresAt)
                  )
                    return r;
                } catch (e) {}
                return null;
              }
              function f(e, t) {
                var n = d();
                if (!n) return !1;
                try {
                  var r = JSON.stringify(t);
                  return n.setItem(m(e), r), n.getItem(m(e)) === r;
                } catch (e) {
                  return !1;
                }
              }
              function g(e) {
                var t = d();
                if (t)
                  try {
                    t.removeItem(m(e));
                  } catch (e) {}
              }
              var h = new WeakMap(),
                y = new WeakSet(),
                C = (function () {
                  function t(e) {
                    $(this, t),
                      A(this, y),
                      F(this, h, void 0),
                      (this.name = e),
                      W(h, this, null);
                  }
                  return N(
                    t,
                    [
                      {
                        key: "lock",
                        value: function (n, r, o) {
                          var t = this;
                          B(h, this) &&
                            (clearTimeout(B(h, this)), W(h, this, null));
                          var a = _(this.name);
                          (!a || a.ownerId === s || a.expiresAt < e()) &&
                            q(y, this, v).call(this, o),
                            W(
                              h,
                              this,
                              setTimeout(function () {
                                W(h, t, null),
                                  q(y, t, b).call(t) ? n(t) : r && r(t);
                              }, 0)
                            );
                        },
                      },
                      {
                        key: "unlock",
                        value: function () {
                          B(h, this) &&
                            (clearTimeout(B(h, this)), W(h, this, null)),
                            q(y, this, b).call(this) && g(this.name);
                        },
                      },
                    ],
                    [
                      {
                        key: "__testSetPageId",
                        value: function (t) {
                          s = t;
                        },
                      },
                    ]
                  );
                })();
              function b() {
                var t = _(this.name);
                return !!(t && t.ownerId === s && t.expiresAt >= e());
              }
              function v(e) {
                var t = Math.max(1, e == null ? r : e),
                  n = _(this.name);
                if (n && n.expiresAt >= Date.now() && n.ownerId !== s)
                  return !1;
                var o = { ownerId: s, token: p(), expiresAt: Date.now() + t };
                return !!f(this.name, o);
              }
              o.exports = C;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEvents.plugins.commonincludes",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsPlugin");
                o.exports = new e(function (e, t) {});
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      (o.exports = a.getFbeventsModules(
        "SignalsFBEvents.plugins.commonincludes"
      )),
      a.registerPlugin &&
        a.registerPlugin("fbevents.plugins.commonincludes", o.exports),
      a.ensureModuleRegistered("fbevents.plugins.commonincludes", function () {
        return o.exports;
      });
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    if (
      ((a.execStart =
        e.performance && e.performance.now && e.performance.now()),
      !(function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })())
    )
      return;
    function i(e) {
      "@babel/helpers - typeof";
      return (
        (i =
          typeof Symbol == "function" &&
          typeof (typeof Symbol == "function"
            ? Symbol.iterator
            : "@@iterator") == "symbol"
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  typeof Symbol == "function" &&
                  e.constructor === Symbol &&
                  e !==
                    (typeof Symbol == "function"
                      ? Symbol.prototype
                      : "@@prototype")
                  ? "symbol"
                  : typeof e;
              }),
        i(e)
      );
    }
    function l(e, t) {
      for (var n = 0; n < t.length; n++) {
        var r = t[n];
        (r.enumerable = r.enumerable || !1),
          (r.configurable = !0),
          "value" in r && (r.writable = !0),
          Object.defineProperty(e, u(r.key), r);
      }
    }
    function s(e, t, n) {
      return (
        t && l(e.prototype, t),
        n && l(e, n),
        Object.defineProperty(e, "prototype", { writable: !1 }),
        e
      );
    }
    function u(e) {
      var t = c(e, "string");
      return i(t) == "symbol" ? t : t + "";
    }
    function c(e, t) {
      if (i(e) != "object" || !e) return e;
      var n =
        e[typeof Symbol == "function" ? Symbol.toPrimitive : "@@toPrimitive"];
      if (n !== void 0) {
        var r = n.call(e, t || "default");
        if (i(r) != "object") return r;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return (t === "string" ? String : Number)(e);
    }
    function d(e, t) {
      if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function");
    }
    function m(e, t, n) {
      return (
        (t = g(t)),
        p(
          e,
          f() ? Reflect.construct(t, n || [], g(e).constructor) : t.apply(e, n)
        )
      );
    }
    function p(e, t) {
      if (t && (i(t) == "object" || typeof t == "function")) return t;
      if (t !== void 0)
        throw new TypeError(
          "Derived constructors may only return object or undefined"
        );
      return _(e);
    }
    function _(e) {
      if (e === void 0)
        throw new ReferenceError(
          "this hasn't been initialised - super() hasn't been called"
        );
      return e;
    }
    function f() {
      try {
        var e = !Boolean.prototype.valueOf.call(
          Reflect.construct(Boolean, [], function () {})
        );
      } catch (e) {}
      return (f = function () {
        return !!e;
      })();
    }
    function g(e) {
      return (
        (g = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (e) {
              return e.__proto__ || Object.getPrototypeOf(e);
            }),
        g(e)
      );
    }
    function h(e, t) {
      if (typeof t != "function" && t !== null)
        throw new TypeError(
          "Super expression must either be null or a function"
        );
      (e.prototype = Object.create(t && t.prototype, {
        constructor: { value: e, writable: !0, configurable: !0 },
      })),
        Object.defineProperty(e, "prototype", { writable: !1 }),
        t && y(e, t);
    }
    function y(e, t) {
      return (
        (y = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (e, t) {
              return (e.__proto__ = t), e;
            }),
        y(e, t)
      );
    }
    function C(e, t) {
      return L(e) || R(e, t) || v(e, t) || b();
    }
    function b() {
      throw new TypeError(
        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
      );
    }
    function v(e, t) {
      if (e) {
        if (typeof e == "string") return S(e, t);
        var n = {}.toString.call(e).slice(8, -1);
        return (
          n === "Object" && e.constructor && (n = e.constructor.name),
          n === "Map" || n === "Set"
            ? Array.from(e)
            : n === "Arguments" ||
              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
            ? S(e, t)
            : void 0
        );
      }
    }
    function S(e, t) {
      (t == null || t > e.length) && (t = e.length);
      for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
      return r;
    }
    function R(e, t) {
      var n =
        e == null
          ? null
          : (typeof Symbol != "undefined" &&
              e[
                typeof Symbol == "function" ? Symbol.iterator : "@@iterator"
              ]) ||
            e["@@iterator"];
      if (n != null) {
        var r,
          o,
          a,
          i,
          l = [],
          s = !0,
          u = !1;
        try {
          if (((a = (n = n.call(e)).next), t === 0)) {
            if (Object(n) !== n) return;
            s = !1;
          } else
            for (
              ;
              !(s = (r = a.call(n)).done) && (l.push(r.value), l.length !== t);
              s = !0
            );
        } catch (e) {
          (u = !0), (o = e);
        } finally {
          try {
            if (!s && n.return != null && ((i = n.return()), Object(i) !== i))
              return;
          } finally {
            if (u) throw o;
          }
        }
        return l;
      }
    }
    function L(e) {
      if (Array.isArray(e)) return e;
    }
    a.__fbeventsModules ||
      ((a.__fbeventsModules = {}),
      (a.__fbeventsResolvedModules = {}),
      (a.getFbeventsModules = function (e) {
        return (
          a.__fbeventsResolvedModules[e] ||
            (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
          a.__fbeventsResolvedModules[e]
        );
      }),
      (a.fbIsModuleLoaded = function (e) {
        return !!a.__fbeventsModules[e];
      }),
      (a.ensureModuleRegistered = function (e, t) {
        a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
      })),
      a.ensureModuleRegistered("sha256_with_dependencies_new", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              function e(e) {
                for (var t = "", n, r, o = 0; o < e.length; o++)
                  (n = e.charCodeAt(o)),
                    (r = o + 1 < e.length ? e.charCodeAt(o + 1) : 0),
                    n >= 55296 &&
                      n <= 56319 &&
                      r >= 56320 &&
                      r <= 57343 &&
                      ((n = 65536 + ((n & 1023) << 10) + (r & 1023)), o++),
                    n <= 127
                      ? (t += String.fromCharCode(n))
                      : n <= 2047
                      ? (t += String.fromCharCode(
                          192 | ((n >>> 6) & 31),
                          128 | (n & 63)
                        ))
                      : n <= 65535
                      ? (t += String.fromCharCode(
                          224 | ((n >>> 12) & 15),
                          128 | ((n >>> 6) & 63),
                          128 | (n & 63)
                        ))
                      : n <= 2097151 &&
                        (t += String.fromCharCode(
                          240 | ((n >>> 18) & 7),
                          128 | ((n >>> 12) & 63),
                          128 | ((n >>> 6) & 63),
                          128 | (n & 63)
                        ));
                return t;
              }
              function t(e, t) {
                return (t >>> e) | (t << (32 - e));
              }
              function n(e, t, n) {
                return (e & t) ^ (~e & n);
              }
              function r(e, t, n) {
                return (e & t) ^ (e & n) ^ (t & n);
              }
              function a(e) {
                return t(2, e) ^ t(13, e) ^ t(22, e);
              }
              function i(e) {
                return t(6, e) ^ t(11, e) ^ t(25, e);
              }
              function l(e) {
                return t(7, e) ^ t(18, e) ^ (e >>> 3);
              }
              function s(e) {
                return t(17, e) ^ t(19, e) ^ (e >>> 10);
              }
              function u(e, t) {
                return (e[t & 15] +=
                  s(e[(t + 14) & 15]) + e[(t + 9) & 15] + l(e[(t + 1) & 15]));
              }
              var c = [
                  1116352408, 1899447441, 3049323471, 3921009573, 961987163,
                  1508970993, 2453635748, 2870763221, 3624381080, 310598401,
                  607225278, 1426881987, 1925078388, 2162078206, 2614888103,
                  3248222580, 3835390401, 4022224774, 264347078, 604807628,
                  770255983, 1249150122, 1555081692, 1996064986, 2554220882,
                  2821834349, 2952996808, 3210313671, 3336571891, 3584528711,
                  113926993, 338241895, 666307205, 773529912, 1294757372,
                  1396182291, 1695183700, 1986661051, 2177026350, 2456956037,
                  2730485921, 2820302411, 3259730800, 3345764771, 3516065817,
                  3600352804, 4094571909, 275423344, 430227734, 506948616,
                  659060556, 883997877, 958139571, 1322822218, 1537002063,
                  1747873779, 1955562222, 2024104815, 2227730452, 2361852424,
                  2428436474, 2756734187, 3204031479, 3329325298,
                ],
                d = new Array(8),
                m = new Array(2),
                p = new Array(64),
                _ = new Array(16),
                f = "0123456789abcdef";
              function g(e, t) {
                var n = (e & 65535) + (t & 65535),
                  r = (e >> 16) + (t >> 16) + (n >> 16);
                return (r << 16) | (n & 65535);
              }
              function h() {
                (m[0] = m[1] = 0),
                  (d[0] = 1779033703),
                  (d[1] = 3144134277),
                  (d[2] = 1013904242),
                  (d[3] = 2773480762),
                  (d[4] = 1359893119),
                  (d[5] = 2600822924),
                  (d[6] = 528734635),
                  (d[7] = 1541459225);
              }
              function y() {
                var e, t, o, l, s, m, f, h, y, C;
                (o = d[0]),
                  (l = d[1]),
                  (s = d[2]),
                  (m = d[3]),
                  (f = d[4]),
                  (h = d[5]),
                  (y = d[6]),
                  (C = d[7]);
                for (var b = 0; b < 16; b++)
                  _[b] =
                    p[(b << 2) + 3] |
                    (p[(b << 2) + 2] << 8) |
                    (p[(b << 2) + 1] << 16) |
                    (p[b << 2] << 24);
                for (var v = 0; v < 64; v++)
                  (e = C + i(f) + n(f, h, y) + c[v]),
                    v < 16 ? (e += _[v]) : (e += u(_, v)),
                    (t = a(o) + r(o, l, s)),
                    (C = y),
                    (y = h),
                    (h = f),
                    (f = g(m, e)),
                    (m = s),
                    (s = l),
                    (l = o),
                    (o = g(e, t));
                (d[0] += o),
                  (d[1] += l),
                  (d[2] += s),
                  (d[3] += m),
                  (d[4] += f),
                  (d[5] += h),
                  (d[6] += y),
                  (d[7] += C);
              }
              function C(e, t) {
                var n,
                  r,
                  o = 0;
                r = (m[0] >> 3) & 63;
                var a = t & 63;
                for (
                  (m[0] += t << 3) < t << 3 && m[1]++, m[1] += t >> 29, n = 0;
                  n + 63 < t;
                  n += 64
                ) {
                  for (var i = r; i < 64; i++) p[i] = e.charCodeAt(o++);
                  y(), (r = 0);
                }
                for (var l = 0; l < a; l++) p[l] = e.charCodeAt(o++);
              }
              function b() {
                var e = (m[0] >> 3) & 63;
                if (((p[e++] = 128), e <= 56))
                  for (var t = e; t < 56; t++) p[t] = 0;
                else {
                  for (var n = e; n < 64; n++) p[n] = 0;
                  y();
                  for (var r = 0; r < 56; r++) p[r] = 0;
                }
                (p[56] = (m[1] >>> 24) & 255),
                  (p[57] = (m[1] >>> 16) & 255),
                  (p[58] = (m[1] >>> 8) & 255),
                  (p[59] = m[1] & 255),
                  (p[60] = (m[0] >>> 24) & 255),
                  (p[61] = (m[0] >>> 16) & 255),
                  (p[62] = (m[0] >>> 8) & 255),
                  (p[63] = m[0] & 255),
                  y();
              }
              function v() {
                for (var e = "", t = 0; t < 8; t++)
                  for (var n = 28; n >= 0; n -= 4)
                    e += f.charAt((d[t] >>> n) & 15);
                return e;
              }
              function S(e) {
                for (var t = 0, n = 0; n < 8; n++)
                  for (var r = 28; r >= 0; r -= 4)
                    e[t++] = f.charCodeAt((d[n] >>> r) & 15);
              }
              function R(e, t) {
                if ((h(), C(e, e.length), b(), t)) S(t);
                else return v();
              }
              function L(t) {
                var n =
                    arguments.length > 1 && arguments[1] !== void 0
                      ? arguments[1]
                      : !0,
                  r = arguments.length > 2 ? arguments[2] : void 0;
                if (t == null) return null;
                var o = t;
                return n && (o = e(t)), R(o, r);
              }
              o.exports = L;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEvents.plugins.identity", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsCensor"),
                t = e.censorPII,
                n = a.getFbeventsModules("SignalsFBEventsLogging"),
                r = n.logUserError,
                i = a.getFbeventsModules("SignalsFBEventsPlugin"),
                l = a.getFbeventsModules("SignalsFBEventsUtils"),
                u = l.FBSet,
                c = a.getFbeventsModules("SignalsPixelPIIUtils"),
                p = c.getNormalizedPIIKey,
                _ = c.getNormalizedPIIValue,
                f = a.getFbeventsModules("sha256_with_dependencies_new"),
                g = /^[A-Fa-f0-9]{64}$|^[A-Fa-f0-9]{32}$/,
                y =
                  /^[\w!#\$%&\'\*\+\/\=\?\^`\{\|\}~\-]+(:?\.[\w!#\$%&\'\*\+\/\=\?\^`\{\|\}~\-]+)*@(?:[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?$/i,
                b = Object.prototype.hasOwnProperty,
                v = new u(["uid"]);
              function S(e) {
                return e == null ? !1 : y.test(e);
              }
              function R(e, t, n) {
                var o = p(e);
                if (t == null || t === "") return null;
                var a = _(o, t, n);
                if (o === "em" && !S(a))
                  throw (
                    (r({
                      key_type: "email address",
                      key_val: e,
                      type: "PII_INVALID_TYPE",
                    }),
                    new Error("Invalid email format for key '".concat(e, "'")))
                  );
                return a != null && a != "" ? a : t;
              }
              function L(e, n) {
                if (n == null) return null;
                var o = /\[(.*)\]/.exec(e);
                if (o == null)
                  throw new Error(
                    "Invalid key format, expected bracket notation like 'ud[em]' but got: ".concat(
                      e
                    )
                  );
                var a = !1;
                e.length > 0 && e[0] === "a" && (a = !0);
                var i = C(o, 2),
                  l = i[1];
                if (v.has(l)) {
                  if (S(n))
                    throw (
                      (r({ key: e, type: "PII_UNHASHED_PII" }),
                      new Error(
                        "Email for key '".concat(e, "' needs to be hashed")
                      ))
                    );
                  return { finalValue: n };
                }
                if (g.test(n)) {
                  var s = n.toLowerCase();
                  return { finalValue: s, censoredFormat: t(s) };
                }
                var u = R(l, n, a);
                return u != null && u != ""
                  ? { finalValue: f(u), censoredFormat: t(u) }
                  : null;
              }
              var E = (function (e) {
                  function t(e) {
                    var n;
                    return (
                      d(this, t),
                      (n = m(this, t, [
                        function (t) {
                          t.piiTranslator = e;
                        },
                      ])),
                      (n.piiTranslator = e),
                      n
                    );
                  }
                  return h(t, e), s(t);
                })(i),
                k = new E(L);
              o.exports = k;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      (o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.identity")),
      a.registerPlugin &&
        a.registerPlugin("fbevents.plugins.identity", o.exports),
      a.ensureModuleRegistered("fbevents.plugins.identity", function () {
        return o.exports;
      });
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    (a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered("signalsFBEventsGetIsAndroid", function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              a = o.exports;
            return (
              (function () {
                "use strict";
                var t = e.navigator,
                  n = t.userAgent,
                  r = n.indexOf("Android") >= 0;
                function a() {
                  return r;
                }
                o.exports = a;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }),
        a.ensureModuleRegistered("signalsFBEventsGetIsAndroidIAW", function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var t = a.getFbeventsModules("signalsFBEventsGetIsAndroid"),
                  n = e.navigator,
                  r = n.userAgent,
                  i = r.indexOf("FB_IAB") >= 0,
                  l = r.indexOf("Instagram") >= 0,
                  s = 0,
                  u = r.match(/(FBAV|Instagram)[/\s](\d+)/);
                if (u != null) {
                  var c = u[0].match(/(\d+)/);
                  c != null && (s = parseInt(c[0], 10));
                }
                var d = 397,
                  m = 264;
                function p(e, n) {
                  var r = t() && (i || l);
                  return r
                    ? i && e != null
                      ? e <= s
                      : l && n != null
                      ? n <= s
                      : r
                    : !1;
                }
                o.exports = {
                  getIsAndroidIAW: p,
                  FB_VERSION_MIN: d,
                  INSTAGRAM_VERSION_MIN: m,
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.privacysandbox",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var e = a.getFbeventsModules("signalsFBEventsGetIsChrome"),
                    n = a.getFbeventsModules("signalsFBEventsGetIsAndroidIAW"),
                    r = n.getIsAndroidIAW,
                    i = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                    l = i.GPS_ENDPOINT,
                    s = a.getFbeventsModules("signalsFBEventsSendGET"),
                    u = a.getFbeventsModules("SignalsFBEventsFiredEvent"),
                    c = a.getFbeventsModules("SignalsFBEventsPlugin");
                  o.exports = new c(function (n, o) {
                    (!e() && !r()) ||
                      t.featurePolicy == null ||
                      !t.featurePolicy.allowsFeature("attribution-reporting") ||
                      u.listen(function (e, t) {
                        var n = t.get("id");
                        n != null &&
                          s(t, {
                            ignoreRequestLengthCheck: !0,
                            attributionReporting: !0,
                            url: l,
                          });
                      });
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          }
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.privacysandbox"
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.privacysandbox", o.exports),
        a.ensureModuleRegistered(
          "fbevents.plugins.privacysandbox",
          function () {
            return o.exports;
          }
        ));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    (a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered("signalsFBEventsGetIwlUrl", function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var t = a.getFbeventsModules(
                    "signalsFBEventsCreateTrustedTypePolicy"
                  ),
                  n = a.getFbeventsModules("signalsFBEventsGetTier"),
                  r = t("facebook.com/signals/iwl", function (t) {
                    var n = typeof e.URL == "function" ? e.URL : e.webkitURL,
                      r = new n(t),
                      o =
                        r.hostname.endsWith(".facebook.com") &&
                        r.pathname == "/signals/iwl.js";
                    if (!o) throw new Error("Disallowed script URL");
                    return t;
                  });
                o.exports = function (t, o, a, i, l) {
                  var e = n(o),
                    s =
                      e == null
                        ? "www.facebook.com"
                        : "www.".concat(e, ".facebook.com"),
                    u = "https://"
                      .concat(s, "/signals/iwl.js?pixel_id=")
                      .concat(encodeURIComponent(t), "&access_token=")
                      .concat(encodeURIComponent(a));
                  return (
                    i === !0 && (u += "&from_extension=true"),
                    l != null &&
                      l !== "" &&
                      (u += "&page_domain=".concat(encodeURIComponent(l))),
                    r != null ? r.createScriptURL(u) : u
                  );
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }),
        a.ensureModuleRegistered("signalsFBEventsGetTier", function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              a = o.exports;
            return (
              (function () {
                "use strict";
                var e =
                    /^https:\/\/www\.([A-Za-z0-9\.]+)\.facebook\.com\/tr\/?$/,
                  t = [
                    "https://www.facebook.com/tr",
                    "https://www.facebook.com/tr/",
                  ];
                o.exports = function (r) {
                  if (t.indexOf(r) !== -1) return null;
                  var n = e.exec(r);
                  if (n == null) throw new Error("Malformed tier: ".concat(r));
                  return n[1];
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.iwlbootstrapper",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var n = a.getFbeventsModules(
                      "SignalsFBEventsIWLBootStrapEvent"
                    ),
                    r = a.getFbeventsModules("SignalsFBEventsLogging"),
                    i = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                    l = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    s = a.getFbeventsModules("SignalsFBEventsUtils"),
                    u = s.hasOwn,
                    c = a.getFbeventsModules("signalsFBEventsGetIwlUrl"),
                    d = a.getFbeventsModules("signalsFBEventsGetTier"),
                    m = r.logUserError;
                  function p() {
                    return typeof performance != "undefined"
                      ? performance.now()
                      : Date.now();
                  }
                  var _ = /^https:\/\/.*\.facebook\.com$/i,
                    f = /^https:\/\/.*\.internalfb\.com$/i,
                    g = "FACEBOOK_IWL_CONFIG_STORAGE_KEY",
                    h = "signals-browser-extension",
                    y = null;
                  o.exports = new l(function (r, o) {
                    try {
                      y = e.sessionStorage
                        ? e.sessionStorage
                        : {
                            getItem: function (t) {
                              return null;
                            },
                            removeItem: function (t) {},
                            setItem: function (t, n) {},
                          };
                    } catch (e) {
                      return;
                    }
                    var a = !1,
                      l = null;
                    function s(n, r, o, l, s) {
                      var u = t.createElement("script");
                      (u.async = !0),
                        (u.onload = function () {
                          if (
                            (e.__iwlBootstrapTiming &&
                              (e.__iwlBootstrapTiming.scriptLoadEnd = p()),
                            !e.FacebookIWL || !e.FacebookIWL.init)
                          ) {
                            delete e.__iwlBootstrapTiming;
                            return;
                          }
                          var t = d(i.ENDPOINT);
                          t != null &&
                            e.FacebookIWL.set &&
                            e.FacebookIWL.set("tier", t),
                            o();
                        }),
                        (e.FacebookIWLSessionEnd = function () {
                          y.removeItem(g), l ? ((a = !1), l()) : e.close();
                        }),
                        (u.src = c(
                          n,
                          i.ENDPOINT,
                          r,
                          s,
                          typeof e != "undefined" && e.location != null
                            ? e.location.hostname
                            : void 0
                        ));
                      var m = t.body;
                      m &&
                        (e.__iwlBootstrapTiming &&
                          (e.__iwlBootstrapTiming.scriptLoadStart = p()),
                        m.appendChild(u));
                    }
                    var C = function (t) {
                      return !!(o && o.pixelsByID && u(o.pixelsByID, t));
                    };
                    function b(t, n) {
                      if (!a) {
                        var r = y.getItem(g);
                        if (r) {
                          var o = JSON.parse(r),
                            i = o.pixelID,
                            l = o.graphToken,
                            u = o.sessionStartTime,
                            c = o.valueCurrencyDiagnostics,
                            d = o.deepLinkContext;
                          (a = !0),
                            s(
                              i,
                              l,
                              function () {
                                var t = C(i) ? i.toString() : null;
                                e.__iwlBootstrapTiming &&
                                  (e.__iwlBootstrapTiming.initStart = p());
                                try {
                                  e.FacebookIWL.init(t, l, u, c, d);
                                } finally {
                                  e.__iwlBootstrapTiming &&
                                    (e.__iwlBootstrapTiming.initEnd = p()),
                                    e.FacebookIWL.logBootstrapTiming &&
                                      e.FacebookIWL.logBootstrapTiming(),
                                    delete e.__iwlBootstrapTiming;
                                }
                              },
                              t,
                              n
                            );
                        }
                      }
                    }
                    function v(t, n, r) {
                      a ||
                        s(
                          t,
                          n,
                          function () {
                            return e.FacebookIWL.showConfirmModal(t);
                          },
                          void 0,
                          r
                        );
                    }
                    function S(e, t, n, r, o, a, i) {
                      y.setItem(
                        g,
                        JSON.stringify({
                          graphToken: e,
                          pixelID: t,
                          sessionStartTime: n,
                          valueCurrencyDiagnostics: a != null ? a : void 0,
                          deepLinkContext: i != null ? i : void 0,
                        })
                      ),
                        b(r, o);
                    }
                    n.listen(function (t) {
                      var n = t.graphToken,
                        r = t.pixelID;
                      S(n, r),
                        (e.FacebookIWLSessionEnd = function () {
                          return y.removeItem(g);
                        });
                    });
                    function R(t) {
                      var n = t.data,
                        r = n.graphToken,
                        a = n.msg_type,
                        i = n.pixelID,
                        s = n.sessionStartTime,
                        c = n.source,
                        d = n.valueCurrencyDiagnostics,
                        C = n.deepLinkContext;
                      if (
                        o &&
                        o.pixelsByID &&
                        o.pixelsByID[i] &&
                        o.pixelsByID[i].codeless === "false"
                      ) {
                        m({ pixelID: i, type: "SITE_CODELESS_OPT_OUT" });
                        return;
                      }
                      var b =
                        _.test(t.origin) ||
                        f.test(t.origin) ||
                        (c === h && t.source === e);
                      if (
                        !(
                          y.getItem(g) ||
                          !b ||
                          !(
                            t.data &&
                            (a === "FACEBOOK_IWL_BOOTSTRAP" ||
                              a === "FACEBOOK_IWL_CONFIRM_DOMAIN")
                          )
                        )
                      ) {
                        if (!u(o.pixelsByID, i)) {
                          t.source.postMessage(
                            "FACEBOOK_IWL_ERROR_PIXEL_DOES_NOT_MATCH",
                            t.origin
                          );
                          return;
                        }
                        switch (a) {
                          case "FACEBOOK_IWL_BOOTSTRAP": {
                            (e.__iwlBootstrapTiming = {
                              listenerReadyAt: l,
                              bootstrapReceivedAt: p(),
                            }),
                              t.source.postMessage(
                                "FACEBOOK_IWL_BOOTSTRAP_ACK",
                                t.origin
                              );
                            var R = c === h && t.source === e,
                              L = R
                                ? function () {
                                    return t.source.postMessage(
                                      "FACEBOOK_IWL_SESSION_ENDED",
                                      t.origin
                                    );
                                  }
                                : void 0;
                            S(r, i, s, L, R, d, C);
                            break;
                          }
                          case "FACEBOOK_IWL_CONFIRM_DOMAIN": {
                            t.source.postMessage(
                              "FACEBOOK_IWL_CONFIRM_DOMAIN_ACK",
                              t.origin
                            ),
                              v(i, r);
                            break;
                          }
                        }
                      }
                    }
                    if (y.getItem(g)) {
                      b();
                      return;
                    }
                    (l = p()), e.addEventListener("message", R);
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          }
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.iwlbootstrapper"
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.iwlbootstrapper", o.exports),
        a.ensureModuleRegistered(
          "fbevents.plugins.iwlbootstrapper",
          function () {
            return o.exports;
          }
        ));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    (a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered(
          "SignalsFBEventsOptTrackingOptions",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                a = o.exports;
              return (
                (function () {
                  "use strict";
                  o.exports = {
                    AUTO_CONFIG_OPT_OUT: 1,
                    AUTO_CONFIG: 2,
                    CONFIG_LOADING: 4,
                    SUPPORTS_DEFINE_PROPERTY: 8,
                    SUPPORTS_SEND_BEACON: 16,
                    HAS_INVALIDATED_PII: 32,
                    SHOULD_PROXY: 64,
                    IS_HEADLESS: 128,
                    IS_SELENIUM: 256,
                    HAS_DETECTION_FAILED: 512,
                    HAS_CONFLICTING_PII: 1024,
                    HAS_AUTOMATCHED_PII: 2048,
                    FIRST_PARTY_COOKIES: 4096,
                    IS_SHADOW_TEST: 8192,
                    SMART_SETUP_OPT_OUT: 16384,
                  };
                })(),
                o.exports
              );
            })(e, t, n, r);
          }
        ),
        a.ensureModuleRegistered("SignalsFBEventsProxyState", function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              a = o.exports;
            return (
              (function () {
                "use strict";
                var e = !1;
                o.exports = {
                  getShouldProxy: function () {
                    return e;
                  },
                  setShouldProxy: function (n) {
                    e = n;
                  },
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.opttracking",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var t = a.getFbeventsModules("SignalsFBEventsEvents"),
                    n = t.getCustomParameters,
                    r = t.piiAutomatched,
                    i = t.piiConflicting,
                    l = t.piiInvalidated,
                    s = a.getFbeventsModules(
                      "SignalsFBEventsOptTrackingOptions"
                    ),
                    u = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    c = a.getFbeventsModules("SignalsFBEventsProxyState"),
                    d = a.getFbeventsModules("SignalsFBEventsUtils"),
                    m = d.some,
                    p = !1;
                  function _() {
                    try {
                      Object.defineProperty({}, "test", {});
                    } catch (e) {
                      return !1;
                    }
                    return !0;
                  }
                  function f() {
                    return !!(e.navigator && e.navigator.sendBeacon);
                  }
                  function g(e, t) {
                    return e ? t : 0;
                  }
                  var h = [
                      "_selenium",
                      "callSelenium",
                      "_Selenium_IDE_Recorder",
                    ],
                    y = [
                      "__webdriver_evaluate",
                      "__selenium_evaluate",
                      "__webdriver_script_function",
                      "__webdriver_script_func",
                      "__webdriver_script_fn",
                      "__fxdriver_evaluate",
                      "__driver_unwrapped",
                      "__webdriver_unwrapped",
                      "__driver_evaluate",
                      "__selenium_unwrapped",
                      "__fxdriver_unwrapped",
                    ];
                  function C() {
                    if (v(h)) return !0;
                    var t = m(y, function (t) {
                      return !!e.document[t];
                    });
                    if (t) return !0;
                    var n = e.document;
                    for (var r in n)
                      if (r.match(/\$[a-z]dc_/) && n[r].cache_) return !0;
                    if (
                      e.external &&
                      e.external.toString &&
                      e.external.toString().indexOf("Sequentum") >= 0
                    )
                      return !0;
                    if (n.documentElement && n.documentElement.getAttribute) {
                      var o = m(
                        ["selenium", "webdriver", "driver"],
                        function (t) {
                          return !!e.document.documentElement.getAttribute(t);
                        }
                      );
                      if (o) return !0;
                    }
                    return !1;
                  }
                  function b() {
                    return !!(
                      v(["_phantom", "__nightmare", "callPhantom"]) ||
                      /HeadlessChrome/.test(e.navigator.userAgent)
                    );
                  }
                  function v(t) {
                    var n = m(t, function (t) {
                      return !!e[t];
                    });
                    return n;
                  }
                  function S() {
                    var e = 0,
                      t = 0,
                      n = 0;
                    try {
                      (e = g(C(), s.IS_SELENIUM)), (t = g(b(), s.IS_HEADLESS));
                    } catch (e) {
                      n = s.HAS_DETECTION_FAILED;
                    }
                    return {
                      hasDetectionFailed: n,
                      isHeadless: t,
                      isSelenium: e,
                    };
                  }
                  var R = new u(function (e, t) {
                    if (!p) {
                      var o = {};
                      l.listen(function (e) {
                        e != null && (o[typeof e == "string" ? e : e.id] = !0);
                      });
                      var a = {};
                      i.listen(function (e) {
                        e != null && (a[typeof e == "string" ? e : e.id] = !0);
                      });
                      var u = {};
                      r.listen(function (e) {
                        e != null && (u[typeof e == "string" ? e : e.id] = !0);
                      }),
                        n.listen(function (n) {
                          var r = t.optIns,
                            i = g(
                              n != null &&
                                r.isOptedOut(n.id, "AutomaticSetup") &&
                                r.isOptedOut(n.id, "InferredEvents") &&
                                r.isOptedOut(n.id, "Microdata"),
                              s.AUTO_CONFIG_OPT_OUT
                            ),
                            l = g(
                              n != null &&
                                (r.isOptedIn(n.id, "AutomaticSetup") ||
                                  r.isOptedIn(n.id, "InferredEvents") ||
                                  r.isOptedIn(n.id, "Microdata")),
                              s.AUTO_CONFIG
                            ),
                            d = g(
                              e.disableConfigLoading !== !0,
                              s.CONFIG_LOADING
                            ),
                            m = g(_(), s.SUPPORTS_DEFINE_PROPERTY),
                            p = g(f(), s.SUPPORTS_SEND_BEACON),
                            h = g(n != null && a[n.id], s.HAS_CONFLICTING_PII),
                            y = g(n != null && o[n.id], s.HAS_INVALIDATED_PII),
                            C = g(n != null && u[n.id], s.HAS_AUTOMATCHED_PII),
                            b = g(c.getShouldProxy(), s.SHOULD_PROXY),
                            v = g(
                              n != null &&
                                r.isOptedIn(n.id, "FirstPartyCookies"),
                              s.FIRST_PARTY_COOKIES
                            ),
                            R = g(
                              n != null && r.isOptedIn(n.id, "ShadowTest"),
                              s.IS_SHADOW_TEST
                            ),
                            L = g(
                              n != null &&
                                (t.disableSmartSetup ||
                                  r.isOptedOut(n.id, "SmartSetup")),
                              s.SMART_SETUP_OPT_OUT
                            ),
                            E = S(),
                            k =
                              i |
                              l |
                              d |
                              m |
                              p |
                              y |
                              b |
                              E.isHeadless |
                              E.isSelenium |
                              E.hasDetectionFailed |
                              h |
                              C |
                              v |
                              R |
                              L;
                          return { o: k };
                        }),
                        (p = !0);
                    }
                  });
                  (R.OPTIONS = s), (o.exports = R);
                })(),
                o.exports
              );
            })(e, t, n, r);
          }
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.opttracking"
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.opttracking", o.exports),
        a.ensureModuleRegistered("fbevents.plugins.opttracking", function () {
          return o.exports;
        }));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    (a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.prohibitedsources",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var t = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                    n = a.getFbeventsModules("SignalsFBEventsEvents"),
                    r = n.configLoaded,
                    i = a.getFbeventsModules("SignalsFBEventsLogging"),
                    l = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    s = a.getFbeventsModules("SignalsFBEventsUtils"),
                    u = s.filter,
                    c = a.getFbeventsModules("sha256_with_dependencies_new");
                  o.exports = new l(function (n, o) {
                    r.listen(function (n) {
                      var r = o.optIns.isOptedIn(n, "ProhibitedSources");
                      if (r) {
                        var a = o.getPixel(n);
                        if (a != null) {
                          var l = t.get(a.id, "prohibitedSources");
                          if (l != null) {
                            var s =
                              u(l.prohibitedSources, function (t) {
                                return (
                                  t.domain != null &&
                                  t.domain === c(e.location.hostname)
                                );
                              }).length > 0;
                            s &&
                              (o.locks.lock("prohibited_sources_".concat(n)),
                              i.consoleWarn(
                                "[fbpixel] " +
                                  a.id +
                                  " is unavailable. Go to Events Manager to learn more"
                              ));
                          }
                        }
                      }
                    });
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          }
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.prohibitedsources"
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.prohibitedsources", o.exports),
        a.ensureModuleRegistered(
          "fbevents.plugins.prohibitedsources",
          function () {
            return o.exports;
          }
        ));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    (a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.unwanteddata",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var e = a.getFbeventsModules("SignalsFBEventsEvents"),
                    t = e.validateCustomParameters,
                    n = e.validateUrlParameters,
                    r = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                    i = a.getFbeventsModules("SignalsFBEventsLogging"),
                    l = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    s = a.getFbeventsModules("SignalsFBEventsUtils"),
                    u = a.getFbeventsModules("sha256_with_dependencies_new"),
                    c = s.map,
                    d = !1;
                  o.exports = new l(function (e, o) {
                    t.listen(function (t, n, a) {
                      if (t == null) return {};
                      e.performanceMark(
                        "fbevents:start:unwantedDataProcessing",
                        t.id
                      );
                      var l = o.optIns.isOptedIn(t.id, "UnwantedData");
                      if (!l) return {};
                      var d = o.optIns.isOptedIn(t.id, "ProtectedDataMode"),
                        m = r.get(t.id, "unwantedData");
                      if (m == null) return {};
                      var p = !1,
                        _ = [],
                        f = [],
                        g = {};
                      if (m.blacklisted_keys != null) {
                        var h = m.blacklisted_keys[a];
                        if (h != null) {
                          var y = h.cd;
                          c(y, function (e) {
                            s.hasOwn(n, e) &&
                              ((p = !0), _.push(e), delete n[e]);
                          });
                        }
                      }
                      if (m.sensitive_keys != null) {
                        var C = m.sensitive_keys[a];
                        if (C != null) {
                          var b = C.cd;
                          Object.keys(n).forEach(function (e) {
                            c(b, function (t) {
                              u(e) === t && ((p = !0), f.push(t), delete n[e]);
                            });
                          });
                        }
                      }
                      if (
                        ((g.unwantedParams = _),
                        (g.restrictedParams = f),
                        p && !d)
                      ) {
                        var v = _.length > 0,
                          S = f.length > 0;
                        if (v || S) {
                          e.performanceMark(
                            "fbevents:end:unwantedDataProcessing",
                            t.id
                          ),
                            i.logUserError({ type: "UNWANTED_CUSTOM_DATA" });
                          var R = {};
                          return (
                            v && (R.up = _.join(",")),
                            S && (R.rp = f.join(",")),
                            R
                          );
                        }
                      }
                      return (
                        e.performanceMark(
                          "fbevents:end:unwantedDataProcessing",
                          t.id
                        ),
                        {}
                      );
                    });
                    function a(e, t, n, r, o) {
                      var a = new URLSearchParams(t.search),
                        i = [],
                        l = [],
                        s = {};
                      if (n.blacklisted_keys != null) {
                        var m = n.blacklisted_keys[r];
                        if (m != null) {
                          var p = m.url;
                          c(p, function (e) {
                            a.has(e) &&
                              ((d = !0), i.push(e), a.set(e, "_removed_"));
                          });
                        }
                      }
                      if (n.sensitive_keys != null) {
                        var _ = n.sensitive_keys[r];
                        if (_ != null) {
                          var f = _.url;
                          a.forEach(function (e, t) {
                            c(f, function (e) {
                              u(t) === e &&
                                ((d = !0), l.push(e), a.set(t, "_removed_"));
                            });
                          });
                        }
                      }
                      return (
                        (s.unwantedParams = i),
                        (s.restrictedParams = l),
                        d
                          ? (o ||
                              (i.length > 0 && e.append("up_url", i.join(",")),
                              l.length > 0 && e.append("rp_url", l.join(","))),
                            a.toString())
                          : ""
                      );
                    }
                    n.listen(function (t, n, l, u) {
                      if (t != null) {
                        e.performanceMark(
                          "fbevents:start:validateUrlProcessing",
                          t.id
                        );
                        var c = o.optIns.isOptedIn(t.id, "UnwantedData");
                        if (c) {
                          var m = o.optIns.isOptedIn(t.id, "ProtectedDataMode"),
                            p = r.get(t.id, "unwantedData");
                          if (p != null) {
                            if (
                              ((d = !1), s.hasOwn(n, "dl") && n.dl.length > 0)
                            ) {
                              var _ = new URL(n.dl),
                                f = a(u, _, p, l, m);
                              d &&
                                f.length > 0 &&
                                ((_.search = f), (n.dl = _.toString()));
                            }
                            if (s.hasOwn(n, "rl") && n.rl.length > 0) {
                              var g = new URL(n.rl),
                                h = a(u, g, p, l, m);
                              d &&
                                h.length > 0 &&
                                ((g.search = h), (n.rl = g.toString()));
                            }
                            d && i.logUserError({ type: "UNWANTED_URL_DATA" }),
                              e.performanceMark(
                                "fbevents:end:validateUrlProcessing",
                                t.id
                              );
                          }
                        }
                      }
                    });
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          }
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.unwanteddata"
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.unwanteddata", o.exports),
        a.ensureModuleRegistered("fbevents.plugins.unwanteddata", function () {
          return o.exports;
        }));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    (a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.eventvalidation",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var e = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    t = a.getFbeventsModules("SignalsFBEventsSendEventEvent"),
                    n = a.getFbeventsModules("SignalsFBEventsTyped"),
                    r = n.coerce,
                    i = n.Typed,
                    l = a.getFbeventsModules("SignalsFBEventsLogging"),
                    s = l.logUserError,
                    u = a.getFbeventsModules("sha256_with_dependencies_new");
                  o.exports = new e(function (e, n) {
                    t.listen(function (e) {
                      var t = e.id,
                        o = e.eventName,
                        a = r(t, i.fbid());
                      if (a == null) return !1;
                      var l = n.optIns.isOptedIn(a, "EventValidation");
                      if (!l) return !1;
                      var c = n.pluginConfig.get(a, "eventValidation");
                      if (c == null) return !1;
                      var d = c.unverifiedEventNames,
                        m = c.restrictedEventNames,
                        p = !1,
                        _ = !1,
                        f = u(o);
                      return (
                        d &&
                          ((p = d.includes(o) || (f != null && d.includes(f))),
                          p && s({ type: "UNVERIFIED_EVENT" })),
                        m &&
                          ((_ = m.includes(o) || (f != null && m.includes(f))),
                          _ && s({ type: "RESTRICTED_EVENT" })),
                        p || _
                      );
                    });
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          }
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.eventvalidation"
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.eventvalidation", o.exports),
        a.ensureModuleRegistered(
          "fbevents.plugins.eventvalidation",
          function () {
            return o.exports;
          }
        ));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    if (
      ((a.execStart =
        e.performance && e.performance.now && e.performance.now()),
      !(function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })())
    )
      return;
    function i(e, t) {
      var n =
        (typeof Symbol != "undefined" &&
          e[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"]) ||
        e["@@iterator"];
      if (!n) {
        if (
          Array.isArray(e) ||
          (n = l(e)) ||
          (t && e && typeof e.length == "number")
        ) {
          n && (e = n);
          var r = 0,
            o = function () {};
          return {
            s: o,
            n: function () {
              return r >= e.length ? { done: !0 } : { done: !1, value: e[r++] };
            },
            e: function (t) {
              throw t;
            },
            f: o,
          };
        }
        throw new TypeError(
          "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
        );
      }
      var a,
        i = !0,
        s = !1;
      return {
        s: function () {
          n = n.call(e);
        },
        n: function () {
          var e = n.next();
          return (i = e.done), e;
        },
        e: function (t) {
          (s = !0), (a = t);
        },
        f: function () {
          try {
            i || n.return == null || n.return();
          } finally {
            if (s) throw a;
          }
        },
      };
    }
    function l(e, t) {
      if (e) {
        if (typeof e == "string") return s(e, t);
        var n = {}.toString.call(e).slice(8, -1);
        return (
          n === "Object" && e.constructor && (n = e.constructor.name),
          n === "Map" || n === "Set"
            ? Array.from(e)
            : n === "Arguments" ||
              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
            ? s(e, t)
            : void 0
        );
      }
    }
    function s(e, t) {
      (t == null || t > e.length) && (t = e.length);
      for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
      return r;
    }
    a.__fbeventsModules ||
      ((a.__fbeventsModules = {}),
      (a.__fbeventsResolvedModules = {}),
      (a.getFbeventsModules = function (e) {
        return (
          a.__fbeventsResolvedModules[e] ||
            (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
          a.__fbeventsResolvedModules[e]
        );
      }),
      (a.fbIsModuleLoaded = function (e) {
        return !!a.__fbeventsModules[e];
      }),
      (a.ensureModuleRegistered = function (e, t) {
        a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
      })),
      a.ensureModuleRegistered("SignalsFBEventsClientHintTypedef", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                t = e.Typed,
                n = t.objectWithFields({
                  brands: t.array(),
                  platform: t.allowNull(t.string()),
                  getHighEntropyValues: t.func(),
                }),
                r = t.objectWithFields({
                  model: t.allowNull(t.string()),
                  platformVersion: t.allowNull(t.string()),
                  fullVersionList: t.array(),
                });
              o.exports = {
                userAgentDataTypedef: n,
                highEntropyResultTypedef: r,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsGetIsAndroidChrome",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("signalsFBEventsGetIsChrome");
                function t(e) {
                  return e === void 0
                    ? !1
                    : e.platform === "Android" &&
                        e.brands
                          .map(function (e) {
                            return e.brand;
                          })
                          .join(", ")
                          .includes("Chrome");
                }
                function n(e) {
                  return e.includes("Chrome") && e.includes("Android");
                }
                function r(t) {
                  var n = t.indexOf("Android") >= 0,
                    r = e();
                  return n && r;
                }
                o.exports = {
                  checkIsAndroidChromeWithClientHint: t,
                  checkIsAndroidChromeWithUAString: n,
                  checkIsAndroidChrome: r,
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      a.ensureModuleRegistered(
        "SignalsFBEvents.plugins.clienthint",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              l = o.exports;
            return (
              (function () {
                "use strict";
                var t = a.getFbeventsModules("SignalsFBEventsPlugin"),
                  n = a.getFbeventsModules("SignalsParamList"),
                  r = a.getFbeventsModules("SignalsFBEventsLogging"),
                  l = r.logWarning,
                  s = r.logInfo,
                  u = r.META_PIXEL_PRODUCT_NAME,
                  c = a.getFbeventsModules("SignalsFBEventsTyped"),
                  d = c.coerce,
                  m = a.getFbeventsModules("SignalsFBEventsClientHintTypedef"),
                  p = m.userAgentDataTypedef,
                  _ = m.highEntropyResultTypedef,
                  f = a.getFbeventsModules("SignalsFBEventsGetIsAndroidChrome"),
                  g = f.checkIsAndroidChrome,
                  h = "chmd",
                  y = "chpv",
                  C = "chfv",
                  b = [h, y, C],
                  v = "clientHint",
                  S = "clienthint";
                function R(e) {
                  var t = d(e, _);
                  if (t == null)
                    return (
                      s(
                        new Error(
                          "[ClientHint Error] getHighEntropyValues returned null from Android Chrome source"
                        ),
                        u,
                        S
                      ),
                      new Map()
                    );
                  var n = new Map();
                  n.set(h, String(t.model)),
                    n.set(y, String(t.platformVersion));
                  var r,
                    o,
                    a = i(t.fullVersionList),
                    l;
                  try {
                    for (a.s(); !(l = a.n()).done; )
                      (o = l.value),
                        o.brand.includes("Chrome") && (r = o.version);
                  } catch (e) {
                    a.e(e);
                  } finally {
                    a.f();
                  }
                  return n.set(C, String(r)), n;
                }
                function L(e, t) {
                  var n = i(b),
                    r;
                  try {
                    for (n.s(); !(r = n.n()).done; ) {
                      var o = r.value;
                      e.get(o) == null && e.append(o, t.get(o));
                    }
                  } catch (e) {
                    n.e(e);
                  } finally {
                    n.f();
                  }
                }
                function E(e, t, r) {
                  var o = R(e),
                    a = t.customParams || new n();
                  L(a, o), (t.customParams = a);
                }
                o.exports = new t(function (t, n) {
                  var r = d(e.navigator.userAgentData, p);
                  if (r == null) {
                    e.navigator.userAgentData != null &&
                      l(
                        new Error(
                          "[ClientHint Error] UserAgentData coerce error"
                        ),
                        u,
                        S
                      );
                    return;
                  } else if (!g(e.navigator.userAgent)) return;
                  var o = e.navigator.userAgentData
                    .getHighEntropyValues([
                      "model",
                      "platformVersion",
                      "fullVersionList",
                    ])
                    .then(function (e) {
                      var t = n.asyncParamFetchers.get(v);
                      return (
                        t != null &&
                          t.result == null &&
                          ((t.result = e), n.asyncParamFetchers.set(v, t)),
                        e
                      );
                    })
                    .catch(function (e) {
                      var t = e instanceof Error ? e.message : String(e);
                      l(
                        new Error("[ClientHint Error] Fetch error: ".concat(t)),
                        u,
                        S
                      );
                    });
                  n.asyncParamFetchers.set(v, { request: o, callback: E }),
                    (n.asyncParamPromisesAllSettled = !1);
                });
              })(),
              o.exports
            );
          })(e, t, n, r);
        }
      ),
      (o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.clienthint")),
      a.registerPlugin &&
        a.registerPlugin("fbevents.plugins.clienthint", o.exports),
      a.ensureModuleRegistered("fbevents.plugins.clienthint", function () {
        return o.exports;
      });
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    (a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.unwantedparams",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var e = a.getFbeventsModules("SignalsFBEventsEvents"),
                    t = e.validateCustomParameters,
                    n = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                    r = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    i = a.getFbeventsModules("SignalsFBEventsUtils"),
                    l = i.each,
                    s = i.hasOwn;
                  o.exports = new r(function (e, r) {
                    t.listen(function (t, o, a) {
                      if (t == null) return {};
                      e.performanceMark(
                        "fbevents:start:unwantedParamsProcessing",
                        t.id
                      );
                      var i = r.optIns.isOptedIn(t.id, "UnwantedParams");
                      if (!i) return {};
                      var u = n.get(t.id, "unwantedParams");
                      if (u == null || u.unwantedParams == null) return {};
                      var c = [];
                      return (
                        l(u.unwantedParams, function (e) {
                          s(o, e) && (c.push(e), delete o[e]);
                        }),
                        e.performanceMark(
                          "fbevents:end:unwantedParamsProcessing",
                          t.id
                        ),
                        c.length > 0 ? { spb: c.join(",") } : {}
                      );
                    });
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          }
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.unwantedparams"
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.unwantedparams", o.exports),
        a.ensureModuleRegistered(
          "fbevents.plugins.unwantedparams",
          function () {
            return o.exports;
          }
        ));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    (a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.standardparamchecks",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                    t = e.logUserError,
                    n = a.getFbeventsModules("SignalsFBEventsEvents"),
                    r = n.lateValidateCustomParameters,
                    i = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                    l = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    s = a.getFbeventsModules("SignalsFBEventsUtils"),
                    u = s.each,
                    c = s.some,
                    d = s.keys;
                  function m(e, t) {
                    return t
                      ? t.require_exact_match
                        ? c(t.potential_matches, function (t) {
                            return t.toLowerCase() === e.toLowerCase();
                          })
                        : c(t.potential_matches, function (t) {
                            return new RegExp(t).test(e);
                          })
                      : !1;
                  }
                  o.exports = new l(function (e, n) {
                    r.listen(function (e, r, o) {
                      var a = n.optIns.isOptedIn(e, "StandardParamChecks");
                      if (!a) return {};
                      var l = i.get(e, "standardParamChecks");
                      if (l == null || l.standardParamChecks == null) return {};
                      var s = [];
                      return (
                        u(d(r), function (n) {
                          var o = l.standardParamChecks[n] || [];
                          if (!o || o.length == 0) return {};
                          var a = c(o, function (e) {
                            return m(String(r[n]), e);
                          });
                          a ||
                            (s.push(n),
                            t({
                              invalidParamName: n,
                              pixelID: e,
                              type: "INVALID_PARAM_FORMAT",
                            }));
                        }),
                        u(s, function (e) {
                          delete r[e];
                        }),
                        s.length > 0 ? { rks: s.join(",") } : {}
                      );
                    });
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          }
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.standardparamchecks"
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.standardparamchecks", o.exports),
        a.ensureModuleRegistered(
          "fbevents.plugins.standardparamchecks",
          function () {
            return o.exports;
          }
        ));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    (a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered("SignalsFBEvents.plugins.gating", function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsPlugin"),
                  t = a.getFbeventsModules("SignalsFBEventsEvents"),
                  n = t.gateCheckEvent,
                  r = t.configLoaded,
                  i = a.getFbeventsModules("signalsFBEventsFeatureGate"),
                  l = a.getFbeventsModules("SignalsFBEventsUtils"),
                  s = l.each,
                  u = l.keys;
                o.exports = new e(function (e, t) {
                  var o = [];
                  function a(e, t, n, r) {
                    var o = i(e, r),
                      a = o ? t : n;
                    try {
                      a(e, r);
                    } catch (e) {}
                  }
                  function l(e, t, n, r, a) {
                    o.push({
                      gateName: e,
                      onEnabled: t,
                      onDisabled: n,
                      pixelID: r,
                      checkedPixels: a,
                    });
                  }
                  function c(e, n, r, o) {
                    if (t.configsLoaded[o]) {
                      a(e, n, r, o);
                      return;
                    }
                    l(e, n, r, o, new Set());
                  }
                  function d(e, n, r) {
                    var o = new Set(),
                      i = u(t.pixelsByID);
                    s(i, function (i) {
                      t.configsLoaded[i] && (a(e, n, r, i), o.add(i));
                    }),
                      l(e, n, r, null, o);
                  }
                  function m(e, t) {
                    var n = e.gateName,
                      r = e.onEnabled,
                      o = e.onDisabled,
                      i = e.pixelID;
                    return i !== t ? !1 : (a(n, r, o, t), !0);
                  }
                  function p(e, t) {
                    var n = e.gateName,
                      r = e.onEnabled,
                      o = e.onDisabled,
                      i = e.checkedPixels;
                    i.has(t) || (a(n, r, o, t), i.add(t));
                  }
                  n.listen(function (e, t, n, r) {
                    r != null ? c(e, t, n, r) : d(e, t, n);
                  }),
                    r.listen(function (e) {
                      var t = [];
                      s(o, function (n) {
                        if (n.pixelID != null) {
                          var r = m(n, e);
                          r || t.push(n);
                        } else p(n, e), t.push(n);
                      }),
                        (o.length = 0),
                        s(t, function (e) {
                          return o.push(e);
                        });
                    });
                });
              })(),
              o.exports
            );
          })(e, t, n, r);
        }),
        (o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.gating")),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.gating", o.exports),
        a.ensureModuleRegistered("fbevents.plugins.gating", function () {
          return o.exports;
        }));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    if (
      ((a.execStart =
        e.performance && e.performance.now && e.performance.now()),
      !(function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*"
            ),
            "error" in console,
            !1);
      })())
    )
      return;
    function i(e) {
      "@babel/helpers - typeof";
      return (
        (i =
          typeof Symbol == "function" &&
          typeof (typeof Symbol == "function"
            ? Symbol.iterator
            : "@@iterator") == "symbol"
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  typeof Symbol == "function" &&
                  e.constructor === Symbol &&
                  e !==
                    (typeof Symbol == "function"
                      ? Symbol.prototype
                      : "@@prototype")
                  ? "symbol"
                  : typeof e;
              }),
        i(e)
      );
    }
    function l(e, t) {
      var n = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t &&
          (r = r.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })),
          n.push.apply(n, r);
      }
      return n;
    }
    function s(e) {
      for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {};
        t % 2
          ? l(Object(n), !0).forEach(function (t) {
              u(e, t, n[t]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
          : l(Object(n)).forEach(function (t) {
              Object.defineProperty(
                e,
                t,
                Object.getOwnPropertyDescriptor(n, t)
              );
            });
      }
      return e;
    }
    function u(e, t, n) {
      return (
        (t = c(t)) in e
          ? Object.defineProperty(e, t, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (e[t] = n),
        e
      );
    }
    function c(e) {
      var t = d(e, "string");
      return i(t) == "symbol" ? t : t + "";
    }
    function d(e, t) {
      if (i(e) != "object" || !e) return e;
      var n =
        e[typeof Symbol == "function" ? Symbol.toPrimitive : "@@toPrimitive"];
      if (n !== void 0) {
        var r = n.call(e, t || "default");
        if (i(r) != "object") return r;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return (t === "string" ? String : Number)(e);
    }
    function m(e, t) {
      return g(e) || p(e, t) || C(e, t) || f();
    }
    function p(e, t) {
      var n =
        e == null
          ? null
          : (typeof Symbol != "undefined" &&
              e[
                typeof Symbol == "function" ? Symbol.iterator : "@@iterator"
              ]) ||
            e["@@iterator"];
      if (n != null) {
        var r,
          o,
          a,
          i,
          l = [],
          s = !0,
          u = !1;
        try {
          if (((a = (n = n.call(e)).next), t === 0)) {
            if (Object(n) !== n) return;
            s = !1;
          } else
            for (
              ;
              !(s = (r = a.call(n)).done) && (l.push(r.value), l.length !== t);
              s = !0
            );
        } catch (e) {
          (u = !0), (o = e);
        } finally {
          try {
            if (!s && n.return != null && ((i = n.return()), Object(i) !== i))
              return;
          } finally {
            if (u) throw o;
          }
        }
        return l;
      }
    }
    function _(e) {
      return g(e) || b(e) || C(e) || f();
    }
    function f() {
      throw new TypeError(
        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
      );
    }
    function g(e) {
      if (Array.isArray(e)) return e;
    }
    function h(e) {
      return v(e) || b(e) || C(e) || y();
    }
    function y() {
      throw new TypeError(
        "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
      );
    }
    function C(e, t) {
      if (e) {
        if (typeof e == "string") return S(e, t);
        var n = {}.toString.call(e).slice(8, -1);
        return (
          n === "Object" && e.constructor && (n = e.constructor.name),
          n === "Map" || n === "Set"
            ? Array.from(e)
            : n === "Arguments" ||
              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
            ? S(e, t)
            : void 0
        );
      }
    }
    function b(e) {
      if (
        (typeof Symbol != "undefined" &&
          e[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] !=
            null) ||
        e["@@iterator"] != null
      )
        return Array.from(e);
    }
    function v(e) {
      if (Array.isArray(e)) return S(e);
    }
    function S(e, t) {
      (t == null || t > e.length) && (t = e.length);
      for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
      return r;
    }
    a.__fbeventsModules ||
      ((a.__fbeventsModules = {}),
      (a.__fbeventsResolvedModules = {}),
      (a.getFbeventsModules = function (e) {
        return (
          a.__fbeventsResolvedModules[e] ||
            (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
          a.__fbeventsResolvedModules[e]
        );
      }),
      (a.fbIsModuleLoaded = function (e) {
        return !!a.__fbeventsModules[e];
      }),
      (a.ensureModuleRegistered = function (e, t) {
        a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
      })),
      a.ensureModuleRegistered("SignalsFBEvents", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              var t = e.fbq;
              (t.execStart =
                e.performance && typeof e.performance.now == "function"
                  ? e.performance.now()
                  : null),
                (t.performanceMark = function (t, n) {
                  var r =
                    e.fbq && e.fbq._releaseSegment
                      ? e.fbq._releaseSegment
                      : "unknown";
                  r === "canary" &&
                    e.performance != null &&
                    typeof e.performance.mark == "function" &&
                    (n != null
                      ? e.performance.mark("".concat(t, "_").concat(n))
                      : e.performance.mark(t));
                });
              var n = t.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                r = t.getFbeventsModules("SignalsFBEventsQE"),
                a = t.getFbeventsModules("SignalsParamList"),
                i = t.getFbeventsModules("signalsFBEventsSendEvent"),
                l = i.sendEvent,
                u = t.getFbeventsModules("SignalsFBEventsUtils"),
                c = t.getFbeventsModules("SignalsFBEventsLogging"),
                d = t.getFbeventsModules("SignalsEventValidation"),
                p = t.getFbeventsModules("handleEventIdOverride"),
                f = t.getFbeventsModules("SignalsFBEventsFBQ"),
                g = t.getFbeventsModules("SignalsFBEventsJSLoader"),
                y = t.getFbeventsModules("SignalsFBEventsFireLock"),
                C = t.getFbeventsModules("SignalsFBEventsMobileAppBridge"),
                b = t.getFbeventsModules("signalsFBEventsInjectMethod"),
                v = t.getFbeventsModules("signalsFBEventsMakeSafe"),
                S = t.getFbeventsModules(
                  "signalsFBEventsResolveLegacyArguments"
                ),
                R = t.getFbeventsModules("SignalsFBEventsPluginManager"),
                L = t.getFbeventsModules("signalsFBEventsCoercePixelID"),
                E = t.getFbeventsModules("SignalsFBEventsEvents"),
                k = t.getFbeventsModules("SignalsFBEventsTyped"),
                I = k.coerce,
                T = k.Typed,
                D = t.getFbeventsModules("SignalsFBEventsGuardrail"),
                x = t.getFbeventsModules("SignalsFBEventsModuleEncodings"),
                $ = t.getFbeventsModules("signalsFBEventsDoAutomaticMatching"),
                P = t.getFbeventsModules("SignalsFBEventsTrackEventEvent"),
                N = t.getFbeventsModules("SignalsFBEventsCensor"),
                M = N.getCensoredPayload,
                w = t.getFbeventsModules("SignalsFBEventsMethods"),
                A = w.gateCheck,
                F = t.getFbeventsModules("signalsFBEventsShopifyUtil"),
                O = F.isIncrementalShopifyEvent,
                B = F.updateContentDataForShopify,
                W = t.getFbeventsModules("signalsFBEventsSPANavigationUtil"),
                q = W.setupSPANavigation,
                U = t.getFbeventsModules("signalsFBEventsUserDataParams"),
                V = U.appendUserDataParams,
                H = u.each,
                G = u.FBSet,
                z = u.isEmptyObject,
                j = u.isPlainObject,
                K = u.isNumber,
                Q = u.keys,
                X = u.stringStartsWith,
                Y = E.execEnd,
                J = E.fired,
                Z = E.getCustomParameters,
                ee = E.iwlBootstrap,
                te = E.setIWLExtractors,
                ne = E.setIWLParameterRules,
                re = E.validateCustomParameters,
                oe = E.validateUrlParameters,
                ae = E.setESTRules,
                ie = E.setCCRules,
                le = E.automaticPageView,
                se = E.webchatEvent,
                ue = t.getFbeventsModules("SignalsFBEventsCorrectPIIPlacement"),
                ce = t.getFbeventsModules("SignalsFBEventsProcessEmailAddress"),
                de = t.getFbeventsModules(
                  "SignalsFBEventsAddGmailSuffixToEmail"
                ),
                me = t.getFbeventsModules("SignalsFBEventsQEV2"),
                pe = t.getFbeventsModules("signalsFBEventsFeatureGate"),
                _e = t.getFbeventsModules("SignalsFBEventsPixelQueueState"),
                fe = _e.tryInitQueue,
                ge = _e.tryEnqueueCommand,
                he = t.getFbeventsModules("SignalsFBEventsComparedManagers"),
                ye = c.logError,
                Ce = c.logInfo,
                be = c.logUserError,
                ve = c.META_PIXEL_PRODUCT_NAME,
                Se = y.global,
                Re = -1,
                Le = Array.prototype.slice,
                Ee = Object.prototype.hasOwnProperty,
                ke = !1,
                Ie = !1,
                Te = [],
                De = {},
                xe = { PageView: new G(), PixelInitialized: new G() },
                $e = new f(t, De),
                Pe = new R($e, Se),
                Ne = new G(["eid"]),
                Me = "SignalsFBEvents";
              function we(e, t, n, r) {
                be({
                  invalidParamName: e,
                  invalidParamValue: t,
                  method: n,
                  params: r,
                  type: "INVALID_FBQ_METHOD_PARAMETER",
                });
              }
              function Ae(e) {
                for (var t in e) Ee.call(e, t) && (this[t] = e[t]);
                return this;
              }
              function Fe() {
                try {
                  return ge(arguments), Oe.apply(this, arguments);
                } catch (e) {
                  ye(e);
                }
              }
              function Oe() {
                try {
                  var e = Le.call(arguments);
                  if (Se.isLocked() && e[0] !== "consent") {
                    t.queue.push(arguments);
                    return;
                  }
                  var n = S(e),
                    r = h(n.args),
                    o = n.isLegacySyntax,
                    a = r.shift();
                  switch (a) {
                    case "addPixelId":
                      (ke = !0), We.apply(this, r);
                      break;
                    case "init":
                      (Ie = !0), We.apply(this, r);
                      break;
                    case "set":
                      Be.apply(this, r);
                      break;
                    case "gateCheck":
                      A.apply(this, r);
                      break;
                    case "track":
                      if (K(r[0])) {
                        je.apply(this, r);
                        break;
                      }
                      if (o === !0) {
                        He.apply(this, r);
                        break;
                      }
                      Ve.apply(this, r);
                      break;
                    case "trackCustom":
                      He.apply(this, r);
                      break;
                    case "trackShopify":
                      ze.apply(this, r);
                      break;
                    case "trackWebchat":
                      Ge.apply(this, r);
                      break;
                    case "send":
                      Ke.apply(this, r);
                      break;
                    case "on":
                      {
                        var i = _(r),
                          l = i[0],
                          s = i.slice(1),
                          u = E[l];
                        u && u.triggerWeakly(s);
                      }
                      break;
                    case "loadPlugin":
                      Pe.loadPlugin(r[0]);
                      break;
                    case "disabledExtensions": {
                      var c = m(r, 1),
                        d = c[0];
                      $e.pluginConfig.set(null, "disabledExtensions", {
                        disabledExtensions: d,
                      });
                      break;
                    }
                    case "dataProcessingOptions":
                      switch (r.length) {
                        case 1: {
                          var p = m(r, 1),
                            f = p[0];
                          $e.pluginConfig.set(null, "dataProcessingOptions", {
                            dataProcessingOptions: f,
                            dataProcessingCountry: null,
                            dataProcessingState: null,
                          });
                          break;
                        }
                        case 3:
                        case 4: {
                          var g = m(r, 3),
                            y = g[0],
                            C = g[1],
                            b = g[2];
                          $e.pluginConfig.set(null, "dataProcessingOptions", {
                            dataProcessingOptions: y,
                            dataProcessingCountry: C,
                            dataProcessingState: b,
                          });
                          break;
                        }
                      }
                      break;
                    default:
                      $e.callMethod(arguments);
                      break;
                  }
                } catch (e) {
                  ye(e);
                }
              }
              function Be(e) {
                for (
                  var o = arguments.length,
                    a = new Array(o > 1 ? o - 1 : 0),
                    i = 1;
                  i < o;
                  i++
                )
                  a[i - 1] = arguments[i];
                var l = [e].concat(a);
                switch (e) {
                  case "endpoint": {
                    var u = a[0];
                    if (typeof u != "string")
                      throw new Error("endpoint value must be a string");
                    n.ENDPOINT = u;
                    break;
                  }
                  case "cdn": {
                    var c = a[0];
                    if (typeof c != "string")
                      throw new Error("cdn value must be a string");
                    g.CONFIG.CDN_BASE_URL = c;
                    break;
                  }
                  case "releaseSegment": {
                    var m = a[0];
                    if (typeof m != "string") {
                      we("new_release_segment", m, "set", l);
                      break;
                    }
                    t._releaseSegment = m;
                    break;
                  }
                  case "autoConfig": {
                    var p = a[0],
                      _ = a[1],
                      f = p === !0 || p === "true" ? "optIn" : "optOut";
                    typeof _ == "string"
                      ? $e.callMethod([f, _, "AutomaticSetup"])
                      : _ === void 0
                      ? ($e.disableAutoConfig = f === "optOut")
                      : we("pixel_id", _, "set", l);
                    break;
                  }
                  case "smartSetup": {
                    var h = a[0],
                      y = a[1],
                      b = h === !0 || h === "true" ? "optIn" : "optOut";
                    typeof y == "string"
                      ? $e.callMethod([b, y, "SmartSetup"])
                      : y === void 0
                      ? ($e.disableSmartSetup = b === "optOut")
                      : we("pixel_id", y, "set", l);
                    break;
                  }
                  case "firstPartyCookies": {
                    var v = a[0],
                      S = a[1],
                      R = v === !0 || v === "true" ? "optIn" : "optOut";
                    typeof S == "string"
                      ? $e.callMethod([R, S, "FirstPartyCookies"])
                      : S === void 0
                      ? ($e.disableFirstPartyCookies = R === "optOut")
                      : we("pixel_id", S, "set", l);
                    break;
                  }
                  case "experiments": {
                    r.setExperiments.apply(r, a);
                    break;
                  }
                  case "experimentsV2": {
                    me.setExperiments.apply(me, a);
                    break;
                  }
                  case "guardrails": {
                    D.setGuardrails.apply(D, a);
                    break;
                  }
                  case "moduleEncodings": {
                    x.setModuleEncodings.apply(x, a);
                    break;
                  }
                  case "mobileBridge": {
                    var L = a[0],
                      E = a[1];
                    if (typeof L != "string") {
                      we("pixel_id", L, "set", l);
                      break;
                    }
                    if (typeof E != "string") {
                      we("app_id", E, "set", l);
                      break;
                    }
                    C.registerBridge([L, E]);
                    break;
                  }
                  case "iwlExtractors": {
                    var k = a[0],
                      P = a[1];
                    te.triggerWeakly({ extractors: P, pixelID: k });
                    break;
                  }
                  case "iwlParameterRules": {
                    var N = a[0],
                      M = a[1];
                    ne.triggerWeakly({ rules: M, pixelID: N });
                    break;
                  }
                  case "estRules": {
                    var w = a[0],
                      A = a[1];
                    ae.triggerWeakly({ rules: A, pixelID: w });
                    break;
                  }
                  case "ccRules": {
                    var F = a[0],
                      O = a[1];
                    ie.triggerWeakly({ rules: O, pixelID: F });
                    break;
                  }
                  case "startIWLBootstrap": {
                    var B = a[0],
                      W = a[1];
                    ee.triggerWeakly({ graphToken: B, pixelID: W });
                    break;
                  }
                  case "parallelfire": {
                    var q = a[0],
                      U = a[1];
                    $e.pluginConfig.set(q, "parallelfire", { target: U });
                    break;
                  }
                  case "openbridge": {
                    var V = a[0],
                      H = a[1];
                    V !== null &&
                      H !== null &&
                      typeof V == "string" &&
                      typeof H == "string" &&
                      ($e.callMethod(["optIn", V, "OpenBridge"]),
                      $e.pluginConfig.set(V, "openbridge", {
                        endpoints: [{ endpoint: H }],
                      }));
                    break;
                  }
                  case "trackSingleOnly": {
                    var G = a[0],
                      z = a[1],
                      K = I(G, T.boolean()),
                      Q = I(z, T.fbid());
                    if (Q == null) {
                      we("pixel_id", z, "set", l);
                      break;
                    }
                    if (K == null) {
                      we("on_or_off", G, "set", l);
                      break;
                    }
                    var X = d.validateMetadata(e);
                    X.error && be(X.error),
                      X.warnings &&
                        X.warnings.forEach(function (e) {
                          be(e);
                        }),
                      Ee.call(De, Q)
                        ? (De[Q].trackSingleOnly = K)
                        : be({
                            metadataValue: e,
                            pixelID: Q,
                            type: "SET_METADATA_ON_UNINITIALIZED_PIXEL_ID",
                          });
                    break;
                  }
                  case "shopifySandboxContext": {
                    var Y = a[0];
                    if (Y != null && j(Y)) {
                      var J = Y.pixelId;
                      typeof J == "string" &&
                        J.length > 0 &&
                        $e.pluginConfig.set(J, "shopifySandboxContext", Y);
                    }
                    break;
                  }
                  case "userData": {
                    var Z = a[0],
                      re = Z == null || j(Z);
                    if (!re) {
                      we("user_data", Z, "set", l);
                      return;
                    }
                    for (var oe = s({}, Z), le = 0; le < Te.length; le++) {
                      var se = Te[le],
                        ue = $e.optIns.isOptedIn(se.id, "AutomaticMatching"),
                        ce = $e.optIns.isOptedIn(
                          se.id,
                          "ShopifyAppIntegratedPixel"
                        );
                      !pe("enable_shopify_additional_events", se.id) &&
                        ce &&
                        Z &&
                        Ee.call(Z, "external_id") &&
                        delete Z.external_id,
                        ue && ce
                          ? $($e, se, Z, oe)
                          : we("pixel_id", se.id, "set", l);
                    }
                    break;
                  }
                  default: {
                    var de = $e.pluginConfig.getWithGlobalFallback(
                        null,
                        "dataProcessingOptions"
                      ),
                      _e =
                        de != null && de.dataProcessingOptions.includes("LDU"),
                      fe = a[0],
                      ge = a[1];
                    if (typeof e != "string") {
                      if (_e) break;
                      we("setting", e, "set", l);
                      break;
                    }
                    if (typeof fe != "string") {
                      if (_e) break;
                      we("value", fe, "set", l);
                      break;
                    }
                    if (typeof ge != "string") {
                      if (_e) break;
                      we("pixel_id", ge, "set", l);
                      break;
                    }
                    Ue(e, fe, ge);
                    break;
                  }
                }
              }
              (t._initHandlers = []), (t._initsDone = {});
              function We(e, t, n) {
                try {
                  Re = Re === -1 ? Date.now() : Re;
                  var r = L(e);
                  if (r == null) return;
                  var o = t == null || j(t);
                  o || we("user_data", t, "init", [e, t]);
                  var a =
                      D.eval("send_censored_ph", r) ||
                      D.eval("send_censored_em", r),
                    i = {};
                  o && a && (i = M(t || {}));
                  var l = null;
                  t != null &&
                    ((l = s({}, t)), (t = ce(t)), (t = ue(t)), (t = de(t)));
                  var u = $e.pluginConfig.get(r, "protectedDataMode"),
                    c = $e.optIns.isOptedIn(r, "ProtectedDataMode"),
                    d = !0;
                  if (
                    (c && u != null && u.disableAM === !0 && (d = !1),
                    Ee.call(De, r))
                  ) {
                    t != null && z(De[r].userData)
                      ? ((De[r].userData = d && o ? t || {} : {}),
                        (De[r].alternateUserData = d && o ? l || {} : {}),
                        (De[r].censoredUserDataFormat = d ? i : {}),
                        Pe.loadPlugin("identity"))
                      : be({ pixelID: r, type: "DUPLICATE_PIXEL_ID" });
                    return;
                  }
                  var m = {
                    agent: n ? n.agent : null,
                    eventCount: 0,
                    id: r,
                    userData: d && o ? t || {} : {},
                    alternateUserData: d && o ? l || {} : {},
                    userDataFormFields: {},
                    alternateUserDataFormFields: {},
                    censoredUserDataFormat: d ? i : {},
                    censoredUserDataFormatFormFields: {},
                  };
                  Te.push(m),
                    (De[r] = m),
                    t != null && Pe.loadPlugin("identity"),
                    $e.optIns.isOptedIn(r, "OpenBridge") &&
                      Pe.loadPlugin("openbridge3"),
                    qe(),
                    $e.loadConfig(r);
                } catch (e) {
                  ye(e, "pixel", "Init");
                }
              }
              function qe() {
                for (var e = 0; e < t._initHandlers.length; e++) {
                  var n = t._initHandlers[e];
                  t._initsDone[e] || (t._initsDone[e] = {});
                  for (var r = 0; r < Te.length; r++) {
                    var o = Te[r];
                    t._initsDone[e][o.id] ||
                      ((t._initsDone[e][o.id] = !0), n(o));
                  }
                }
              }
              function Ue(e, t, n) {
                var r = d.validateMetadata(e);
                if (
                  (r.error && be(r.error),
                  r.warnings &&
                    r.warnings.forEach(function (e) {
                      be(e);
                    }),
                  Ee.call(De, n))
                ) {
                  for (var o = 0, a = Te.length; o < a; o++)
                    if (Te[o].id === n) {
                      Te[o][e] = t;
                      break;
                    }
                } else
                  be({
                    metadataValue: t,
                    pixelID: n,
                    type: "SET_METADATA_ON_UNINITIALIZED_PIXEL_ID",
                  });
              }
              function Ve(e, t, n) {
                (t = t || {}),
                  d.validateEventAndLog(e, t),
                  e === "CustomEvent" &&
                    typeof t.event == "string" &&
                    (e = t.event),
                  He.call(this, e, t, n);
              }
              function He(n, o, i, l) {
                var c = this,
                  d = !1,
                  m = null;
                this == null &&
                  ((c = new Ae({
                    allowDuplicatePageViews: !0,
                    isAutomaticPageView: !0,
                  })),
                  (m = new a(t.piiTranslator)),
                  m.append("ie[a]", "1")),
                  l != null &&
                    Q(l).length > 0 &&
                    (m == null && (m = new a(t.piiTranslator)),
                    Object.keys(l).forEach(function (e) {
                      m.append(e, l[e]);
                    }));
                try {
                  D.eval("reset_init_time_on_spa_page_change") &&
                    c.isAutomaticPageView &&
                    (Re = Re !== -1 ? Date.now() : Re);
                  for (var p = 0, _ = Te.length; p < _; p++) {
                    var f = Te[p],
                      g = Date.now().toString(),
                      h = e.fbq.instance.pluginConfig.get(f.id, "buffer"),
                      y = !1;
                    if (
                      (h != null &&
                        (y =
                          h.onlyBufferPageView === !0 &&
                          r.isInTest("spa_pageview_fix")),
                      (y = c.allowDuplicatePageViews || y),
                      c.isAutomaticPageView &&
                        (i = s(s({}, i), {}, { isAutomaticPageView: !0 })),
                      !(
                        !(n === "PageView" && y) &&
                        u.hasOwn(xe, n) &&
                        xe[n].has(f.id)
                      ) && f.trackSingleOnly !== !0)
                    )
                      try {
                        Je({
                          customData: o,
                          eventData: i,
                          eventName: n,
                          pixel: f,
                          additionalCustomParams: m,
                          experimentId: g,
                        }),
                          u.hasOwn(xe, n) && xe[n].add(f.id);
                      } catch (e) {
                        ye(e, ve, Me);
                      }
                  }
                } finally {
                }
              }
              function Ge(e, t, n, r) {
                try {
                  for (var o = 0, a = Te.length; o < a; o++) {
                    var i = Te[o];
                    i == null ||
                      i.id == null ||
                      se.triggerWeakly([
                        {
                          pixelID: i.id,
                          eventName: e,
                          customData: t != null ? t : {},
                          eventData: n,
                          customParams: r,
                        },
                      ]);
                  }
                } catch (e) {
                  ye(e, "pixel", "webchat");
                }
              }
              function ze(e, t, n, r, o) {
                var a = O(t, o),
                  i = pe("enable_shopify_additional_events", e);
                if (!(a && !i)) {
                  var l = {};
                  a && (l = s(s({}, l), {}, { "ie[f]": "1" }));
                  var u = $e.optIns.isOptedIn(e, "ShopifyAppIntegratedPixel");
                  (n = B(u, e, t, n, o)),
                    d.validateEventAndLog(t, n),
                    t === "CustomEvent" &&
                      typeof n.event == "string" &&
                      (t = n.event),
                    He.call(this, t, n, r, l);
                }
              }
              function je(e, t) {
                var n = Date.now().toString();
                Je({ customData: t, eventName: e, experimentId: n });
              }
              function Ke(e, t, n) {
                Te.forEach(function (n) {
                  var r = Date.now().toString();
                  Je({
                    customData: t,
                    eventName: e,
                    pixel: n,
                    experimentId: r,
                  });
                });
              }
              function Qe(e, n, r, o, i, l) {
                var u = new a(t.piiTranslator);
                l != null && (u = l),
                  V(e, u),
                  u.append("v", t.version),
                  t._releaseSegment && u.append("r", t._releaseSegment),
                  u.append("a", e && e.agent ? e.agent : t.agent),
                  e && (u.append("ec", e.eventCount), e.eventCount++);
                var c = Z.trigger(e, n, r, o, i);
                H(c, function (t) {
                  return H(Q(t), function (n) {
                    if (u.containsKey(n)) {
                      if (!Ne.has(n))
                        if (n === "bfs" && j(t[n]) && j(u.get(n))) {
                          var r = u.get(n),
                            o = s(s({}, r), t[n]);
                          u.replaceEntry(n, o);
                        } else {
                          var a = me.isInMetaQEControl(
                            e == null ? void 0 : e.id
                          );
                          if (a)
                            throw new Error(
                              "Custom parameter ".concat(
                                n,
                                " has already been specified."
                              )
                            );
                          var i = u.get(n),
                            l = t != null ? t[n] : null;
                          Ce(
                            i === l
                              ? new Error(
                                  "[SignalsFBEvents] ".concat(
                                    n,
                                    " param is the same as the existing value."
                                  )
                                )
                              : new Error(
                                  "[SignalsFBEvents] ".concat(
                                    n,
                                    " param is different from the existing value."
                                  )
                                ),
                            ve,
                            Me
                          ),
                            u.replaceEntry(n, l != null ? l : i),
                            !u.containsKey("ie[c]") &&
                              !u.containsKey("ie%5Bc%5D") &&
                              u.append("ie[c]", 1);
                        }
                      t &&
                        (Xe(n, t[n]) || Ye(n, t[n])) &&
                        u.replaceEntry(n, t[n]);
                    } else u.append(n, t[n]);
                  });
                }),
                  u.append("it", Re);
                var d = e && e.codeless === "false";
                u.append("coo", d);
                var m = $e.pluginConfig.getWithGlobalFallback(
                  e ? e.id : null,
                  "dataProcessingOptions"
                );
                if (m != null) {
                  var p = m.dataProcessingCountry,
                    _ = m.dataProcessingOptions,
                    f = m.dataProcessingState;
                  u.append("dpo", _.join(",")),
                    u.append("dpoco", p),
                    u.append("dpost", f);
                }
                var g = $e.pluginConfig.getWithGlobalFallback(
                  e ? e.id : null,
                  "disabledExtensions"
                );
                if (g != null) {
                  var h = g.disabledExtensions;
                  u.append("de", h.join(","));
                }
                return u;
              }
              function Xe(e, t) {
                return (
                  (e === "eid" || e === "eid%5B%5D") &&
                  t &&
                  typeof t == "string" &&
                  X(t, "ob3_plugin-set")
                );
              }
              function Ye(e, t) {
                return (
                  (e === "eid" || e === "eid%5B%5D") &&
                  t &&
                  typeof t == "string" &&
                  X(t, "sgwpixel_plugin-set")
                );
              }
              function Je(e) {
                var t = e.customData,
                  n = e.eventData,
                  r = e.eventName,
                  o = e.pixel,
                  a = e.additionalCustomParams,
                  i = e.experimentId;
                if (((t = t || {}), o != null && C.pixelHasActiveBridge(o))) {
                  C.sendEvent(o, r, t);
                  return;
                }
                var s = Qe(o, r, t, void 0, n, a);
                p(n, t, s, o == null ? void 0 : o.id, r),
                  P.trigger({
                    pixelID: o ? o.id : null,
                    eventName: r,
                    customData: t,
                    eventData: n,
                    eventId: s.getEventId(),
                  });
                var u = re.trigger(o, t, r);
                H(u, function (e) {
                  e != null &&
                    H(Q(e), function (t) {
                      t != null && s.append(t, e[t]);
                    });
                });
                var c = he.getComparedURL(),
                  d = he.getComparedReferrer(),
                  m = {};
                c != null && (m.dl = c),
                  d != null && (m.rl = d),
                  z(m) || oe.trigger(o, m, r, s),
                  l(
                    {
                      customData: t,
                      customParams: s,
                      eventName: r,
                      id: o ? o.id : null,
                      piiTranslator: null,
                      documentLink: m.dl ? m.dl : "",
                      referrerLink: m.rl ? m.rl : "",
                      eventData: n,
                      experimentId: i,
                    },
                    $e
                  );
              }
              function Ze() {
                for (; e.fbq.queue && e.fbq.queue.length && !Se.isLocked(); ) {
                  var t = e.fbq.queue.shift();
                  Oe.apply(e.fbq, t);
                }
              }
              Se.onUnlocked(function () {
                Ze();
              }),
                t.pixelId && ((ke = !0), We(t.pixelId)),
                ((ke && Ie) || e.fbq !== e._fbq) &&
                  be({ type: "CONFLICTING_VERSIONS" }),
                Te.length > 1 && be({ type: "MULTIPLE_PIXELS" }),
                J.listenOnce(function () {
                  q({
                    fbq: t,
                    automaticPageView: le,
                    onPageChange: function () {
                      var e = new Ae({
                        allowDuplicatePageViews: !0,
                        isAutomaticPageView: !0,
                      });
                      Fe.call(e, "trackCustom", "PageView");
                    },
                    makeSafe: v,
                    injectMethod: b,
                  });
                });
              function et(e) {
                t._initHandlers.push(e), qe();
              }
              function tt() {
                return { pixelInitializationTime: Re, pixels: Te };
              }
              function nt(e) {
                (e.instance = $e),
                  (e.callMethod = Fe),
                  (e._initHandlers = []),
                  (e._initsDone = {}),
                  (e.send = Ke),
                  (e.getEventCustomParameters = Qe),
                  (e.addInitHandler = et),
                  (e.getState = tt),
                  (e.init = We),
                  (e.set = Be),
                  (e.gateCheck = A),
                  (e.loadPlugin = function (e) {
                    return Pe.loadPlugin(e);
                  }),
                  (e.registerPlugin = function (e, t) {
                    Pe.registerPlugin(e, t);
                  });
              }
              nt(e.fbq),
                fe(e.fbq.queue),
                Ze(),
                (o.exports = { doExport: nt }),
                Y.trigger();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      (o.exports = a.getFbeventsModules("SignalsFBEvents")),
      a.registerPlugin && a.registerPlugin("fbevents", o.exports),
      a.ensureModuleRegistered("fbevents", function () {
        return o.exports;
      });
  })();
})(window, document, location, history);
fbq.registerPlugin("global_config", {
  __fbEventsPlugin: 1,
  plugin: function (fbq, instance, config) {
    fbq.loadPlugin("commonincludes");
    fbq.loadPlugin("identity");
    fbq.loadPlugin("privacysandbox");
    fbq.loadPlugin("opttracking");
    fbq.set("experiments", [
      { allocation: 0.01, code: "c", name: "no_op_exp", passRate: 0.5 },
      { allocation: 0, code: "d", name: "config_dedupe", passRate: 1 },
      {
        allocation: 0,
        code: "e",
        name: "send_fbc_when_no_cookie",
        passRate: 1,
      },
      { allocation: 0, code: "f", name: "send_events_in_batch", passRate: 0 },
      {
        allocation: 0,
        code: "h",
        name: "set_fbc_cookie_after_config_load",
        passRate: 0,
      },
      {
        allocation: 0,
        code: "i",
        name: "prioritize_send_beacon_in_url",
        passRate: 0.5,
      },
      { allocation: 0, code: "j", name: "fix_fbc_fbp_update", passRate: 0 },
      { allocation: 0, code: "l", name: "async_param_refactor", passRate: 0.5 },
      {
        allocation: 0.01,
        code: "m",
        name: "sync_process_event",
        passRate: 0.5,
      },
      {
        allocation: 0.04,
        code: "s",
        name: "fix_null_context_passed",
        passRate: 0.5,
      },
    ]);
    fbq.set("guardrails", [
      {
        name: "no_op",
        code: "a",
        passRate: 1,
        enableForPixels: ["569835061642423"],
      },
      {
        name: "extract_extra_microdata",
        code: "b",
        passRate: 0,
        enableForPixels: [],
      },
      {
        name: "sgw_auto_extract",
        code: "c",
        passRate: 1,
        enableForPixels: ["1296510287734738", "337570375319394"],
      },
      {
        name: "multi_eid_fix",
        code: "d",
        passRate: 0,
        enableForPixels: ["909978539160024", "966604283536489"],
      },
      {
        name: "use_async_param_refactor",
        code: "f",
        passRate: 1,
        enableForPixels: ["3421688111417438"],
      },
      {
        name: "process_pii_from_shopify",
        code: "h",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "send_censored_ph",
        code: "f",
        passRate: 1,
        enableForPixels: ["569835061642423"],
      },
      {
        name: "send_censored_em",
        code: "g",
        passRate: 1,
        enableForPixels: ["569835061642423"],
      },
      {
        name: "fix_fbevent_uri_error",
        code: "j",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "send_normalized_ud_format",
        code: "e",
        passRate: 1,
        enableForPixels: ["569835061642423"],
      },
      {
        name: "enable_automatic_parameter_logging",
        code: "i",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "release_spa_pageview_fix",
        code: "l",
        passRate: 1,
        enableForPixels: ["569835061642423"],
      },
      {
        name: "fix_duplicate_opt_tracking_param",
        code: "m",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "release_fix_null_context_passed",
        code: "n",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "reset_init_time_on_spa_page_change",
        code: "o",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "fix_missing_event_name_error",
        code: "p",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "use_string_prefix_match_from_util",
        code: "q",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "get_keywords_from_local_storage",
        code: "r",
        passRate: 0,
        enableForPixels: [
          "569835061642423",
          "1728810767262484",
          "197307666770807",
          "568414510204424",
        ],
      },
      {
        name: "bot_blocking_client_side_block_enabled",
        code: "s",
        passRate: 1,
        enableForPixels: ["1306783967701444"],
      },
      {
        name: "page_locale_metadata_enabled",
        code: "t",
        passRate: 1,
        enableForPixels: ["1728810767262484"],
      },
    ]);
    fbq.set("moduleEncodings", {
      map: {
        gateCheck: 0,
        generateEventId: 1,
        handleEventIdOverride: 2,
        normalizeSignalsFBEventsDOBType: 3,
        normalizeSignalsFBEventsEmailType: 4,
        normalizeSignalsFBEventsEnumType: 5,
        normalizeSignalsFBEventsPhoneNumberType: 6,
        normalizeSignalsFBEventsPostalCodeType: 7,
        normalizeSignalsFBEventsStringType: 8,
        PixelQueue: 9,
        SignalsConvertNodeToHTMLElement: 10,
        SignalsEventPayload: 11,
        SignalsEventValidation: 12,
        SignalsFBEventsAddGmailSuffixToEmail: 13,
        SignalsFBEventsAsyncParamUtils: 14,
        SignalsFBEventsAutomaticPageViewEvent: 15,
        SignalsFBEventsBaseEvent: 16,
        SignalsFBEventsBotBlockingConfigTypedef: 17,
        SignalsFBEventsBrowserPropertiesConfigTypedef: 18,
        SignalsFBEventsBrowserPropertiesPlatformConfigTypedef: 19,
        SignalsFBEventsBufferConfigTypedef: 20,
        SignalsFBEventsCCRuleEvaluatorConfigTypedef: 21,
        SignalsFBEventsCensor: 22,
        SignalsFBEventsCheckGateEvent: 23,
        SignalsFBEventsClientHintConfigTypedef: 24,
        SignalsFBEventsClientSidePixelForkingConfigTypedef: 25,
        signalsFBEventsCoerceAutomaticMatchingConfig: 26,
        signalsFBEventsCoerceBatchingConfig: 27,
        signalsFBEventsCoerceInferredEventsConfig: 28,
        signalsFBEventsCoerceParameterExtractors: 29,
        signalsFBEventsCoercePixelID: 30,
        signalsFBEventsCoerceStandardParameter: 31,
        SignalsFBEventsComparedManagers: 32,
        SignalsFBEventsConfigLoadedEvent: 33,
        SignalsFBEventsConfigStore: 34,
        SignalsFBEventsCookieConfigTypedef: 35,
        SignalsFBEventsCookieDeprecationLabelConfigTypedef: 36,
        SignalsFBEventsCookieManager: 37,
        SignalsFBEventsCorrectPIIPlacement: 38,
        signalsFBEventsCreateTrustedTypePolicy: 39,
        SignalsFBEventsDataProcessingOptionsConfigTypedef: 40,
        SignalsFBEventsDefaultCustomDataConfigTypedef: 41,
        SignalsFBEventsDisabledExtensionsConfigTypedef: 42,
        signalsFBEventsDoAutomaticMatching: 43,
        SignalsFBEventsESTRuleEngineConfigTypedef: 44,
        SignalsFBEventsEvents: 45,
        SignalsFBEventsEventValidationConfigTypedef: 46,
        SignalsFBEventsExperimentNames: 47,
        SignalsFBEventsExperimentsTypedef: 48,
        SignalsFBEventsExperimentsV2Typedef: 49,
        SignalsFBEventsExtractPII: 50,
        SignalsFBEventsFBQ: 51,
        signalsFBEventsFeatureGate: 52,
        signalsFBEventsFillParamList: 53,
        SignalsFBEventsFilterProtectedModeEvent: 54,
        SignalsFBEventsFiredEvent: 55,
        signalsFBEventsFireEvent: 56,
        SignalsFBEventsFireLock: 57,
        SignalsFBEventsForkEvent: 58,
        SignalsFBEventsGatingConfigTypedef: 59,
        SignalsFBEventsGetAutomaticParametersEvent: 60,
        SignalsFBEventsGetCustomParametersEvent: 61,
        signalsFBEventsGetIsChrome: 62,
        SignalsFBEventsGetIWLParametersEvent: 63,
        SignalsFBEventsGetTimingsEvent: 64,
        SignalsFBEventsGetValidUrl: 65,
        SignalsFBEventsGoogleAnalyticsBridgeConfigTypedef: 66,
        SignalsFBEventsGuardrail: 67,
        SignalsFBEventsGuardrailTypedef: 68,
        SignalsFBEventsIABPCMAEBridgeConfigTypedef: 69,
        SignalsFBEventsImagePixelOpenBridgeConfigTypedef: 70,
        signalsFBEventsInjectMethod: 71,
        signalsFBEventsIsHostMeta: 72,
        signalsFBEventsIsURLFromMeta: 73,
        SignalsFBEventsIWLBootStrapEvent: 74,
        SignalsFBEventsJSLoader: 75,
        SignalsFBEventsLateValidateCustomParametersEvent: 76,
        SignalsFBEventsLegacyExperimentGroupsTypedef: 77,
        SignalsFBEventsLogging: 78,
        signalsFBEventsMakeSafe: 79,
        SignalsFBEventsMessageParamsTypedef: 80,
        SignalsFBEventsMetaQEConfigTypedef: 81,
        SignalsFBEventsMethods: 82,
        SignalsFBEventsMicrodataConfigTypedef: 83,
        SignalsFBEventsMicrodataCoverageConfigTypedef: 84,
        SignalsFBEventsMicrodataExtractionConfigTypedef: 85,
        SignalsFBEventsMicrodataFieldTransmissionConfigTypedef: 86,
        SignalsFBEventsMobileAppBridge: 87,
        SignalsFBEventsModuleEncodings: 88,
        SignalsFBEventsModuleEncodingsTypedef: 89,
        SignalsFBEventsNetworkConfig: 90,
        SignalsFBEventsNormalizers: 91,
        SignalsFBEventsOpenBridgeConfigTypedef: 92,
        SignalsFBEventsOptIn: 93,
        SignalsFBEventsPageStatusEvent: 94,
        SignalsFBEventsPageStatusMonitor: 95,
        SignalsFBEventsParallelFireConfigTypedef: 96,
        SignalsFBEventsPIIAutomatchedEvent: 97,
        SignalsFBEventsPIIConflictingEvent: 98,
        SignalsFBEventsPIIInvalidatedEvent: 99,
        SignalsFBEventsPixelCookie: 100,
        SignalsFBEventsPixelPIISchema: 101,
        SignalsFBEventsPixelQueueState: 102,
        SignalsFBEventsPixelTypedef: 103,
        SignalsFBEventsPlugin: 104,
        SignalsFBEventsPluginLoadedEvent: 105,
        SignalsFBEventsPluginManager: 106,
        SignalsFBEventsProcessCCRulesEvent: 107,
        SignalsFBEventsProcessEmailAddress: 108,
        SignalsFBEventsProhibitedPixelConfigTypedef: 109,
        SignalsFBEventsProhibitedSourcesTypedef: 110,
        SignalsFBEventsProtectedDataModeConfigTypedef: 111,
        SignalsFBEventsQE: 112,
        SignalsFBEventsQEV2: 113,
        SignalsFBEventsQualityCheckerConfigTypedef: 114,
        SignalsFBEventsRawCookieOps: 115,
        SignalsFBEventsRegexParamFilterConfigTypedef: 116,
        signalsFBEventsResolveLegacyArguments: 117,
        SignalsFBEventsResolveLink: 118,
        SignalsFBEventsRestrictedDomainsConfigTypedef: 119,
        signalsFBEventsSendBeacon: 120,
        SignalsFBEventsSendCloudbridgeEvent: 121,
        signalsFBEventsSendEvent: 122,
        SignalsFBEventsSendEventEvent: 123,
        signalsFBEventsSendEventImpl: 124,
        signalsFBEventsSendFetch: 125,
        signalsFBEventsSendFormPOST: 126,
        signalsFBEventsSendGET: 127,
        SignalsFBEventsSetCCRules: 128,
        SignalsFBEventsSetESTRules: 129,
        SignalsFBEventsSetEventIDEvent: 130,
        SignalsFBEventsSetFilteredEventName: 131,
        SignalsFBEventsSetIWLExtractorsEvent: 132,
        SignalsFBEventsSetIWLParameterRulesEvent: 133,
        SignalsFBEventsShared: 134,
        SignalsFBEventsShopifySandboxConfigTypedef: 135,
        SignalsFBEventsShopifySandboxContextConfigTypedef: 136,
        signalsFBEventsShopifyUtil: 137,
        SignalsFBEventsShouldRestrictReferrerEvent: 138,
        SignalsFBEventsSmartSetupPixelConfigTypedef: 139,
        signalsFBEventsSPANavigationUtil: 140,
        SignalsFBEventsStandardParamChecksConfigTypedef: 141,
        SignalsFBEventsTelemetry: 142,
        SignalsFBEventsTrackEventEvent: 143,
        SignalsFBEventsTriggerSgwPixelTrackCommandConfigTypedef: 144,
        SignalsFBEventsTyped: 145,
        SignalsFBEventsTypeVersioning: 146,
        SignalsFBEventsUnwantedDataTypedef: 147,
        SignalsFBEventsUnwantedEventNamesConfigTypedef: 148,
        SignalsFBEventsUnwantedEventsConfigTypedef: 149,
        SignalsFBEventsUnwantedParamsConfigTypedef: 150,
        SignalsFBEventsURLManager: 151,
        SignalsFBEventsURLMetadataConfigTypedef: 152,
        signalsFBEventsUserDataParams: 153,
        SignalsFBEventsUtils: 154,
        SignalsFBEventsValidateCustomParametersEvent: 155,
        SignalsFBEventsValidateGetClickIDFromBrowserProperties: 156,
        SignalsFBEventsValidateGetIMEFromBrowserPropertiesPlatform: 157,
        SignalsFBEventsValidateUrlParametersEvent: 158,
        SignalsFBEventsValidationUtils: 159,
        SignalsFBEventsWebchatConfigTypedef: 160,
        SignalsFBEventsWebChatEvent: 161,
        SignalsParamList: 162,
        SignalsPixelCookieUtils: 163,
        SignalsPixelPIIConstants: 164,
        SignalsPixelPIIUtils: 165,
        WebStorage: 166,
        WebStorageMutex: 167,
        SignalsFBEvents: 168,
        "SignalsFBEvents.plugins.automaticparameters": 169,
        sha256_with_dependencies_new: 170,
        SignalsFBEventsBuildMicrodata: 171,
        SignalsFBEventsExtractMicrodataFromJsonLdV2: 172,
        SignalsFBEventsExtractMicrodataFromOpenGraphV2: 173,
        SignalsFBEventsExtractMicrodataFromSchemaOrgV2: 174,
        signalsFBEventsExtractMicrodataSchemas: 175,
        SignalsFBEventsMicrodata: 176,
        SignalsFBEventsParseMicrodataUtils: 177,
        SignalsFBEventsProcessMicrodata: 178,
        "SignalsFBEvents.plugins.botblocking": 179,
        SignalsFBEventsBlockFlags: 180,
        SignalsFBEventsBotDetectionEngine: 181,
        "SignalsFBEvents.plugins.browserproperties": 182,
        "SignalsFBEvents.plugins.cookie": 183,
        SignalsFBEventsBrowserPropertiesTypedef: 184,
        SignalsFBEventsFbcCombiner: 185,
        signalsFBEventsGetIsAndroid: 186,
        signalsFBEventsGetIsAndroidIAW: 187,
        signalsFBEventsGetIsSafariOrMobileSafari: 188,
        signalsFBEventsIsHostFacebook: 189,
        SignalsFBEventsLocalStorageTypedef: 190,
        SignalsFBEventsLocalStorageUtils: 191,
        signalsFBEventsShouldNotDropCookie: 192,
        SignalsFBEventsURLUtil: 193,
        "SignalsFBEvents.plugins.browserpropertiesplatform": 194,
        "SignalsFBEvents.plugins.buffer": 195,
        signalsFBEventsGetIsIosInAppBrowser: 196,
        "SignalsFBEvents.plugins.ccruleevaluator": 197,
        SignalsFBEventsCCRuleEngine: 198,
        SignalsFBEventsTransformToCCInput: 199,
        "SignalsFBEvents.plugins.clienthint": 200,
        SignalsFBEventsClientHintTypedef: 201,
        SignalsFBEventsGetIsAndroidChrome: 202,
        "SignalsFBEvents.plugins.clientsidepixelforking": 203,
        SignalsPixelClientSideForkingUtils: 204,
        "SignalsFBEvents.plugins.commonincludes": 205,
        "SignalsFBEvents.plugins.cookiedeprecationlabel": 206,
        "SignalsFBEvents.plugins.debug": 207,
        "SignalsFBEvents.plugins.defaultcustomdata": 208,
        "SignalsFBEvents.plugins.engagementdata": 209,
        "SignalsFBEvents.plugins.estruleengine": 210,
        signalsFBEventsMakeSafeString: 211,
        "SignalsFBEvents.plugins.eventvalidation": 212,
        "SignalsFBEvents.plugins.gating": 213,
        "SignalsFBEvents.plugins.googleanalyticsbridge": 214,
        "SignalsFBEvents.plugins.iabpcmaebridge": 215,
        "SignalsFBEvents.plugins.identifyintegration": 216,
        getDeepStackTrace: 217,
        getIntegrationCandidates: 218,
        "SignalsFBEvents.plugins.identity": 219,
        "SignalsFBEvents.plugins.imagepixelopenbridge": 220,
        "SignalsFBEvents.plugins.inferredevents": 221,
        signalsFBEventsCollapseUserData: 222,
        signalsFBEventsExtractEventPayload: 223,
        signalsFBEventsExtractFormFieldFeatures: 224,
        signalsFBEventsExtractFromInputs: 225,
        signalsFBEventsExtractPageFeatures: 226,
        SignalsFBEventsFeatureCounter: 227,
        SignalsFBEventsThrottler: 228,
        "SignalsFBEvents.plugins.iwlbootstrapper": 229,
        signalsFBEventsGetIwlUrl: 230,
        signalsFBEventsGetTier: 231,
        "SignalsFBEvents.plugins.iwlparameterrules": 232,
        "SignalsFBEvents.plugins.iwlparameters": 233,
        "SignalsFBEvents.plugins.jsonld_microdata": 234,
        "SignalsFBEvents.plugins.lastexternalreferrer": 235,
        "SignalsFBEvents.plugins.microdata": 236,
        "SignalsFBEvents.plugins.microdatacoverage": 237,
        SignalsFBEventsBitmapEncoder: 238,
        SignalsFBEventsConfigDrivenParsingUtils: 239,
        SignalsFBEventsCoverageExtractor: 240,
        SignalsFBEventsCoverageJsonLdExtractor: 241,
        SignalsFBEventsCoverageOpenGraphExtractor: 242,
        SignalsFBEventsCoverageSchemaOrgExtractor: 243,
        SignalsFBEventsMicrodataErrors: 244,
        "SignalsFBEvents.plugins.microdatafieldtransmission": 245,
        SignalsFBEventsConfigDrivenParser: 246,
        SignalsFBEventsDublinCoreParser: 247,
        SignalsFBEventsJsonLdParser: 248,
        SignalsFBEventsOpenGraphParser: 249,
        SignalsFBEventsRDFaParser: 250,
        SignalsFBEventsResponseOptimizer: 251,
        SignalsFBEventsSchemaOrgParser: 252,
        SignalsFBEventsTwitterCardParser: 253,
        "SignalsFBEvents.plugins.openbridge3": 254,
        cbsdk_fbevents_embed: 255,
        openBridgeAdvancedMatching: 256,
        openBridgeDomainFilter: 257,
        OpenBridgeFBLogin: 258,
        openBridgeUserDataUtils: 259,
        ResolveLinks: 260,
        "SignalsFBEvents.plugins.openbridgerollout": 261,
        "SignalsFBEvents.plugins.opttracking": 262,
        SignalsFBEventsOptTrackingOptions: 263,
        SignalsFBEventsProxyState: 264,
        "SignalsFBEvents.plugins.pagemetadata": 265,
        "SignalsFBEvents.plugins.parallelfire": 266,
        signalsFBEventsSendXHR: 267,
        "SignalsFBEvents.plugins.performance": 268,
        SignalsFBEventsPerformanceTiming: 269,
        "SignalsFBEvents.plugins.privacypreservingdatalookup": 270,
        pdl: 271,
        PdlWasm: 272,
        PdlWasmTypes: 273,
        WebPDL: 274,
        WebPDLUtility: 275,
        "SignalsFBEvents.plugins.privacysandbox": 276,
        "SignalsFBEvents.plugins.prohibitedpixels": 277,
        "SignalsFBEvents.plugins.prohibitedsources": 278,
        "SignalsFBEvents.plugins.protecteddatamode": 279,
        "SignalsFBEvents.plugins.regexparamfilter": 280,
        "SignalsFBEvents.plugins.scrolldepth": 281,
        "SignalsFBEvents.plugins.shopifyappintegratedpixel": 282,
        "SignalsFBEvents.plugins.shopifysandbox": 283,
        "SignalsFBEvents.plugins.smartsetup": 284,
        signalsFBEventsWarningAggregator: 285,
        smartSetupBuildResult: 286,
        smartSetupProcessContent: 287,
        "SignalsFBEvents.plugins.standardparamchecks": 288,
        "SignalsFBEvents.plugins.timespent": 289,
        SignalsFBEventsTimespentTracking: 290,
        "SignalsFBEvents.plugins.topicsapi": 291,
        "SignalsFBEvents.plugins.triggersgwpixeltrackcommand": 292,
        "SignalsFBEvents.plugins.unwanteddata": 293,
        "SignalsFBEvents.plugins.unwantedeventnames": 294,
        "SignalsFBEvents.plugins.unwantedevents": 295,
        "SignalsFBEvents.plugins.unwantedparams": 296,
        "SignalsFBEvents.plugins.urlmetadata": 297,
        SignalsFBEventsURLMetadataUtils: 298,
        "SignalsFBEvents.plugins.urlparamschematization": 299,
        AllowableQueryBucketizedValues: 300,
        AllowableQueryKeys: 301,
        AllowableQueryValues: 302,
        AllowedRegexParameterValue: 303,
        AllowedURLParameterValue: 304,
        BucketedURLParameterValue: 305,
        EnumExtractor: 306,
        FBIDsExtractor: 307,
        FBIDValidator: 308,
        IURLParameterValue: 309,
        URLParameterConfig: 310,
        URLSchematization: 311,
        URLSchematizer: 312,
        UtmIdFetcher: 313,
        "SignalsFBEvents.plugins.webchat": 314,
        "SignalsFBEvents.plugins.websiteperformance": 315,
        "SignalsFBevents.plugins.automaticmatchingforpartnerintegrations": 316,
        SignalsFBEventsCookieProviderType: 317,
        SignalsFBEventsESTCustomData: 318,
        SignalsFBEventsEnums: 319,
        SignalsFBEventsFormFieldFeaturesType: 320,
        SignalsFBEventsTypes: 321,
        SignalsFBEventsURLProviderType: 322,
        SignalsFBEventsWildcardMatches: 323,
        SignalsInteractionUtil: 324,
        SignalsPageVisibilityUtil: 325,
        SignalsFBEventsAutomaticEventsTypes: 326,
        signalsFBEventsElementDoesMatch: 327,
        signalsFBEventsExtractButtonFeatures: 328,
        signalsFBEventsExtractForm: 329,
        signalsFBEventsGetTruncatedButtonText: 330,
        signalsFBEventsGetWrappingButton: 331,
        signalsFBEventsIsIWLElement: 332,
        signalsFBEventsIsSaneAndNotDisabledButton: 333,
        "babel.config": 334,
        fbevents_embed: 335,
        SignalsFBEventsConfigTypes: 336,
        SignalsFBEventsForkCbsdkEvent: 337,
        SignalsFBEventsConfigDrivenParserInterface: 338,
        SignalsFBEventsCoverageParserInterface: 339,
        ExperimentUtil: 340,
        OpenBridgeConnection: 341,
        topics_api_utility_lib: 342,
        signalsFBEventsGetIsChromeInclIOS: 343,
        signalsFBEventsGetIsWebview: 344,
        analytics_debug: 345,
        analytics_ecommerce: 346,
        analytics_enhanced_ecommerce: 347,
        analytics_enhanced_link_attribution: 348,
        analytics_release: 349,
        proxy_polyfill: 350,
        SignalsFBEventsESTRuleConditionTypedef: 351,
        TestUtils: 352,
        loadBaseCode: 353,
        paramFilterFixtures: 354,
      },
      hash: "97937018cefade17726f0472876fc101316b2ce9008a35a6a5a7977d7436151a",
    });
    config.set(null, "batching", { batchWaitTimeMs: 10, maxBatchSize: 10 });
    config.set(null, "microdata", { waitTimeMs: 500 });
    fbq.set("experimentsV2", [
      {
        allocation: 1,
        code: "pl",
        name: "page_load_level_no_op_experiment",
        passRate: 0.5,
        universe: "page_load_level_no_op_universe",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 1,
        code: "el",
        name: "event_level_no_op_experiment",
        passRate: 0.5,
        universe: "event_level_no_op_universe",
        evaluationType: "EVENT_LEVEL",
      },
      {
        allocation: 1,
        code: "bc",
        name: "button_click_optimize_experiment_v2",
        passRate: 1,
        universe: "button_click_experiment_universe",
        evaluationType: "EVENT_LEVEL",
      },
      {
        allocation: 0,
        code: "se",
        name: "process_additional_shopify_events",
        passRate: 0,
        universe: "shopify_events_universe",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 1,
        code: "ra",
        name: "microdata_refactor_migration_automatic_parameters",
        passRate: 0,
        universe: "microdata_refactor_migration_automatic_parameters",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 1,
        code: "rp",
        name: "microdata_refactor_migration_page_meta_data",
        passRate: 0,
        universe: "microdata_refactor_migration_page_meta_data",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 0.5,
        code: "ct",
        name: "cookie_ttl_fix",
        passRate: 0.5,
        universe: "cookie_universe",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 0.5,
        code: "im",
        name: "in_memory_cookie_jar",
        passRate: 0.5,
        universe: "cookie_universe",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 1,
        code: "hf",
        name: "high_fetch_priority_image",
        passRate: 0.5,
        universe: "high_fetch_priority_universe",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 0,
        code: "zz",
        name: "meta_qe",
        passRate: 0,
        universe: "qe_universe",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 0.05,
        code: "pt",
        name: "page_title_og_fallback",
        passRate: 0.5,
        universe: "page_title_og_fallback_universe",
        evaluationType: "EVENT_LEVEL",
      },
      {
        allocation: 0.01,
        code: "ai",
        name: "android_iab_max_get_length_32k",
        passRate: 0.5,
        universe: "android_iab_max_get_length_universe",
        evaluationType: "EVENT_LEVEL",
      },
    ]);
    instance.configLoaded("global_config");
  },
});
